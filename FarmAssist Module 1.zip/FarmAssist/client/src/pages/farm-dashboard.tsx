import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  Calendar, 
  History, 
  Sprout, 
  ListTodo,
  Check,
  User,
  StickyNote,
  X,
  Calculator,
  TrendingUp
} from "lucide-react";
import { CROP_TASK_CALENDAR } from "@shared/crop-data";
import type { TaskProgress } from "@shared/schema";

interface TaskCompletionData {
  taskId: number;
  notes: string;
}

interface User {
  id: number;
  username: string;
  fullName: string;
}

export default function FarmDashboard({ currentUser }: { currentUser?: User }) {
  const [selectedTask, setSelectedTask] = useState<TaskProgress | null>(null);
  const [completionModalOpen, setCompletionModalOpen] = useState(false);
  const [completionNotes, setCompletionNotes] = useState("");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [timeFilter, setTimeFilter] = useState("last7days");
  const { toast } = useToast();

  // Generate tasks from crop calendar - simulating current tomato crop at day 45
  const currentCrop = "tomato";
  const currentDay = 45;
  const cropTasks = CROP_TASK_CALENDAR[currentCrop as keyof typeof CROP_TASK_CALENDAR];
  
  // Fetch tasks from API
  const { data: apiTasks, isLoading: tasksLoading } = useQuery({
    queryKey: ["/api/tasks", 1], // userId = 1 for demo
    queryFn: () => apiRequest("GET", "/api/tasks/1"),
    enabled: true,
  });

  // Combine API tasks with crop calendar for missing tasks
  const mockTasks: TaskProgress[] = cropTasks.tasks
    .filter(task => task.day <= currentDay + 5) // Show current and next 5 days
    .map((task, index) => {
      // Check if this task exists in API data (ensure apiTasks is an array)
      const existingTask = Array.isArray(apiTasks) ? apiTasks.find((t: TaskProgress) => t.taskDay === task.day) : null;
      
      if (existingTask) {
        return existingTask;
      }
      
      // Create mock task if not in API
      return {
        id: -(index + 1), // Negative ID for mock tasks
        userId: 1,
        farmCalculationId: 1,
        taskDay: task.day,
        taskTitle: task.task,
        taskDescription: task.task,
        taskCategory: task.category,
        priority: task.priority,
        isCompleted: false,
        completedAt: null,
        notes: null,
        createdAt: new Date()
      };
    });

  const completedTasks = mockTasks.filter(task => task.isCompleted);
  const pendingTasks = mockTasks.filter(task => !task.isCompleted);

  const completeTaskMutation = useMutation({
    mutationFn: async (data: TaskCompletionData) => {
      return await apiRequest("PATCH", `/api/tasks/${data.taskId}/complete`, { notes: data.notes });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task Completed",
        description: "Task has been marked as complete successfully.",
      });
      setCompletionModalOpen(false);
      setCompletionNotes("");
      setSelectedTask(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to complete task",
        variant: "destructive",
      });
    }
  });

  const handleMarkDone = (task: TaskProgress) => {
    setSelectedTask(task);
    setCompletionModalOpen(true);
  };

  const handleCompleteTask = () => {
    if (selectedTask) {
      // If it's a mock task (negative ID), create it first then complete it
      if (selectedTask.id < 0) {
        // Create the task first, then mark it complete
        const taskData = {
          userId: selectedTask.userId,
          farmCalculationId: selectedTask.farmCalculationId,
          taskDay: selectedTask.taskDay,
          taskTitle: selectedTask.taskTitle,
          taskDescription: selectedTask.taskDescription,
          taskCategory: selectedTask.taskCategory,
          priority: selectedTask.priority,
          isCompleted: true,
          notes: completionNotes.trim()
        };
        
        apiRequest("POST", "/api/tasks", taskData)
          .then(() => {
            queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
            toast({
              title: "Task Completed",
              description: "Task has been recorded and marked as complete.",
            });
            setCompletionModalOpen(false);
            setCompletionNotes("");
            setSelectedTask(null);
          })
          .catch((error) => {
            toast({
              title: "Error",
              description: error.message || "Failed to record task completion",
              variant: "destructive",
            });
          });
      } else {
        // Existing task - just mark as complete
        completeTaskMutation.mutate({
          taskId: selectedTask.id,
          notes: completionNotes.trim()
        });
      }
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-700";
      case "medium": return "bg-orange-100 text-orange-700";
      case "low": return "bg-green-100 text-green-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "preparation": return "border-l-purple-500";
      case "planting": return "border-l-green-500";
      case "watering": return "border-l-blue-500";
      case "fertilization": return "border-l-green-600";
      case "maintenance": return "border-l-orange-500";
      case "pest_control": return "border-l-red-500";
      case "disease_control": return "border-l-pink-500";
      case "monitoring": return "border-l-indigo-500";
      case "harvesting": return "border-l-yellow-500";
      default: return "border-l-gray-500";
    }
  };

  const formatDate = (date: Date | null) => {
    if (!date) return "";
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return "Just now";
    if (days === 1) return "1 day ago";
    if (days < 7) return `${days} days ago`;
    if (days < 30) return `${Math.floor(days / 7)} week${Math.floor(days / 7) > 1 ? 's' : ''} ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-gradient-to-r from-green-600 to-green-500 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center">
                <Sprout className="mr-3" size={36} />
                FarmAssist
              </h1>
              <p className="text-lg opacity-90">Smart Task Management for Better Farming</p>
            </div>
            <div className="text-right">
              <div className="text-sm opacity-75">Current Farm Plan</div>
              <div className="font-semibold">{cropTasks.name}</div>
              <div className="text-xs">Day {currentDay} of {cropTasks.totalDays}</div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Task Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-l-4 border-l-green-500 hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-green-600">{mockTasks.length}</div>
                  <div className="text-gray-600 text-sm font-medium">Total ListTodo</div>
                </div>
                <ListTodo className="text-green-500" size={24} />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-blue-500 hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-blue-600">{completedTasks.length}</div>
                  <div className="text-gray-600 text-sm font-medium">Completed</div>
                </div>
                <CheckCircle className="text-blue-500" size={24} />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-orange-500 hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-orange-600">
                    {pendingTasks.filter(t => t.taskDay <= 45).length}
                  </div>
                  <div className="text-gray-600 text-sm font-medium">Due Today</div>
                </div>
                <Clock className="text-orange-500" size={24} />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-red-500 hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-red-600">
                    {pendingTasks.filter(t => t.taskDay < 45).length}
                  </div>
                  <div className="text-gray-600 text-sm font-medium">Overdue</div>
                </div>
                <AlertTriangle className="text-red-500" size={24} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Task Calendar Section */}
        <Card className="mb-8">
          <CardHeader className="border-b">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <CardTitle className="text-2xl font-bold text-gray-800 mb-2 flex items-center">
                  <Calendar className="text-green-500 mr-3" size={24} />
                  Daily Task Calendar
                </CardTitle>
                <p className="text-gray-600">Your farming tasks for this week</p>
              </div>
              <div className="mt-4 md:mt-0 flex gap-3">
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    <SelectItem value="high">High Priority</SelectItem>
                    <SelectItem value="medium">Medium Priority</SelectItem>
                    <SelectItem value="low">Low Priority</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="watering">Watering</SelectItem>
                    <SelectItem value="fertilization">Fertilization</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="monitoring">Monitoring</SelectItem>
                    <SelectItem value="pest_control">Pest Control</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            {mockTasks.map((task) => (
              <div 
                key={task.id} 
                className={`transition-all duration-500 border border-gray-200 rounded-lg p-4 mb-4 hover:bg-gray-50 border-l-4 ${getCategoryColor(task.taskCategory)} ${
                  task.isCompleted ? 'opacity-70 bg-gradient-to-r from-gray-50 to-gray-100' : 'bg-white'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start flex-1">
                    <div className={`${task.isCompleted ? 'bg-blue-500' : task.priority === 'high' ? 'bg-red-500' : task.priority === 'medium' ? 'bg-green-500' : 'bg-blue-500'} text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-sm mr-4 flex-shrink-0`}>
                      {task.taskDay}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800 mb-2">{task.taskTitle}</h3>
                      <p className="text-gray-600 text-sm mb-3">{task.taskDescription}</p>
                      <div className="flex flex-wrap gap-2 items-center mb-2">
                        <Badge variant="secondary" className="capitalize">
                          {task.taskCategory.replace('_', ' ')}
                        </Badge>
                        <Badge className={getPriorityColor(task.priority)}>
                          {task.priority} Priority
                        </Badge>
                        {task.isCompleted ? (
                          <Badge className="bg-blue-100 text-blue-700">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Completed
                          </Badge>
                        ) : task.taskDay < 45 ? (
                          <span className="text-red-500 text-xs font-medium">
                            <AlertTriangle className="w-3 h-3 inline mr-1" />
                            Overdue by {45 - task.taskDay} day{45 - task.taskDay > 1 ? 's' : ''}
                          </span>
                        ) : task.taskDay === 45 ? (
                          <span className="text-orange-500 text-xs">Due: Today</span>
                        ) : (
                          <span className="text-gray-500 text-xs">Due: Tomorrow</span>
                        )}
                      </div>
                      {task.isCompleted && task.notes && (
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <div className="text-xs text-blue-600 font-medium mb-1">
                            <User className="w-3 h-3 inline mr-1" />
                            Completed by John Farmer • {formatDate(task.completedAt)}
                          </div>
                          <div className="text-sm text-blue-800">{task.notes}</div>
                        </div>
                      )}
                    </div>
                  </div>
                  {!task.isCompleted && (
                    <div className="flex gap-2 ml-4">
                      <Button 
                        onClick={() => handleMarkDone(task)}
                        className="bg-green-600 hover:bg-green-700 text-white"
                        size="sm"
                      >
                        <Check className="w-4 h-4 mr-2" />
                        Mark Done
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Completed ListTodo Log */}
        <Card>
          <CardHeader className="border-b">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <CardTitle className="text-2xl font-bold text-gray-800 mb-2 flex items-center">
                  <History className="text-blue-500 mr-3" size={24} />
                  Completed ListTodo Log
                </CardTitle>
                <p className="text-gray-600">Track your farming progress and achievements</p>
              </div>
              <div className="mt-4 md:mt-0">
                <Select value={timeFilter} onValueChange={setTimeFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last7days">Last 7 Days</SelectItem>
                    <SelectItem value="last30days">Last 30 Days</SelectItem>
                    <SelectItem value="thisseason">This Season</SelectItem>
                    <SelectItem value="alltime">All Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            {completedTasks.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No completed tasks yet. Start completing tasks to see your progress here!</p>
              </div>
            ) : (
              completedTasks.map((task) => (
                <div key={task.id} className={`border-l-4 border-l-blue-500 bg-blue-50 rounded-lg p-4 mb-4`}>
                  <div className="flex items-start">
                    <div className="bg-blue-500 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold text-sm mr-4 flex-shrink-0">
                      {task.taskDay}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-gray-800">{task.taskTitle}</h3>
                        <div className="text-right">
                          <div className="text-sm text-blue-600 font-medium">Completed</div>
                          <div className="text-xs text-gray-500">{formatDate(task.completedAt)}</div>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2 items-center mb-3">
                        <Badge variant="secondary" className="capitalize">
                          {task.taskCategory.replace('_', ' ')}
                        </Badge>
                        <Badge className={getPriorityColor(task.priority)}>
                          {task.priority} Priority
                        </Badge>
                      </div>
                      {task.notes && (
                        <div className="bg-white border border-blue-200 rounded p-3">
                          <div className="text-sm font-medium text-gray-700 mb-1">Completion Notes:</div>
                          <div className="text-sm text-gray-600">"{task.notes}"</div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Task Completion Modal */}
      <Dialog open={completionModalOpen} onOpenChange={setCompletionModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <CheckCircle className="text-green-500 mr-2" size={20} />
              Mark Task Complete
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-gray-800 mb-2">{selectedTask?.taskTitle}</h4>
              <p className="text-sm text-gray-600">Add notes about how you completed this task (optional)</p>
            </div>
            
            <div>
              <Label htmlFor="completion-notes" className="flex items-center text-sm font-medium text-gray-700 mb-2">
                <StickyNote className="text-green-500 mr-1" size={16} />
                Completion Notes
              </Label>
              <Textarea
                id="completion-notes"
                value={completionNotes}
                onChange={(e) => setCompletionNotes(e.target.value)}
                rows={4}
                placeholder="Describe what you did, any observations, challenges, or results..."
                className="resize-none"
              />
            </div>
            
            <div className="flex gap-3">
              <Button 
                variant="outline" 
                onClick={() => setCompletionModalOpen(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleCompleteTask}
                disabled={completeTaskMutation.isPending}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                {completeTaskMutation.isPending ? (
                  "Completing..."
                ) : (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Complete Task
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
