import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Brain, Filter, Calendar, Tag, AlertTriangle, Info, CheckCircle, Clock } from "lucide-react";
import { EXTENSION_TIPS, type ExtensionTip, type CropExtensionTips } from "@shared/extension-tips";

interface User {
  id: number;
  username: string;
  fullName: string;
}

interface ExtensionAdvisorProps {
  currentUser?: User;
}

export default function ExtensionAdvisor({ currentUser }: ExtensionAdvisorProps) {
  const [selectedCrop, setSelectedCrop] = useState<string>("");
  const [dayFilter, setDayFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [filteredTips, setFilteredTips] = useState<ExtensionTip[]>([]);
  const [currentCropTips, setCurrentCropTips] = useState<CropExtensionTips | null>(null);

  // Filter tips when crop, day, or category changes
  useEffect(() => {
    if (!currentCropTips) {
      setFilteredTips([]);
      return;
    }

    let tips = [...currentCropTips.tips];

    // Filter by day range
    if (dayFilter !== "all") {
      const [start, end] = dayFilter.split("-").map(Number);
      tips = tips.filter(tip => tip.day >= start && tip.day <= end);
    }

    // Filter by category
    if (categoryFilter !== "all") {
      tips = tips.filter(tip => tip.category === categoryFilter);
    }

    // Sort by day
    tips.sort((a, b) => a.day - b.day);

    setFilteredTips(tips);
  }, [currentCropTips, dayFilter, categoryFilter]);

  const handleCropChange = (cropType: string) => {
    setSelectedCrop(cropType);
    if (cropType && EXTENSION_TIPS[cropType]) {
      setCurrentCropTips(EXTENSION_TIPS[cropType]);
      setDayFilter("all");
      setCategoryFilter("all");
    } else {
      setCurrentCropTips(null);
      setFilteredTips([]);
    }
  };

  const getExpertiseLevelIcon = (level: string) => {
    switch (level) {
      case "critical":
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case "important":
        return <Info className="h-4 w-4 text-orange-500" />;
      case "helpful":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "optional":
        return <Clock className="h-4 w-4 text-gray-500" />;
      default:
        return <Info className="h-4 w-4 text-blue-500" />;
    }
  };

  const getExpertiseLevelColor = (level: string) => {
    switch (level) {
      case "critical":
        return "destructive";
      case "important":
        return "secondary";
      case "helpful":
        return "default";
      case "optional":
        return "outline";
      default:
        return "default";
    }
  };

  const getCategoryIcon = (category: string) => {
    // You can expand this with more specific icons
    return <Tag className="h-4 w-4" />;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <Brain className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold text-gray-800">Extension Intelligence Engine</h1>
        </div>
        <p className="text-lg text-gray-600">
          AI Agronomist & Digital Extension Advisor - Expert farming advice for your crops
        </p>
      </div>

      {/* Crop Selection */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Select Crop for Expert Advice
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedCrop} onValueChange={handleCropChange}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Choose a crop to get expert farming tips..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="tomato">🍅 Tomato</SelectItem>
              <SelectItem value="maize">🌽 Maize (Corn)</SelectItem>
              <SelectItem value="pepper">🌶️ Pepper</SelectItem>
              <SelectItem value="beans">🫘 Beans</SelectItem>
              <SelectItem value="cabbage">🥬 Cabbage</SelectItem>
              <SelectItem value="onion">🧅 Onion</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Filters */}
      {currentCropTips && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filter Expert Tips
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Filter by Growth Stage</label>
                <Select value={dayFilter} onValueChange={setDayFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Days</SelectItem>
                    <SelectItem value="1-30">Days 1-30 (Early Stage)</SelectItem>
                    <SelectItem value="31-60">Days 31-60 (Growth Stage)</SelectItem>
                    <SelectItem value="61-90">Days 61-90 (Maturity Stage)</SelectItem>
                    <SelectItem value="91-120">Days 91-120 (Harvest Stage)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Filter by Category</label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="preparation">Preparation</SelectItem>
                    <SelectItem value="planting">Planting</SelectItem>
                    <SelectItem value="watering">Watering</SelectItem>
                    <SelectItem value="fertilization">Fertilization</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="pest_control">Pest Control</SelectItem>
                    <SelectItem value="disease_control">Disease Control</SelectItem>
                    <SelectItem value="monitoring">Monitoring</SelectItem>
                    <SelectItem value="harvesting">Harvesting</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Expert Tips Display */}
      {currentCropTips ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold">
              {currentCropTips.name} - {filteredTips.length} Expert Tips
            </h2>
            
            {/* Legend */}
            <div className="flex items-center gap-2 text-sm">
              <span className="font-medium">Priority:</span>
              <div className="flex items-center gap-1">
                <AlertTriangle className="h-3 w-3 text-red-500" />
                <span className="text-xs">Critical</span>
              </div>
              <div className="flex items-center gap-1">
                <Info className="h-3 w-3 text-orange-500" />
                <span className="text-xs">Important</span>
              </div>
              <div className="flex items-center gap-1">
                <CheckCircle className="h-3 w-3 text-green-500" />
                <span className="text-xs">Helpful</span>
              </div>
            </div>
          </div>

          {filteredTips.length > 0 ? (
            <div className="grid gap-4">
              {filteredTips.map((tip, index) => (
                <Card key={index} className="border-l-4 border-l-blue-500">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="font-mono">
                            Day {tip.day}
                          </Badge>
                          <Badge variant="secondary" className="capitalize">
                            {getCategoryIcon(tip.category)}
                            <span className="ml-1">{tip.category.replace(/_/g, ' ')}</span>
                          </Badge>
                          <Badge variant={getExpertiseLevelColor(tip.expertise_level) as any}>
                            {getExpertiseLevelIcon(tip.expertise_level)}
                            <span className="ml-1 capitalize">{tip.expertise_level}</span>
                          </Badge>
                        </div>
                        <p className="text-gray-700 leading-relaxed">{tip.tip}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <Brain className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-600 mb-2">No Tips Found</h3>
                <p className="text-gray-500">
                  Try adjusting your filters to see more expert farming advice for {currentCropTips.name.toLowerCase()}.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      ) : (
        <Card>
          <CardContent className="p-8 text-center">
            <Brain className="h-16 w-16 text-blue-400 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-600 mb-2">Welcome to the Extension Intelligence Engine</h3>
            <p className="text-gray-500 mb-4">
              Your AI Agronomist & Digital Extension Advisor is ready to provide expert farming advice.
            </p>
            <p className="text-sm text-gray-400">
              Select a crop above to access day-by-day expert tips from agricultural specialists.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}