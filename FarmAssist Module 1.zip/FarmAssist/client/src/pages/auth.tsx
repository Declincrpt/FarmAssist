import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Sprout, UserCircle, UserPlus, LogIn, LogOut, MapPin, CheckCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  phone?: string;
  location?: string;
  farmSize?: number;
  experience: string;
  createdAt: Date;
}

interface AuthPageProps {
  currentUser: User | null;
  onLogin: (user: User) => void;
  onLogout: () => void;
}

export default function AuthPage({ currentUser, onLogin, onLogout }: AuthPageProps) {
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [loginData, setLoginData] = useState({ username: "" });
  const [registerData, setRegisterData] = useState({
    username: "",
    email: "",
    fullName: "",
    phone: "",
    location: "",
    farmSize: "",
    experience: ""
  });
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: (data: { username: string }) => apiRequest("POST", "/api/auth/login", data),
    onSuccess: (user: User) => {
      onLogin(user);
      toast({
        title: "Login Successful",
        description: `Welcome back, ${user.fullName}!`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid username",
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/auth/register", data),
    onSuccess: (user: User) => {
      onLogin(user);
      toast({
        title: "Registration Successful",
        description: `Account created for ${user.fullName}!`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Registration Failed",
        description: error.message || "Failed to create account",
        variant: "destructive",
      });
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginData.username.trim()) {
      toast({
        title: "Error",
        description: "Please enter your username",
        variant: "destructive",
      });
      return;
    }
    loginMutation.mutate(loginData);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      ...registerData,
      farmSize: registerData.farmSize ? parseFloat(registerData.farmSize) : undefined
    };
    registerMutation.mutate(data);
  };

  const handleLogout = () => {
    onLogout();
    toast({
      title: "Logged Out",
      description: "You have been logged out successfully",
    });
  };

  if (currentUser) {
    return (
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <header className="text-center py-8 mb-8">
          <h1 className="text-4xl font-bold flex items-center justify-center gap-3 text-green-600 mb-2">
            <Sprout className="h-10 w-10" />
            FarmAssist Crop
          </h1>
          <p className="text-xl text-gray-600">Smart Planting Calculator for Farmers</p>
        </header>

        {/* User Profile */}
        <Card className="max-w-md mx-auto">
          <CardHeader className="bg-green-600 text-white">
            <CardTitle className="flex items-center gap-2">
              <UserCircle className="h-6 w-6" />
              User Profile
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="mb-4">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-3" />
                <h4 className="text-xl font-semibold text-green-600 mb-3">Welcome back!</h4>
              </div>
              
              <div className="space-y-2 mb-6">
                <p className="font-semibold text-lg">{currentUser.fullName}</p>
                <p className="text-gray-600">@{currentUser.username}</p>
                {currentUser.location && (
                  <p className="text-gray-600 flex items-center justify-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {currentUser.location}
                    {currentUser.farmSize && ` • ${currentUser.farmSize} hectares`}
                  </p>
                )}
                <p className="text-sm text-gray-500 capitalize">
                  Experience: {currentUser.experience}
                </p>
              </div>
              
              <Button variant="outline" onClick={handleLogout} className="text-red-600 border-red-300 hover:bg-red-50">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <header className="text-center py-8 mb-8">
        <h1 className="text-4xl font-bold flex items-center justify-center gap-3 text-green-600 mb-2">
          <Sprout className="h-10 w-10" />
          FarmAssist Crop
        </h1>
        <p className="text-xl text-gray-600">Smart Planting Calculator for Farmers</p>
      </header>

      {/* Authentication Card */}
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="bg-blue-600 text-white">
          <CardTitle className="flex items-center gap-2">
            <UserCircle className="h-6 w-6" />
            {authMode === "login" ? "Login to Your Farm Account" : "Create Your Farm Account"}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {authMode === "login" ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  value={loginData.username}
                  onChange={(e) => setLoginData({ username: e.target.value })}
                  required
                />
              </div>
              
              <div className="flex justify-center gap-3">
                <Button type="submit" disabled={loginMutation.isPending}>
                  <LogIn className="h-4 w-4 mr-2" />
                  {loginMutation.isPending ? "Logging in..." : "Login"}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setAuthMode("register")}
                >
                  New? Register Here
                </Button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="regUsername">Username</Label>
                  <Input
                    id="regUsername"
                    type="text"
                    value={registerData.username}
                    onChange={(e) => setRegisterData({ ...registerData, username: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="regEmail">Email</Label>
                  <Input
                    id="regEmail"
                    type="email"
                    value={registerData.email}
                    onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="regFullName">Full Name</Label>
                  <Input
                    id="regFullName"
                    type="text"
                    value={registerData.fullName}
                    onChange={(e) => setRegisterData({ ...registerData, fullName: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="regPhone">Phone Number</Label>
                  <Input
                    id="regPhone"
                    type="tel"
                    value={registerData.phone}
                    onChange={(e) => setRegisterData({ ...registerData, phone: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="regLocation">Location</Label>
                  <Input
                    id="regLocation"
                    type="text"
                    placeholder="City, Region"
                    value={registerData.location}
                    onChange={(e) => setRegisterData({ ...registerData, location: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="regFarmSize">Farm Size (hectares)</Label>
                  <Input
                    id="regFarmSize"
                    type="number"
                    step="0.1"
                    min="0"
                    value={registerData.farmSize}
                    onChange={(e) => setRegisterData({ ...registerData, farmSize: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="regExperience">Experience Level</Label>
                <Select 
                  value={registerData.experience} 
                  onValueChange={(value) => setRegisterData({ ...registerData, experience: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your experience" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Beginner (0-2 years)</SelectItem>
                    <SelectItem value="intermediate">Intermediate (3-10 years)</SelectItem>
                    <SelectItem value="advanced">Advanced (10+ years)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex justify-center gap-3">
                <Button type="submit" disabled={registerMutation.isPending}>
                  <UserPlus className="h-4 w-4 mr-2" />
                  {registerMutation.isPending ? "Creating Account..." : "Register"}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setAuthMode("login")}
                >
                  Back to Login
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}