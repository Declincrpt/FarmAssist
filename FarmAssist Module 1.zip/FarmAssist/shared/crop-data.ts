// Static crop database from original FarmAssist with realistic farming data
export const CROP_DATABASE = {
    tomato: {
        name: "Tomato",
        spacingMeters: 0.6, // 60cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 300,
        fertilizer: {
            open_field_rainfed: 200, // kg per hectare
            open_field_irrigated: 250,
            greenhouse: 300,
            polytunnel: 275
        },
        manure: {
            open_field_rainfed: 15000, // kg per hectare
            open_field_irrigated: 20000,
            greenhouse: 25000,
            polytunnel: 22000
        },
        waterPerWeek: {
            open_field_rainfed: 0, // liters per plant per week
            open_field_irrigated: 25,
            greenhouse: 30,
            polytunnel: 28
        },
        yieldPerPlant: {
            open_field_rainfed: 3, // kg per plant
            open_field_irrigated: 5,
            greenhouse: 8,
            polytunnel: 6
        }
    },
    maize: {
        name: "Maize (Corn)",
        spacingMeters: 0.75, // 75cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 3,
        fertilizer: {
            open_field_rainfed: 150,
            open_field_irrigated: 200,
            greenhouse: 250,
            polytunnel: 225
        },
        manure: {
            open_field_rainfed: 10000,
            open_field_irrigated: 15000,
            greenhouse: 20000,
            polytunnel: 18000
        },
        waterPerWeek: {
            open_field_rainfed: 0,
            open_field_irrigated: 20,
            greenhouse: 25,
            polytunnel: 22
        },
        yieldPerPlant: {
            open_field_rainfed: 0.8,
            open_field_irrigated: 1.2,
            greenhouse: 1.8,
            polytunnel: 1.5
        }
    },
    pepper: {
        name: "Pepper",
        spacingMeters: 0.5, // 50cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 150,
        fertilizer: {
            open_field_rainfed: 180,
            open_field_irrigated: 220,
            greenhouse: 280,
            polytunnel: 250
        },
        manure: {
            open_field_rainfed: 12000,
            open_field_irrigated: 18000,
            greenhouse: 23000,
            polytunnel: 20000
        },
        waterPerWeek: {
            open_field_rainfed: 0,
            open_field_irrigated: 15,
            greenhouse: 20,
            polytunnel: 18
        },
        yieldPerPlant: {
            open_field_rainfed: 1.5,
            open_field_irrigated: 2.2,
            greenhouse: 3.5,
            polytunnel: 2.8
        }
    },
    beans: {
        name: "Beans",
        spacingMeters: 0.3, // 30cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 3,
        fertilizer: {
            open_field_rainfed: 100, // Lower because beans fix nitrogen
            open_field_irrigated: 130,
            greenhouse: 160,
            polytunnel: 145
        },
        manure: {
            open_field_rainfed: 8000,
            open_field_irrigated: 12000,
            greenhouse: 15000,
            polytunnel: 13000
        },
        waterPerWeek: {
            open_field_rainfed: 0,
            open_field_irrigated: 12,
            greenhouse: 15,
            polytunnel: 14
        },
        yieldPerPlant: {
            open_field_rainfed: 0.5,
            open_field_irrigated: 0.8,
            greenhouse: 1.2,
            polytunnel: 1.0
        }
    },
    cabbage: {
        name: "Cabbage",
        spacingMeters: 0.45, // 45cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 300,
        fertilizer: {
            open_field_rainfed: 160,
            open_field_irrigated: 200,
            greenhouse: 240,
            polytunnel: 220
        },
        manure: {
            open_field_rainfed: 14000,
            open_field_irrigated: 18000,
            greenhouse: 22000,
            polytunnel: 20000
        },
        waterPerWeek: {
            open_field_rainfed: 0,
            open_field_irrigated: 18,
            greenhouse: 22,
            polytunnel: 20
        },
        yieldPerPlant: {
            open_field_rainfed: 1.2,
            open_field_irrigated: 1.8,
            greenhouse: 2.5,
            polytunnel: 2.2
        }
    },
    onion: {
        name: "Onion",
        spacingMeters: 0.15, // 15cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 300,
        fertilizer: {
            open_field_rainfed: 120,
            open_field_irrigated: 160,
            greenhouse: 200,
            polytunnel: 180
        },
        manure: {
            open_field_rainfed: 10000,
            open_field_irrigated: 14000,
            greenhouse: 18000,
            polytunnel: 16000
        },
        waterPerWeek: {
            open_field_rainfed: 0,
            open_field_irrigated: 8,
            greenhouse: 12,
            polytunnel: 10
        },
        yieldPerPlant: {
            open_field_rainfed: 0.3,
            open_field_irrigated: 0.5,
            greenhouse: 0.7,
            polytunnel: 0.6
        }
    }
};

// Daily Task Calendar for each crop (day-by-day farming guide)
export const CROP_TASK_CALENDAR = {
    tomato: {
        name: "Tomato (Open Field, Irrigated)",
        totalDays: 90,
        tasks: [
            { day: 1, task: "Clear land and remove all weeds", category: "preparation", priority: "high" },
            { day: 2, task: "Prepare nursery bed (1m x 3m for 100 seedlings)", category: "preparation", priority: "high" },
            { day: 3, task: "Apply compost to nursery bed and mix well", category: "preparation", priority: "medium" },
            { day: 4, task: "Sow tomato seeds in nursery bed (0.5cm deep)", category: "planting", priority: "high" },
            { day: 5, task: "Water nursery gently and cover with grass mulch", category: "watering", priority: "high" },
            { day: 7, task: "Check for seed germination and remove mulch", category: "monitoring", priority: "medium" },
            { day: 10, task: "Begin daily watering of nursery (morning and evening)", category: "watering", priority: "high" },
            { day: 15, task: "Start hardening seedlings - reduce watering frequency", category: "preparation", priority: "medium" },
            { day: 18, task: "Prepare main field - plow and make ridges", category: "preparation", priority: "high" },
            { day: 20, task: "Apply manure to main field (20 tons per hectare)", category: "fertilization", priority: "high" },
            { day: 22, task: "Transplant seedlings to main field (60cm spacing)", category: "planting", priority: "high" },
            { day: 24, task: "Water transplanted seedlings immediately", category: "watering", priority: "high" },
            { day: 28, task: "Replace any dead seedlings with healthy ones", category: "maintenance", priority: "medium" },
            { day: 30, task: "Apply first NPK fertilizer (200kg per hectare)", category: "fertilization", priority: "high" },
            { day: 35, task: "First weeding around plants", category: "maintenance", priority: "high" },
            { day: 40, task: "Install stakes for plant support", category: "maintenance", priority: "high" },
            { day: 45, task: "Tie plants to stakes and remove side shoots", category: "maintenance", priority: "medium" },
            { day: 50, task: "Monitor for pests (aphids, whiteflies) and spray if needed", category: "pest_control", priority: "medium" },
            { day: 55, task: "Second weeding and earthing up", category: "maintenance", priority: "high" },
            { day: 60, task: "Apply second NPK fertilizer dose", category: "fertilization", priority: "high" },
            { day: 65, task: "Check for diseases (blight, wilt) and treat", category: "disease_control", priority: "medium" },
            { day: 70, task: "Flowers appear - ensure adequate watering", category: "watering", priority: "high" },
            { day: 75, task: "First fruits set - begin weekly harvesting", category: "harvesting", priority: "high" },
            { day: 80, task: "Continue harvesting ripe tomatoes", category: "harvesting", priority: "high" },
            { day: 85, task: "Peak harvest period - harvest every 2-3 days", category: "harvesting", priority: "high" },
            { day: 90, task: "Final harvest and field cleanup", category: "harvesting", priority: "medium" }
        ]
    },
    maize: {
        name: "Maize (Corn)",
        totalDays: 120,
        tasks: [
            { day: 1, task: "Clear land and remove all weeds and crop residues", category: "preparation", priority: "high" },
            { day: 2, task: "Deep plowing of field (20-25cm depth)", category: "preparation", priority: "high" },
            { day: 3, task: "Apply farmyard manure (10-15 tons per hectare)", category: "fertilization", priority: "high" },
            { day: 4, task: "Prepare planting rows 75cm apart", category: "preparation", priority: "high" },
            { day: 5, task: "Plant maize seeds 25cm apart, 3cm deep", category: "planting", priority: "high" },
            { day: 7, task: "Light watering if no rain (avoid waterlogging)", category: "watering", priority: "medium" },
            { day: 10, task: "Check for seed germination and replant gaps", category: "monitoring", priority: "medium" },
            { day: 14, task: "First weeding when plants are 15cm tall", category: "maintenance", priority: "high" },
            { day: 18, task: "Thin plants to one strong plant per hole", category: "maintenance", priority: "medium" },
            { day: 21, task: "Apply first NPK fertilizer (150kg per hectare)", category: "fertilization", priority: "high" },
            { day: 28, task: "Monitor for cutworms and treat if present", category: "pest_control", priority: "medium" },
            { day: 35, task: "Second weeding and earthing up around plants", category: "maintenance", priority: "high" },
            { day: 42, task: "Apply urea top dressing (50kg per hectare)", category: "fertilization", priority: "high" },
            { day: 50, task: "Monitor for stalk borer and spray if needed", category: "pest_control", priority: "medium" },
            { day: 60, task: "Check for leaf diseases and treat accordingly", category: "disease_control", priority: "medium" },
            { day: 70, task: "Tasseling stage - ensure adequate water", category: "monitoring", priority: "high" },
            { day: 80, task: "Silk emergence - critical pollination period", category: "monitoring", priority: "high" },
            { day: 90, task: "Grain filling stage - maintain soil moisture", category: "watering", priority: "high" },
            { day: 100, task: "Monitor for corn borer and armyworm", category: "pest_control", priority: "medium" },
            { day: 110, task: "Check grain maturity - kernels should dent", category: "monitoring", priority: "high" },
            { day: 120, task: "Harvest when moisture content is 20-25%", category: "harvesting", priority: "high" }
        ]
    },
    pepper: {
        name: "Pepper",
        totalDays: 85,
        tasks: [
            { day: 1, task: "Prepare nursery bed for pepper seedlings", category: "preparation", priority: "high" },
            { day: 2, task: "Sow pepper seeds in nursery (1cm deep)", category: "planting", priority: "high" },
            { day: 5, task: "Water nursery bed gently twice daily", category: "watering", priority: "high" },
            { day: 10, task: "Check for seed germination (7-14 days)", category: "monitoring", priority: "medium" },
            { day: 15, task: "Begin hardening seedlings gradually", category: "preparation", priority: "medium" },
            { day: 20, task: "Prepare main field with organic matter", category: "preparation", priority: "high" },
            { day: 25, task: "Transplant seedlings (50cm x 50cm spacing)", category: "planting", priority: "high" },
            { day: 27, task: "Water transplanted seedlings thoroughly", category: "watering", priority: "high" },
            { day: 30, task: "Apply first fertilizer application", category: "fertilization", priority: "high" },
            { day: 35, task: "First cultivation and weeding", category: "maintenance", priority: "high" },
            { day: 40, task: "Monitor for aphids and thrips", category: "pest_control", priority: "medium" },
            { day: 45, task: "Apply mulch around plants", category: "maintenance", priority: "medium" },
            { day: 50, task: "Second fertilizer application", category: "fertilization", priority: "high" },
            { day: 55, task: "Monitor for bacterial spot disease", category: "disease_control", priority: "medium" },
            { day: 60, task: "Flowering stage - ensure adequate water", category: "watering", priority: "high" },
            { day: 65, task: "First pepper fruits appear", category: "monitoring", priority: "medium" },
            { day: 70, task: "Begin regular harvesting of mature peppers", category: "harvesting", priority: "high" },
            { day: 75, task: "Continue harvesting every 3-4 days", category: "harvesting", priority: "high" },
            { day: 80, task: "Peak harvest period", category: "harvesting", priority: "high" },
            { day: 85, task: "Final harvest and field cleanup", category: "harvesting", priority: "medium" }
        ]
    }
};

// Unit conversion constants
export const UNIT_CONVERSIONS = {
    acres: 4047, // square meters per acre
    hectares: 10000, // square meters per hectare
    sqmeters: 1, // square meters per square meter
    plots: 464.5 // square meters per plot (50x100 ft = 464.5 sq meters)
};