import express from 'express';
import { storage } from './storage';

const router = express.Router();

// ===========================
// USER REGISTRATION & AUTH ROUTES
// ===========================

// Register new user
router.post('/api/auth/register', async (req, res) => {
    try {
        const { username, email, fullName, phoneNumber, location, farmSize, experienceLevel } = req.body;
        
        // Check if user already exists
        const existingUser = await storage.getUserByUsername(username);
        if (existingUser) {
            return res.status(400).json({ error: 'Username already exists' });
        }

        // Create new user
        const newUser = await storage.createUser({
            username,
            email,
            fullName,
            phoneNumber,
            location,
            farmSize,
            experienceLevel
        });

        res.status(201).json({ 
            message: 'User registered successfully', 
            user: { id: newUser.id, username: newUser.username, fullName: newUser.fullName }
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Failed to register user' });
    }
});

// Simple login (check if user exists)
router.post('/api/auth/login', async (req, res) => {
    try {
        const { username } = req.body;
        
        const user = await storage.getUserByUsername(username);
        if (!user) {
            return res.status(401).json({ error: 'User not found' });
        }

        res.json({ 
            message: 'Login successful', 
            user: { 
                id: user.id, 
                username: user.username, 
                fullName: user.fullName,
                farmSize: user.farmSize,
                experienceLevel: user.experienceLevel
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Failed to login' });
    }
});

// ===========================
// FARM CALCULATION ROUTES
// ===========================

// Save farm calculation
router.post('/api/calculations', async (req, res) => {
    try {
        const { 
            userId, 
            landSize, 
            landUnit, 
            cropType, 
            plantingStyle, 
            plantsNeeded, 
            expectedYield, 
            fertilizerRequired, 
            manureRequired, 
            waterRequired 
        } = req.body;

        const calculation = await storage.saveFarmCalculation({
            userId,
            landSize: parseFloat(landSize),
            landUnit,
            cropType,
            plantingStyle,
            plantsNeeded: parseInt(plantsNeeded),
            expectedYield: parseFloat(expectedYield),
            fertilizerRequired: parseFloat(fertilizerRequired),
            manureRequired: parseFloat(manureRequired),
            waterRequired: waterRequired ? parseFloat(waterRequired) : null
        });

        res.status(201).json({ 
            message: 'Calculation saved successfully', 
            calculation 
        });
    } catch (error) {
        console.error('Save calculation error:', error);
        res.status(500).json({ error: 'Failed to save calculation' });
    }
});

// Get user's calculation history
router.get('/api/calculations/:userId', async (req, res) => {
    try {
        const userId = parseInt(req.params.userId);
        const calculations = await storage.getFarmCalculations(userId);
        
        res.json(calculations);
    } catch (error) {
        console.error('Get calculations error:', error);
        res.status(500).json({ error: 'Failed to fetch calculations' });
    }
});

// ===========================
// TASK PROGRESS ROUTES
// ===========================

// Save task progress (when tasks are generated)
router.post('/api/tasks', async (req, res) => {
    try {
        const tasks = req.body.tasks; // Array of tasks
        const savedTasks = [];

        for (const task of tasks) {
            const savedTask = await storage.saveTaskProgress({
                userId: task.userId,
                farmCalculationId: task.farmCalculationId,
                cropType: task.cropType,
                taskDay: task.taskDay,
                taskDescription: task.taskDescription,
                taskCategory: task.taskCategory,
                priority: task.priority,
                dueDate: task.dueDate
            });
            savedTasks.push(savedTask);
        }

        res.status(201).json({ 
            message: 'Tasks saved successfully', 
            tasks: savedTasks 
        });
    } catch (error) {
        console.error('Save tasks error:', error);
        res.status(500).json({ error: 'Failed to save tasks' });
    }
});

// Get user's tasks
router.get('/api/tasks/:userId', async (req, res) => {
    try {
        const userId = parseInt(req.params.userId);
        const farmCalculationId = req.query.farmCalculationId ? parseInt(req.query.farmCalculationId as string) : undefined;
        
        const tasks = await storage.getTaskProgress(userId, farmCalculationId);
        
        res.json(tasks);
    } catch (error) {
        console.error('Get tasks error:', error);
        res.status(500).json({ error: 'Failed to fetch tasks' });
    }
});

// Mark task as completed
router.patch('/api/tasks/:taskId/complete', async (req, res) => {
    try {
        const taskId = parseInt(req.params.taskId);
        const { notes } = req.body;
        
        const updatedTask = await storage.markTaskCompleted(taskId, notes);
        
        if (!updatedTask) {
            return res.status(404).json({ error: 'Task not found' });
        }
        
        res.json({ 
            message: 'Task marked as completed', 
            task: updatedTask 
        });
    } catch (error) {
        console.error('Complete task error:', error);
        res.status(500).json({ error: 'Failed to mark task as completed' });
    }
});

// Update task progress
router.patch('/api/tasks/:taskId', async (req, res) => {
    try {
        const taskId = parseInt(req.params.taskId);
        const updates = req.body;
        
        const updatedTask = await storage.updateTaskProgress(taskId, updates);
        
        if (!updatedTask) {
            return res.status(404).json({ error: 'Task not found' });
        }
        
        res.json({ 
            message: 'Task updated successfully', 
            task: updatedTask 
        });
    } catch (error) {
        console.error('Update task error:', error);
        res.status(500).json({ error: 'Failed to update task' });
    }
});

// ===========================
// CROPS & PLANTING STYLES ROUTES
// ===========================

// Get all crops
router.get('/api/crops', async (req, res) => {
    try {
        const crops = await storage.getCrops();
        res.json(crops);
    } catch (error) {
        console.error('Get crops error:', error);
        res.status(500).json({ error: 'Failed to fetch crops' });
    }
});

// Get planting styles for a crop
router.get('/api/crops/:cropId/planting-styles', async (req, res) => {
    try {
        const cropId = parseInt(req.params.cropId);
        const plantingStyles = await storage.getPlantingStyles(cropId);
        res.json(plantingStyles);
    } catch (error) {
        console.error('Get planting styles error:', error);
        res.status(500).json({ error: 'Failed to fetch planting styles' });
    }
});

export default router;