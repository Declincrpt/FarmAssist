import { 
    users, 
    farmCalculations, 
    taskProgress, 
    crops, 
    plantingStyles,
    type User,
    type FarmCalculation,
    type TaskProgress,
    type Crop,
    type PlantingStyle
} from "../shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
    // User operations
    getUser(id: number): Promise<User | undefined>;
    getUserByUsername(username: string): Promise<User | undefined>;
    createUser(userData: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): Promise<User>;
    updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;

    // Farm calculation operations
    saveFarmCalculation(calculationData: Omit<FarmCalculation, 'id' | 'createdAt'>): Promise<FarmCalculation>;
    getFarmCalculations(userId: number): Promise<FarmCalculation[]>;
    getFarmCalculation(id: number): Promise<FarmCalculation | undefined>;

    // Task progress operations
    saveTaskProgress(taskData: Omit<TaskProgress, 'id' | 'createdAt'>): Promise<TaskProgress>;
    getTaskProgress(userId: number, farmCalculationId?: number): Promise<TaskProgress[]>;
    updateTaskProgress(id: number, updates: Partial<TaskProgress>): Promise<TaskProgress | undefined>;
    markTaskCompleted(id: number, notes?: string): Promise<TaskProgress | undefined>;

    // Crop and planting style operations
    getCrops(): Promise<Crop[]>;
    getPlantingStyles(cropId: number): Promise<PlantingStyle[]>;
}

export class DatabaseStorage implements IStorage {
    // User operations
    async getUser(id: number): Promise<User | undefined> {
        const [user] = await db.select().from(users).where(eq(users.id, id));
        return user;
    }

    async getUserByUsername(username: string): Promise<User | undefined> {
        const [user] = await db.select().from(users).where(eq(users.username, username));
        return user;
    }

    async createUser(userData: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): Promise<User> {
        const [user] = await db
            .insert(users)
            .values({
                ...userData,
                createdAt: new Date(),
                updatedAt: new Date()
            })
            .returning();
        return user;
    }

    async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
        const [user] = await db
            .update(users)
            .set({
                ...userData,
                updatedAt: new Date()
            })
            .where(eq(users.id, id))
            .returning();
        return user;
    }

    // Farm calculation operations
    async saveFarmCalculation(calculationData: Omit<FarmCalculation, 'id' | 'createdAt'>): Promise<FarmCalculation> {
        const [calculation] = await db
            .insert(farmCalculations)
            .values({
                ...calculationData,
                createdAt: new Date()
            })
            .returning();
        return calculation;
    }

    async getFarmCalculations(userId: number): Promise<FarmCalculation[]> {
        return await db
            .select()
            .from(farmCalculations)
            .where(eq(farmCalculations.userId, userId))
            .orderBy(desc(farmCalculations.createdAt));
    }

    async getFarmCalculation(id: number): Promise<FarmCalculation | undefined> {
        const [calculation] = await db
            .select()
            .from(farmCalculations)
            .where(eq(farmCalculations.id, id));
        return calculation;
    }

    // Task progress operations
    async saveTaskProgress(taskData: Omit<TaskProgress, 'id' | 'createdAt'>): Promise<TaskProgress> {
        const [task] = await db
            .insert(taskProgress)
            .values({
                ...taskData,
                createdAt: new Date()
            })
            .returning();
        return task;
    }

    async getTaskProgress(userId: number, farmCalculationId?: number): Promise<TaskProgress[]> {
        let query = db
            .select()
            .from(taskProgress)
            .where(eq(taskProgress.userId, userId));

        if (farmCalculationId) {
            return await db
                .select()
                .from(taskProgress)
                .where(and(
                    eq(taskProgress.userId, userId),
                    eq(taskProgress.farmCalculationId, farmCalculationId)
                ))
                .orderBy(taskProgress.taskDay);
        }

        return await query.orderBy(taskProgress.taskDay);
    }

    async updateTaskProgress(id: number, updates: Partial<TaskProgress>): Promise<TaskProgress | undefined> {
        const [task] = await db
            .update(taskProgress)
            .set(updates)
            .where(eq(taskProgress.id, id))
            .returning();
        return task;
    }

    async markTaskCompleted(id: number, notes?: string): Promise<TaskProgress | undefined> {
        const [task] = await db
            .update(taskProgress)
            .set({
                isCompleted: true,
                completedAt: new Date(),
                notes: notes || null
            })
            .where(eq(taskProgress.id, id))
            .returning();
        return task;
    }

    // Crop and planting style operations
    async getCrops(): Promise<Crop[]> {
        return await db
            .select()
            .from(crops)
            .where(eq(crops.isActive, true))
            .orderBy(crops.name);
    }

    async getPlantingStyles(cropId: number): Promise<PlantingStyle[]> {
        return await db
            .select()
            .from(plantingStyles)
            .where(and(
                eq(plantingStyles.cropId, cropId),
                eq(plantingStyles.isActive, true)
            ));
    }
}

export const storage = new DatabaseStorage();