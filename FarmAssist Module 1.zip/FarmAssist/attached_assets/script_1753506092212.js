/**
 * FarmAssist Crop - Smart Planting Calculator
 * A mobile-friendly web app for farmers to calculate planting requirements and yields
 */

// Static crop database with realistic farming data
const CROP_DATABASE = {
    tomato: {
        name: "Tomato",
        spacingMeters: 0.6, // 60cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 300,
        fertilizer: {
            open_field_rainfed: 200, // kg per hectare
            open_field_irrigated: 250,
            greenhouse: 300,
            polytunnel: 275
        },
        manure: {
            open_field_rainfed: 15000, // kg per hectare
            open_field_irrigated: 20000,
            greenhouse: 25000,
            polytunnel: 22000
        },
        waterPerWeek: {
            open_field_rainfed: 0, // liters per plant per week
            open_field_irrigated: 25,
            greenhouse: 30,
            polytunnel: 28
        },
        yieldPerPlant: {
            open_field_rainfed: 3, // kg per plant
            open_field_irrigated: 5,
            greenhouse: 8,
            polytunnel: 6
        }
    },
    maize: {
        name: "Maize (Corn)",
        spacingMeters: 0.75, // 75cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 3,
        fertilizer: {
            open_field_rainfed: 150,
            open_field_irrigated: 200,
            greenhouse: 250,
            polytunnel: 225
        },
        manure: {
            open_field_rainfed: 10000,
            open_field_irrigated: 15000,
            greenhouse: 20000,
            polytunnel: 18000
        },
        waterPerWeek: {
            open_field_rainfed: 0,
            open_field_irrigated: 20,
            greenhouse: 25,
            polytunnel: 22
        },
        yieldPerPlant: {
            open_field_rainfed: 0.8,
            open_field_irrigated: 1.2,
            greenhouse: 1.8,
            polytunnel: 1.5
        }
    },
    pepper: {
        name: "Pepper",
        spacingMeters: 0.5, // 50cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 150,
        fertilizer: {
            open_field_rainfed: 180,
            open_field_irrigated: 220,
            greenhouse: 280,
            polytunnel: 250
        },
        manure: {
            open_field_rainfed: 12000,
            open_field_irrigated: 18000,
            greenhouse: 23000,
            polytunnel: 20000
        },
        waterPerWeek: {
            open_field_rainfed: 0,
            open_field_irrigated: 15,
            greenhouse: 20,
            polytunnel: 18
        },
        yieldPerPlant: {
            open_field_rainfed: 1.5,
            open_field_irrigated: 2.2,
            greenhouse: 3.5,
            polytunnel: 2.8
        }
    },
    beans: {
        name: "Beans",
        spacingMeters: 0.3, // 30cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 3,
        fertilizer: {
            open_field_rainfed: 100, // Lower because beans fix nitrogen
            open_field_irrigated: 130,
            greenhouse: 160,
            polytunnel: 145
        },
        manure: {
            open_field_rainfed: 8000,
            open_field_irrigated: 12000,
            greenhouse: 15000,
            polytunnel: 13000
        },
        waterPerWeek: {
            open_field_rainfed: 0,
            open_field_irrigated: 12,
            greenhouse: 15,
            polytunnel: 14
        },
        yieldPerPlant: {
            open_field_rainfed: 0.5,
            open_field_irrigated: 0.8,
            greenhouse: 1.2,
            polytunnel: 1.0
        }
    },
    cabbage: {
        name: "Cabbage",
        spacingMeters: 0.45, // 45cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 300,
        fertilizer: {
            open_field_rainfed: 160,
            open_field_irrigated: 200,
            greenhouse: 240,
            polytunnel: 220
        },
        manure: {
            open_field_rainfed: 14000,
            open_field_irrigated: 18000,
            greenhouse: 22000,
            polytunnel: 20000
        },
        waterPerWeek: {
            open_field_rainfed: 0,
            open_field_irrigated: 18,
            greenhouse: 22,
            polytunnel: 20
        },
        yieldPerPlant: {
            open_field_rainfed: 1.2,
            open_field_irrigated: 1.8,
            greenhouse: 2.5,
            polytunnel: 2.2
        }
    },
    onion: {
        name: "Onion",
        spacingMeters: 0.15, // 15cm between plants
        seedsPerPlant: 1,
        seedsPerGram: 300,
        fertilizer: {
            open_field_rainfed: 120,
            open_field_irrigated: 160,
            greenhouse: 200,
            polytunnel: 180
        },
        manure: {
            open_field_rainfed: 10000,
            open_field_irrigated: 14000,
            greenhouse: 18000,
            polytunnel: 16000
        },
        waterPerWeek: {
            open_field_rainfed: 0,
            open_field_irrigated: 8,
            greenhouse: 12,
            polytunnel: 10
        },
        yieldPerPlant: {
            open_field_rainfed: 0.3,
            open_field_irrigated: 0.5,
            greenhouse: 0.7,
            polytunnel: 0.6
        }
    }
};

// Daily Task Calendar for each crop (day-by-day farming guide)
const CROP_TASK_CALENDAR = {
    tomato: {
        name: "Tomato (Open Field, Irrigated)",
        totalDays: 90,
        tasks: [
            { day: 1, task: "Clear land and remove all weeds", category: "preparation", priority: "high" },
            { day: 2, task: "Prepare nursery bed (1m x 3m for 100 seedlings)", category: "preparation", priority: "high" },
            { day: 3, task: "Apply compost to nursery bed and mix well", category: "preparation", priority: "medium" },
            { day: 4, task: "Sow tomato seeds in nursery bed (0.5cm deep)", category: "planting", priority: "high" },
            { day: 5, task: "Water nursery gently and cover with grass mulch", category: "watering", priority: "high" },
            { day: 7, task: "Check for seed germination and remove mulch", category: "monitoring", priority: "medium" },
            { day: 10, task: "Begin daily watering of nursery (morning and evening)", category: "watering", priority: "high" },
            { day: 15, task: "Start hardening seedlings - reduce watering frequency", category: "preparation", priority: "medium" },
            { day: 18, task: "Prepare main field - plow and make ridges", category: "preparation", priority: "high" },
            { day: 20, task: "Apply manure to main field (20 tons per hectare)", category: "fertilization", priority: "high" },
            { day: 22, task: "Transplant seedlings to main field (60cm spacing)", category: "planting", priority: "high" },
            { day: 24, task: "Water transplanted seedlings immediately", category: "watering", priority: "high" },
            { day: 28, task: "Replace any dead seedlings with healthy ones", category: "maintenance", priority: "medium" },
            { day: 30, task: "Apply first NPK fertilizer (200kg per hectare)", category: "fertilization", priority: "high" },
            { day: 35, task: "First weeding around plants", category: "maintenance", priority: "high" },
            { day: 40, task: "Install stakes for plant support", category: "maintenance", priority: "high" },
            { day: 45, task: "Tie plants to stakes and remove side shoots", category: "maintenance", priority: "medium" },
            { day: 50, task: "Monitor for pests (aphids, whiteflies) and spray if needed", category: "pest_control", priority: "medium" },
            { day: 55, task: "Second weeding and earthing up", category: "maintenance", priority: "high" },
            { day: 60, task: "Apply second NPK fertilizer dose", category: "fertilization", priority: "high" },
            { day: 65, task: "Check for diseases (blight, wilt) and treat", category: "disease_control", priority: "medium" },
            { day: 70, task: "Flowers appear - ensure adequate watering", category: "watering", priority: "high" },
            { day: 75, task: "First fruits set - begin weekly harvesting", category: "harvesting", priority: "high" },
            { day: 80, task: "Continue harvesting ripe tomatoes", category: "harvesting", priority: "high" },
            { day: 85, task: "Peak harvest period - harvest every 2-3 days", category: "harvesting", priority: "high" },
            { day: 90, task: "Final harvest and field cleanup", category: "harvesting", priority: "medium" }
        ]
    },
    maize: {
        name: "Maize (Corn)",
        totalDays: 120,
        tasks: [
            { day: 1, task: "Clear land and remove all weeds and crop residues", category: "preparation", priority: "high" },
            { day: 2, task: "Deep plowing of field (20-25cm depth)", category: "preparation", priority: "high" },
            { day: 3, task: "Apply farmyard manure (10-15 tons per hectare)", category: "fertilization", priority: "high" },
            { day: 4, task: "Prepare planting rows 75cm apart", category: "preparation", priority: "high" },
            { day: 5, task: "Plant maize seeds 25cm apart, 3cm deep", category: "planting", priority: "high" },
            { day: 7, task: "Light watering if no rain (avoid waterlogging)", category: "watering", priority: "medium" },
            { day: 10, task: "Check for seed germination and replant gaps", category: "monitoring", priority: "medium" },
            { day: 14, task: "First weeding when plants are 15cm tall", category: "maintenance", priority: "high" },
            { day: 18, task: "Thin plants to one strong plant per hole", category: "maintenance", priority: "medium" },
            { day: 21, task: "Apply first NPK fertilizer (150kg per hectare)", category: "fertilization", priority: "high" },
            { day: 28, task: "Monitor for cutworms and treat if present", category: "pest_control", priority: "medium" },
            { day: 35, task: "Second weeding and earthing up around plants", category: "maintenance", priority: "high" },
            { day: 42, task: "Apply urea top dressing (50kg per hectare)", category: "fertilization", priority: "high" },
            { day: 50, task: "Monitor for stalk borer and spray if needed", category: "pest_control", priority: "medium" },
            { day: 60, task: "Check for leaf diseases and treat accordingly", category: "disease_control", priority: "medium" },
            { day: 70, task: "Tasseling stage - ensure adequate water", category: "monitoring", priority: "high" },
            { day: 80, task: "Silking stage - critical watering period", category: "watering", priority: "high" },
            { day: 90, task: "Grain filling stage - reduce watering gradually", category: "watering", priority: "medium" },
            { day: 100, task: "Monitor grain development and dryness", category: "monitoring", priority: "medium" },
            { day: 110, task: "Test grain moisture content for harvest readiness", category: "monitoring", priority: "high" },
            { day: 120, task: "Harvest when grain moisture is 18-20%", category: "harvesting", priority: "high" }
        ]
    },
    pepper: {
        name: "Pepper",
        totalDays: 100,
        tasks: [
            { day: 1, task: "Land preparation and clearing of weeds", category: "preparation", priority: "high" },
            { day: 2, task: "Construct raised nursery bed (1m x 4m)", category: "preparation", priority: "high" },
            { day: 3, task: "Mix nursery soil with compost (2:1 ratio)", category: "preparation", priority: "medium" },
            { day: 4, task: "Sow pepper seeds in nursery (1cm deep)", category: "planting", priority: "high" },
            { day: 6, task: "Water nursery gently twice daily", category: "watering", priority: "high" },
            { day: 10, task: "Check for germination (should be 80%+)", category: "monitoring", priority: "medium" },
            { day: 14, task: "Thin weak seedlings, keep strongest ones", category: "maintenance", priority: "medium" },
            { day: 21, task: "Begin hardening seedlings - reduce watering", category: "preparation", priority: "medium" },
            { day: 24, task: "Prepare main field with ridges 60cm apart", category: "preparation", priority: "high" },
            { day: 25, task: "Apply compost to main field (15 tons per hectare)", category: "fertilization", priority: "high" },
            { day: 28, task: "Transplant seedlings 50cm apart on ridges", category: "planting", priority: "high" },
            { day: 30, task: "Water transplanted seedlings thoroughly", category: "watering", priority: "high" },
            { day: 35, task: "Apply first NPK fertilizer (180kg per hectare)", category: "fertilization", priority: "high" },
            { day: 38, task: "Monitor for thrips and whiteflies", category: "pest_control", priority: "medium" },
            { day: 42, task: "First weeding and mulching around plants", category: "maintenance", priority: "high" },
            { day: 50, task: "Apply organic mulch to retain moisture", category: "maintenance", priority: "medium" },
            { day: 55, task: "Spray against aphids if present", category: "pest_control", priority: "medium" },
            { day: 60, task: "Apply second fertilizer dose", category: "fertilization", priority: "high" },
            { day: 65, task: "Support plants with small stakes if needed", category: "maintenance", priority: "low" },
            { day: 70, task: "Monitor for bacterial wilt disease", category: "disease_control", priority: "medium" },
            { day: 75, task: "First flowers appear - ensure consistent watering", category: "watering", priority: "high" },
            { day: 80, task: "Fruit set begins - reduce nitrogen fertilizer", category: "monitoring", priority: "medium" },
            { day: 85, task: "Begin harvesting green peppers", category: "harvesting", priority: "high" },
            { day: 90, task: "Continue regular harvesting every 3-4 days", category: "harvesting", priority: "high" },
            { day: 95, task: "Peak harvest period - daily picking", category: "harvesting", priority: "high" },
            { day: 100, task: "Final harvest and field preparation for next crop", category: "harvesting", priority: "medium" }
        ]
    }
};

// Extension Intelligence Engine - Expert farming tips by crop and day
const EXTENSION_TIPS = {
    tomato: {
        name: "Tomato Expert Tips",
        tips: [
            { 
                day: 1, 
                tip: "Clear the land thoroughly. Avoid replanting where tomatoes grew last season to reduce disease risk. Rotate with legumes or cereals.", 
                category: "preparation",
                expertise_level: "critical"
            },
            { 
                day: 2, 
                tip: "Use well-draining soil for nursery. Mix garden soil with compost (2:1 ratio) and ensure good drainage to prevent damping-off disease.", 
                category: "preparation",
                expertise_level: "important"
            },
            { 
                day: 4, 
                tip: "Sow seeds 0.5cm deep only. Deeper planting reduces germination rate. Cover lightly with fine soil or compost.", 
                category: "planting",
                expertise_level: "critical"
            },
            { 
                day: 7, 
                tip: "Germination should occur within 5-7 days. If poor, check soil moisture and temperature (optimal 20-25°C).", 
                category: "monitoring",
                expertise_level: "important"
            },
            { 
                day: 15, 
                tip: "Start hardening seedlings by reducing watering frequency and exposing to morning sun for 2-3 hours daily.", 
                category: "preparation",
                expertise_level: "important"
            },
            { 
                day: 20, 
                tip: "Apply well-decomposed manure before transplanting. Fresh manure can burn roots and attract pests.", 
                category: "fertilization",
                expertise_level: "critical"
            },
            { 
                day: 22, 
                tip: "Transplant in the evening or on cloudy days to reduce heat stress. Water immediately after transplanting.", 
                category: "planting",
                expertise_level: "critical"
            },
            { 
                day: 30, 
                tip: "Apply fertilizer early in the morning before watering. NPK 17:17:17 is ideal for vegetative growth stage.", 
                category: "fertilization",
                expertise_level: "important"
            },
            { 
                day: 35, 
                tip: "Weed carefully to avoid damaging shallow roots. Mulch around plants to suppress weeds and retain moisture.", 
                category: "maintenance",
                expertise_level: "important"
            },
            { 
                day: 40, 
                tip: "Install stakes now before plants get too large. Use 1.5-2m wooden or bamboo stakes driven 30cm deep.", 
                category: "maintenance",
                expertise_level: "critical"
            },
            { 
                day: 45, 
                tip: "Tie plants loosely with soft material. Remove suckers (side shoots) to channel energy to main stem and fruits.", 
                category: "maintenance",
                expertise_level: "important"
            },
            { 
                day: 50, 
                tip: "Monitor for early blight (brown spots on leaves). Remove affected leaves and improve air circulation between plants.", 
                category: "disease_control",
                expertise_level: "critical"
            },
            { 
                day: 60, 
                tip: "Watch for blight and bacterial wilt. Remove infected leaves immediately and spray neem oil or approved fungicide.", 
                category: "disease_control",
                expertise_level: "critical"
            },
            { 
                day: 70, 
                tip: "Flowering stage - ensure consistent watering but avoid wetting leaves. Water stress now reduces fruit set.", 
                category: "watering",
                expertise_level: "critical"
            },
            { 
                day: 75, 
                tip: "First fruits setting - reduce nitrogen fertilizer and increase potassium for better fruit quality and disease resistance.", 
                category: "fertilization",
                expertise_level: "important"
            },
            { 
                day: 80, 
                tip: "Harvest when fruits show color change but are still firm. Morning harvest gives better shelf life.", 
                category: "harvesting",
                expertise_level: "important"
            }
        ]
    },
    maize: {
        name: "Maize Expert Tips",
        tips: [
            { 
                day: 1, 
                tip: "Clear land of all crop residues which harbor stem borer pests. Burn or compost old stalks away from new planting area.", 
                category: "preparation",
                expertise_level: "critical"
            },
            { 
                day: 2, 
                tip: "Deep plow to 20-25cm to break hardpans and improve water infiltration. Shallow plowing reduces yields significantly.", 
                category: "preparation",
                expertise_level: "critical"
            },
            { 
                day: 5, 
                tip: "Plant seeds 2-3cm deep only. Deeper planting delays emergence and weakens seedlings. Space 25cm apart in rows.", 
                category: "planting",
                expertise_level: "critical"
            },
            { 
                day: 7, 
                tip: "If no rain within 3 days of planting, apply light irrigation. Avoid waterlogging which causes seed rot.", 
                category: "watering",
                expertise_level: "important"
            },
            { 
                day: 10, 
                tip: "Check germination rate. Should be 80%+ within 7-10 days. Replant gaps immediately with pre-germinated seeds.", 
                category: "monitoring",
                expertise_level: "important"
            },
            { 
                day: 14, 
                tip: "First weeding when plants are 15cm tall. Weed when soil is slightly moist for easier removal.", 
                category: "maintenance",
                expertise_level: "critical"
            },
            { 
                day: 18, 
                tip: "Thin to one strong plant per hole. Keep the most vigorous seedling and remove weak ones to reduce competition.", 
                category: "maintenance",
                expertise_level: "important"
            },
            { 
                day: 21, 
                tip: "Apply first fertilizer dose (NPK 17:17:17) in bands 5cm from plants. Avoid direct contact with stems.", 
                category: "fertilization",
                expertise_level: "critical"
            },
            { 
                day: 28, 
                tip: "Scout for cutworms and army worms. Apply appropriate insecticide if damage exceeds 10% of plants.", 
                category: "pest_control",
                expertise_level: "important"
            },
            { 
                day: 35, 
                tip: "Second weeding and earthing up. Earth up soil around plants to support stems and cover exposed roots.", 
                category: "maintenance",
                expertise_level: "critical"
            },
            { 
                day: 42, 
                tip: "Apply urea top dressing (50kg/ha) as plants enter rapid growth phase. Apply before expected rain or irrigation.", 
                category: "fertilization",
                expertise_level: "critical"
            },
            { 
                day: 50, 
                tip: "Monitor for stem borer entry holes and frass (sawdust-like droppings). Apply recommended systemic insecticide.", 
                category: "pest_control",
                expertise_level: "critical"
            },
            { 
                day: 60, 
                tip: "Check for leaf diseases like blight and rust. Remove infected leaves and ensure good air circulation.", 
                category: "disease_control",
                expertise_level: "important"
            },
            { 
                day: 70, 
                tip: "Tasseling stage - critical water requirement period. Ensure adequate soil moisture for good pollen production.", 
                category: "watering",
                expertise_level: "critical"
            },
            { 
                day: 80, 
                tip: "Silking stage - most critical period for water. Water stress now drastically reduces grain formation.", 
                category: "watering",
                expertise_level: "critical"
            },
            { 
                day: 90, 
                tip: "Grain filling stage - gradually reduce watering frequency. Too much water now can cause lodging.", 
                category: "watering",
                expertise_level: "important"
            },
            { 
                day: 110, 
                tip: "Test grain moisture by pressing kernels with thumbnail. Harvest when moisture is 18-20% for good storage.", 
                category: "harvesting",
                expertise_level: "critical"
            }
        ]
    },
    pepper: {
        name: "Pepper Expert Tips",
        tips: [
            { 
                day: 1, 
                tip: "Prepare well-drained soil. Peppers are very sensitive to waterlogging. Raise beds if drainage is poor.", 
                category: "preparation",
                expertise_level: "critical"
            },
            { 
                day: 2, 
                tip: "Construct nursery bed 1m wide for easy management. Use 30cm height for good drainage and root development.", 
                category: "preparation",
                expertise_level: "important"
            },
            { 
                day: 4, 
                tip: "Sow seeds 1cm deep in well-prepared seedbed. Pepper seeds need consistent moisture and warmth (25-30°C) to germinate.", 
                category: "planting",
                expertise_level: "critical"
            },
            { 
                day: 6, 
                tip: "Water nursery gently twice daily - morning and evening. Use fine spray to avoid disturbing seeds.", 
                category: "watering",
                expertise_level: "important"
            },
            { 
                day: 10, 
                tip: "Expect 80%+ germination within 7-10 days. Poor germination indicates old seeds or incorrect soil temperature.", 
                category: "monitoring",
                expertise_level: "important"
            },
            { 
                day: 14, 
                tip: "Thin weak seedlings to give strong ones more space. Keep only the most vigorous plants for transplanting.", 
                category: "maintenance",
                expertise_level: "important"
            },
            { 
                day: 21, 
                tip: "Begin hardening process - reduce watering and expose seedlings to direct sunlight for increasing periods daily.", 
                category: "preparation",
                expertise_level: "important"
            },
            { 
                day: 25, 
                tip: "Apply well-decomposed compost to main field. Fresh manure can burn pepper roots and attract pests.", 
                category: "fertilization",
                expertise_level: "critical"
            },
            { 
                day: 28, 
                tip: "Transplant in late afternoon or evening. Handle seedlings by leaves, not stems, to avoid damage.", 
                category: "planting",
                expertise_level: "critical"
            },
            { 
                day: 35, 
                tip: "Apply balanced fertilizer (NPK 17:17:17) 5cm from plant base. Peppers need steady nutrition throughout growth.", 
                category: "fertilization",
                expertise_level: "important"
            },
            { 
                day: 38, 
                tip: "Monitor for thrips and whiteflies - major pepper pests. Use yellow sticky traps for early detection.", 
                category: "pest_control",
                expertise_level: "critical"
            },
            { 
                day: 42, 
                tip: "Mulch around plants with organic matter to conserve moisture and suppress weeds. Keep mulch away from stems.", 
                category: "maintenance",
                expertise_level: "important"
            },
            { 
                day: 50, 
                tip: "Apply thick organic mulch (grass, leaves) to maintain soil moisture. Peppers need consistent soil moisture.", 
                category: "maintenance",
                expertise_level: "important"
            },
            { 
                day: 55, 
                tip: "Scout for aphids on young shoots and flower buds. Spray neem oil or insecticidal soap if colonies found.", 
                category: "pest_control",
                expertise_level: "important"
            },
            { 
                day: 65, 
                tip: "Support heavily fruiting plants with small stakes to prevent branch breakage. Use soft ties to avoid stem damage.", 
                category: "maintenance",
                expertise_level: "important"
            },
            { 
                day: 70, 
                tip: "Monitor for bacterial wilt (sudden plant collapse). Remove affected plants immediately to prevent spread.", 
                category: "disease_control",
                expertise_level: "critical"
            },
            { 
                day: 75, 
                tip: "Flowering stage - ensure consistent but not excessive watering. Water stress reduces flower and fruit development.", 
                category: "watering",
                expertise_level: "critical"
            },
            { 
                day: 85, 
                tip: "Harvest peppers when they reach desired size and color. Regular picking encourages continued production.", 
                category: "harvesting",
                expertise_level: "important"
            },
            { 
                day: 90, 
                tip: "Peak harvest period - pick every 3-4 days to maintain plant productivity. Handle fruits gently to avoid bruising.", 
                category: "harvesting",
                expertise_level: "important"
            }
        ]
    },
    beans: {
        name: "Beans Expert Tips",
        tips: [
            { 
                day: 1, 
                tip: "Prepare well-drained soil. Beans are nitrogen-fixers but still need phosphorus and potassium for good nodulation.", 
                category: "preparation",
                expertise_level: "important"
            },
            { 
                day: 3, 
                tip: "Plant seeds 2-3cm deep, 15cm apart. Pre-soak seeds for 4-6 hours for faster germination.", 
                category: "planting",
                expertise_level: "important"
            },
            { 
                day: 7, 
                tip: "Check for germination. Beans typically germinate in 5-7 days. Replant any gaps immediately.", 
                category: "monitoring",
                expertise_level: "important"
            },
            { 
                day: 14, 
                tip: "First light weeding when plants are 10cm tall. Be gentle as bean roots are shallow and easily damaged.", 
                category: "maintenance",
                expertise_level: "important"
            },
            { 
                day: 21, 
                tip: "Apply phosphorus-rich fertilizer to encourage root nodule formation for nitrogen fixation.", 
                category: "fertilization",
                expertise_level: "important"
            },
            { 
                day: 30, 
                tip: "Check for aphids and bean fly. Early detection and treatment prevent major crop losses.", 
                category: "pest_control",
                expertise_level: "important"
            },
            { 
                day: 45, 
                tip: "Flowering stage - ensure adequate water but avoid waterlogging which reduces nodule activity.", 
                category: "watering",
                expertise_level: "critical"
            },
            { 
                day: 60, 
                tip: "Begin harvesting young pods for fresh consumption or wait longer for dry beans for storage.", 
                category: "harvesting",
                expertise_level: "important"
            }
        ]
    },
    cabbage: {
        name: "Cabbage Expert Tips", 
        tips: [
            { 
                day: 1, 
                tip: "Prepare rich, well-drained soil with pH 6.0-6.5. Cabbage needs fertile soil with good organic matter content.", 
                category: "preparation",
                expertise_level: "important"
            },
            { 
                day: 3, 
                tip: "Sow seeds 1cm deep in seedbed. Cabbage seeds need cool conditions (15-20°C) for optimal germination.", 
                category: "planting",
                expertise_level: "important"
            },
            { 
                day: 14, 
                tip: "Thin seedlings to strongest ones. Crowded seedlings become weak and susceptible to diseases.", 
                category: "maintenance",
                expertise_level: "important"
            },
            { 
                day: 25, 
                tip: "Transplant seedlings with 4-5 true leaves. Handle carefully as cabbage is sensitive to root disturbance.", 
                category: "planting",
                expertise_level: "critical"
            },
            { 
                day: 35, 
                tip: "Apply balanced fertilizer and ensure consistent watering. Cabbage needs steady moisture for head formation.", 
                category: "fertilization",
                expertise_level: "important"
            },
            { 
                day: 45, 
                tip: "Monitor for diamondback moth and cabbage worms. Use Bt (Bacillus thuringiensis) for organic control.", 
                category: "pest_control",
                expertise_level: "critical"
            },
            { 
                day: 60, 
                tip: "Head formation stage - maintain consistent moisture. Water stress causes poor head development or splitting.", 
                category: "watering",
                expertise_level: "critical"
            },
            { 
                day: 75, 
                tip: "Harvest when heads are firm and solid. Cut with sharp knife leaving outer leaves to protect remaining plants.", 
                category: "harvesting",
                expertise_level: "important"
            }
        ]
    },
    onion: {
        name: "Onion Expert Tips",
        tips: [
            { 
                day: 1, 
                tip: "Prepare fine, well-drained soil. Onions need loose soil as bulbs expand horizontally and vertically.", 
                category: "preparation",
                expertise_level: "important"
            },
            { 
                day: 3, 
                tip: "Sow seeds thinly, 1cm deep. Onion seeds have low germination rate, so sow extra for thinning later.", 
                category: "planting",
                expertise_level: "important"
            },
            { 
                day: 14, 
                tip: "Thin seedlings to 10cm spacing when pencil-thick. Crowded onions produce small bulbs.", 
                category: "maintenance",
                expertise_level: "critical"
            },
            { 
                day: 30, 
                tip: "Weed carefully as onions compete poorly with weeds. Hand weeding is best to avoid disturbing shallow roots.", 
                category: "maintenance",
                expertise_level: "critical"
            },
            { 
                day: 45, 
                tip: "Apply nitrogen fertilizer for leaf growth. Strong leaf growth early leads to larger bulb formation later.", 
                category: "fertilization",
                expertise_level: "important"
            },
            { 
                day: 60, 
                tip: "Reduce nitrogen and increase potassium as bulbs begin forming. This improves storage quality.", 
                category: "fertilization",
                expertise_level: "important"
            },
            { 
                day: 90, 
                tip: "Stop watering when tops begin yellowing and falling over. This signals bulb maturity.", 
                category: "watering",
                expertise_level: "critical"
            },
            { 
                day: 105, 
                tip: "Harvest when 80% of tops have fallen. Cure in sun for 2-3 days before storage.", 
                category: "harvesting",
                expertise_level: "important"
            }
        ]
    }
};

// Unit conversion constants
const UNIT_CONVERSIONS = {
    acres: 4047, // square meters per acre
    hectares: 10000, // square meters per hectare
    sqmeters: 1, // square meters per square meter
    plots: 464.5 // square meters per plot (50x100 ft = 464.5 sq meters)
};

// Application state
let currentCalculation = null;

// DOM elements
const farmForm = document.getElementById('farmForm');
const resultsSection = document.getElementById('resultsSection');
const loadingIndicator = document.getElementById('loadingIndicator');
const errorMessage = document.getElementById('errorMessage');
const resetBtn = document.getElementById('resetBtn');

// Authentication elements
const authCard = document.getElementById('authCard');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const userProfile = document.getElementById('userProfile');
const showRegisterBtn = document.getElementById('showRegisterBtn');
const showLoginBtn = document.getElementById('showLoginBtn');
const logoutBtn = document.getElementById('logoutBtn');
const authTitle = document.getElementById('authTitle');

// Form input elements
const landSizeInput = document.getElementById('landSize');
const landUnitSelect = document.getElementById('landUnit');
const cropTypeSelect = document.getElementById('cropType');
const plantingStyleSelect = document.getElementById('plantingStyle');

// Result display elements
const plantsNeededEl = document.getElementById('plantsNeeded');
const plantSpacingEl = document.getElementById('plantSpacing');
const landUtilizationEl = document.getElementById('landUtilization');
const seedsRequiredEl = document.getElementById('seedsRequired');
const fertilizerRequiredEl = document.getElementById('fertilizerRequired');
const manureRequiredEl = document.getElementById('manureRequired');
const waterRequiredEl = document.getElementById('waterRequired');
const expectedYieldEl = document.getElementById('expectedYield');
const yieldDetailsEl = document.getElementById('yieldDetails');

// Extension Intelligence Engine elements
const extensionTipsCard = document.getElementById('extensionTipsCard');
const expertTipsContainer = document.getElementById('expertTipsContainer');
const dayFilter = document.getElementById('dayFilter');
const categoryFilter = document.getElementById('categoryFilter');

// Daily Task Calendar elements
const taskCalendarCard = document.getElementById('taskCalendarCard');
const taskSummary = document.getElementById('taskSummary');
const dailyTasksList = document.getElementById('dailyTasksList');
const taskFilters = document.getElementById('taskFilters');
const taskLegend = document.getElementById('taskLegend');
const taskStageFilter = document.getElementById('taskStageFilter');
const taskCategoryFilter = document.getElementById('taskCategoryFilter');

// Current extension tips state
let currentCropTips = null;
let filteredTips = [];

// Current task calendar state
let currentCropTasks = null;
let filteredTasks = [];

// Current user state
let currentUser = null;
let isLoggedIn = false;

/**
 * Initialize the application
 */
function initializeApp() {
    console.log('FarmAssist Crop - Initializing application...');
    
    // Add event listeners
    farmForm.addEventListener('submit', handleFormSubmit);
    resetBtn.addEventListener('click', resetForm);
    
    // Add input validation listeners
    landSizeInput.addEventListener('input', validateLandSize);
    cropTypeSelect.addEventListener('change', validateCropSelection);
    plantingStyleSelect.addEventListener('change', validatePlantingStyle);
    
    // Add Extension Intelligence Engine listeners
    cropTypeSelect.addEventListener('change', handleCropSelectionForTips);
    dayFilter.addEventListener('change', filterTips);
    categoryFilter.addEventListener('change', filterTips);
    
    // Add Daily Task Calendar listeners
    taskStageFilter.addEventListener('change', filterTasks);
    taskCategoryFilter.addEventListener('change', filterTasks);
    
    // Add authentication listeners
    loginForm.addEventListener('submit', handleLogin);
    registerForm.addEventListener('submit', handleRegister);
    showRegisterBtn.addEventListener('click', showRegisterForm);
    showLoginBtn.addEventListener('click', showLoginForm);
    logoutBtn.addEventListener('click', handleLogout);
    
    // Check for saved user session
    checkUserSession();
    
    console.log('Application initialized successfully');
}

/**
 * Handle form submission
 */
async function handleFormSubmit(event) {
    event.preventDefault();
    
    // Validate form
    if (!validateForm()) {
        return;
    }
    
    // Show loading indicator
    showLoading();
    
    try {
        // Simulate processing time for better UX
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Get form data
        const formData = getFormData();
        
        // Calculate requirements
        const calculation = calculateRequirements(formData);
        
        // Display results
        displayResults(calculation);
        
    } catch (error) {
        console.error('Calculation error:', error);
        showError('An error occurred while calculating your requirements. Please try again.');
    } finally {
        hideLoading();
    }
}

/**
 * Get form data
 */
function getFormData() {
    return {
        landSize: parseFloat(landSizeInput.value),
        landUnit: landUnitSelect.value,
        cropType: cropTypeSelect.value,
        plantingStyle: plantingStyleSelect.value
    };
}

/**
 * Validate the entire form
 */
function validateForm() {
    let isValid = true;
    
    // Clear previous error states
    clearErrorStates();
    
    // Validate land size
    if (!validateLandSize()) {
        isValid = false;
    }
    
    // Validate crop selection
    if (!validateCropSelection()) {
        isValid = false;
    }
    
    // Validate planting style
    if (!validatePlantingStyle()) {
        isValid = false;
    }
    
    return isValid;
}

/**
 * Validate land size input
 */
function validateLandSize() {
    const value = parseFloat(landSizeInput.value);
    
    if (!value || value <= 0) {
        setInputError(landSizeInput, 'Please enter a valid land size greater than 0');
        return false;
    }
    
    if (value > 10000) {
        setInputError(landSizeInput, 'Land size seems too large. Please check your input');
        return false;
    }
    
    setInputValid(landSizeInput);
    return true;
}

/**
 * Validate crop selection
 */
function validateCropSelection() {
    if (!cropTypeSelect.value) {
        setInputError(cropTypeSelect, 'Please select a crop type');
        return false;
    }
    
    setInputValid(cropTypeSelect);
    return true;
}

/**
 * Validate planting style selection
 */
function validatePlantingStyle() {
    if (!plantingStyleSelect.value) {
        setInputError(plantingStyleSelect, 'Please select a planting style');
        return false;
    }
    
    setInputValid(plantingStyleSelect);
    return true;
}

/**
 * Set input error state
 */
function setInputError(input, message) {
    input.classList.add('is-invalid');
    input.classList.remove('is-valid');
    
    const feedback = input.parentNode.querySelector('.invalid-feedback');
    if (feedback) {
        feedback.textContent = message;
    }
}

/**
 * Set input valid state
 */
function setInputValid(input) {
    input.classList.add('is-valid');
    input.classList.remove('is-invalid');
}

/**
 * Clear all error states
 */
function clearErrorStates() {
    const inputs = [landSizeInput, cropTypeSelect, plantingStyleSelect];
    inputs.forEach(input => {
        input.classList.remove('is-invalid', 'is-valid');
    });
}

/**
 * Calculate planting requirements and yield
 */
function calculateRequirements(formData) {
    const { landSize, landUnit, cropType, plantingStyle } = formData;
    
    // Get crop data
    const cropData = CROP_DATABASE[cropType];
    if (!cropData) {
        throw new Error(`Crop data not found for ${cropType}`);
    }
    
    // Convert land size to square meters
    const landSizeSquareMeters = landSize * UNIT_CONVERSIONS[landUnit];
    const landSizeHectares = landSizeSquareMeters / 10000;
    
    // Calculate plant spacing and number of plants
    const plantSpacing = cropData.spacingMeters;
    const areaPerPlant = plantSpacing * plantSpacing; // Square spacing
    const plantsNeeded = Math.floor(landSizeSquareMeters / areaPerPlant);
    
    // Calculate land utilization
    const usedArea = plantsNeeded * areaPerPlant;
    const landUtilization = (usedArea / landSizeSquareMeters) * 100;
    
    // Calculate seed requirements
    const totalSeeds = plantsNeeded * cropData.seedsPerPlant;
    const seedsInGrams = totalSeeds / cropData.seedsPerGram;
    
    // Calculate fertilizer requirements (kg)
    const fertilizerPerHectare = cropData.fertilizer[plantingStyle];
    const totalFertilizer = fertilizerPerHectare * landSizeHectares;
    
    // Calculate manure requirements (kg)
    const manurePerHectare = cropData.manure[plantingStyle];
    const totalManure = manurePerHectare * landSizeHectares;
    
    // Calculate water requirements (liters per week)
    const waterPerPlantPerWeek = cropData.waterPerWeek[plantingStyle];
    const totalWaterPerWeek = waterPerPlantPerWeek * plantsNeeded;
    
    // Calculate expected yield (kg)
    const yieldPerPlant = cropData.yieldPerPlant[plantingStyle];
    const totalYield = yieldPerPlant * plantsNeeded;
    
    // Store calculation for reference
    currentCalculation = {
        formData,
        results: {
            plantsNeeded,
            plantSpacing: `${Math.round(plantSpacing * 100)} cm`,
            landUtilization: `${landUtilization.toFixed(1)}%`,
            seedsRequired: formatSeeds(seedsInGrams, totalSeeds),
            fertilizerRequired: `${totalFertilizer.toFixed(1)} kg`,
            manureRequired: `${Math.round(totalManure)} kg`,
            waterRequired: formatWater(totalWaterPerWeek, plantingStyle),
            expectedYield: `${totalYield.toFixed(1)} kg`,
            yieldDetails: generateYieldDetails(cropData.name, plantingStyle, totalYield, landSizeHectares)
        }
    };
    
    return currentCalculation;
}

/**
 * Format seed requirements for display
 */
function formatSeeds(grams, totalSeeds) {
    if (grams < 1) {
        return `${totalSeeds} seeds (${(grams * 1000).toFixed(0)} mg)`;
    } else if (grams < 1000) {
        return `${totalSeeds} seeds (${grams.toFixed(1)} g)`;
    } else {
        return `${totalSeeds} seeds (${(grams / 1000).toFixed(2)} kg)`;
    }
}

/**
 * Format water requirements for display
 */
function formatWater(litersPerWeek, plantingStyle) {
    if (plantingStyle === 'open_field_rainfed') {
        return 'Rain-dependent (no irrigation needed)';
    }
    
    if (litersPerWeek < 1000) {
        return `${Math.round(litersPerWeek)} L/week`;
    } else {
        return `${(litersPerWeek / 1000).toFixed(2)} m³/week`;
    }
}

/**
 * Generate yield details text
 */
function generateYieldDetails(cropName, plantingStyle, totalYield, hectares) {
    const yieldPerHectare = totalYield / hectares;
    const styleText = plantingStyle.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    
    return `${cropName} in ${styleText} setup: ${yieldPerHectare.toFixed(1)} kg/hectare expected yield based on standard farming practices and favorable conditions.`;
}

/**
 * Display calculation results
 */
function displayResults(calculation) {
    const { results } = calculation;
    
    // Update all result elements
    plantsNeededEl.textContent = formatNumber(results.plantsNeeded);
    plantSpacingEl.textContent = results.plantSpacing;
    landUtilizationEl.textContent = results.landUtilization;
    seedsRequiredEl.textContent = results.seedsRequired;
    fertilizerRequiredEl.textContent = results.fertilizerRequired;
    manureRequiredEl.textContent = results.manureRequired;
    waterRequiredEl.textContent = results.waterRequired;
    expectedYieldEl.textContent = results.expectedYield;
    yieldDetailsEl.textContent = results.yieldDetails;
    
    // Show daily task calendar for selected crop
    displayDailyTasks(calculation.formData.cropType);
    
    // Save calculation to database if user is logged in
    saveCalculationToDatabase(calculation);
    
    // Show results section
    resultsSection.style.display = 'block';
    
    // Scroll to results
    resultsSection.scrollIntoView({ behavior: 'smooth' });
    
    console.log('Results displayed successfully');
}

/**
 * Format numbers with thousand separators
 */
function formatNumber(num) {
    return num.toLocaleString();
}

/**
 * Show loading indicator
 */
function showLoading() {
    loadingIndicator.style.display = 'block';
    hideError();
}

/**
 * Hide loading indicator
 */
function hideLoading() {
    loadingIndicator.style.display = 'none';
}

/**
 * Show error message
 */
function showError(message) {
    document.getElementById('errorText').textContent = message;
    errorMessage.style.display = 'block';
    
    // Scroll to error message
    errorMessage.scrollIntoView({ behavior: 'smooth' });
}

/**
 * Hide error message
 */
function hideError() {
    errorMessage.style.display = 'none';
}

/**
 * Reset form and hide results
 */
function resetForm() {
    // Reset form
    farmForm.reset();
    
    // Clear validation states
    clearErrorStates();
    
    // Hide results and errors
    resultsSection.style.display = 'none';
    hideError();
    
    // Clear current calculation
    currentCalculation = null;
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    // Focus on first input
    landSizeInput.focus();
    
    // Reset Extension Intelligence Engine
    extensionTipsCard.style.display = 'none';
    currentCropTips = null;
    filteredTips = [];
    
    // Reset Daily Task Calendar
    taskCalendarCard.style.display = 'none';
    currentCropTasks = null;
    filteredTasks = [];
    
    console.log('Form reset successfully');
}

// ========================================
// EXTENSION INTELLIGENCE ENGINE FUNCTIONS
// ========================================

/**
 * Handle crop selection for Extension Intelligence Engine
 */
function handleCropSelectionForTips() {
    const selectedCrop = cropTypeSelect.value;
    
    if (selectedCrop && EXTENSION_TIPS[selectedCrop]) {
        currentCropTips = EXTENSION_TIPS[selectedCrop];
        displayExtensionTips(selectedCrop);
        extensionTipsCard.style.display = 'block';
    } else {
        extensionTipsCard.style.display = 'none';
        currentCropTips = null;
        filteredTips = [];
    }
}

/**
 * Display extension tips for selected crop
 */
function displayExtensionTips(cropType) {
    if (!currentCropTips) return;
    
    // Reset filters
    dayFilter.value = 'all';
    categoryFilter.value = 'all';
    
    // Display all tips initially
    filteredTips = [...currentCropTips.tips];
    renderTips();
}

/**
 * Filter tips based on day range and category
 */
function filterTips() {
    if (!currentCropTips) return;
    
    const dayRange = dayFilter.value;
    const category = categoryFilter.value;
    
    filteredTips = currentCropTips.tips.filter(tip => {
        // Filter by day range
        let dayMatch = true;
        if (dayRange !== 'all') {
            const [minDay, maxDay] = dayRange.split('-').map(Number);
            dayMatch = tip.day >= minDay && tip.day <= maxDay;
        }
        
        // Filter by category
        let categoryMatch = true;
        if (category !== 'all') {
            categoryMatch = tip.category === category;
        }
        
        return dayMatch && categoryMatch;
    });
    
    renderTips();
}

/**
 * Render filtered tips to the UI
 */
function renderTips() {
    if (!filteredTips || filteredTips.length === 0) {
        expertTipsContainer.innerHTML = `
            <div class="no-tips-message">
                <i class="fas fa-search fa-2x mb-2"></i>
                <p>No tips found for the selected filters.</p>
                <small>Try adjusting your day range or category filters.</small>
            </div>
        `;
        return;
    }
    
    const tipsCount = filteredTips.length;
    const totalTips = currentCropTips.tips.length;
    
    let html = `
        <div class="tips-count">
            <i class="fas fa-lightbulb me-1"></i>
            Showing ${tipsCount} of ${totalTips} expert tips for ${currentCropTips.name}
        </div>
    `;
    
    // Sort tips by day
    const sortedTips = [...filteredTips].sort((a, b) => a.day - b.day);
    
    sortedTips.forEach(tip => {
        html += `
            <div class="tip-item ${tip.category}" data-day="${tip.day}" data-category="${tip.category}">
                <div class="d-flex align-items-start">
                    <div class="tip-day">
                        ${tip.day}
                    </div>
                    <div class="tip-content">
                        <div class="tip-text">
                            ${tip.tip}
                        </div>
                        <div class="tip-meta">
                            <span class="tip-category">
                                <i class="fas fa-tag me-1"></i>
                                ${tip.category.replace('_', ' ')}
                            </span>
                            <span class="badge-${tip.expertise_level}">
                                ${tip.expertise_level}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    expertTipsContainer.innerHTML = html;
}

/**
 * Get tips for specific day (utility function for future use)
 */
function getTipsForDay(cropType, day) {
    if (!EXTENSION_TIPS[cropType]) return [];
    
    return EXTENSION_TIPS[cropType].tips.filter(tip => tip.day === day);
}

/**
 * Get tips by category (utility function for future use)
 */
function getTipsByCategory(cropType, category) {
    if (!EXTENSION_TIPS[cropType]) return [];
    
    return EXTENSION_TIPS[cropType].tips.filter(tip => tip.category === category);
}

/**
 * Get critical tips for crop (utility function for future use)
 */
function getCriticalTips(cropType) {
    if (!EXTENSION_TIPS[cropType]) return [];
    
    return EXTENSION_TIPS[cropType].tips.filter(tip => tip.expertise_level === 'critical');
}

// ========================================
// DAILY TASK CALENDAR FUNCTIONS
// ========================================

/**
 * Display daily tasks for selected crop
 */
function displayDailyTasks(cropType) {
    if (!CROP_TASK_CALENDAR[cropType]) {
        taskCalendarCard.style.display = 'none';
        return;
    }
    
    currentCropTasks = CROP_TASK_CALENDAR[cropType];
    
    // Show task calendar card
    taskCalendarCard.style.display = 'block';
    
    // Reset filters
    taskStageFilter.value = 'all';
    taskCategoryFilter.value = 'all';
    
    // Display task summary
    displayTaskSummary();
    
    // Display all tasks initially
    filteredTasks = [...currentCropTasks.tasks];
    renderTasks();
    
    // Show filters and legend
    taskFilters.style.display = 'block';
    taskLegend.style.display = 'block';
}

/**
 * Display task summary information
 */
function displayTaskSummary() {
    if (!currentCropTasks) return;
    
    const totalTasks = currentCropTasks.tasks.length;
    const totalDays = currentCropTasks.totalDays;
    
    taskSummary.innerHTML = `
        <div class="task-count-summary">
            <i class="fas fa-calendar-check me-2"></i>
            <span class="crop-name">${currentCropTasks.name}</span> farming schedule: 
            <span class="total-days">${totalDays} days</span> with 
            <strong>${totalTasks} planned tasks</strong>
        </div>
    `;
}

/**
 * Filter tasks based on stage and category
 */
function filterTasks() {
    if (!currentCropTasks) return;
    
    const stage = taskStageFilter.value;
    const category = taskCategoryFilter.value;
    
    filteredTasks = currentCropTasks.tasks.filter(task => {
        // Filter by stage (day range)
        let stageMatch = true;
        if (stage !== 'all') {
            switch (stage) {
                case 'early':
                    stageMatch = task.day >= 1 && task.day <= 30;
                    break;
                case 'growth':
                    stageMatch = task.day >= 31 && task.day <= 60;
                    break;
                case 'mature':
                    stageMatch = task.day >= 61 && task.day <= 90;
                    break;
                case 'harvest':
                    stageMatch = task.day >= 91;
                    break;
            }
        }
        
        // Filter by category
        let categoryMatch = true;
        if (category !== 'all') {
            categoryMatch = task.category === category;
        }
        
        return stageMatch && categoryMatch;
    });
    
    renderTasks();
}

/**
 * Render filtered tasks to the UI
 */
function renderTasks() {
    if (!filteredTasks || filteredTasks.length === 0) {
        dailyTasksList.innerHTML = `
            <div class="no-tasks-message">
                <i class="fas fa-search fa-2x mb-2"></i>
                <p>No tasks found for the selected filters.</p>
                <small>Try adjusting your stage or category filters.</small>
            </div>
        `;
        return;
    }
    
    // Sort tasks by day
    const sortedTasks = [...filteredTasks].sort((a, b) => a.day - b.day);
    
    let html = '';
    sortedTasks.forEach(task => {
        html += `
            <div class="task-item ${task.category}" data-day="${task.day}" data-category="${task.category}">
                <div class="d-flex align-items-start">
                    <div class="task-day-badge">
                        ${task.day}
                    </div>
                    <div class="task-content">
                        <div class="task-description">
                            ${task.task}
                        </div>
                        <div class="task-meta">
                            <span class="task-category-badge">
                                <i class="fas fa-tag me-1"></i>
                                ${task.category.replace('_', ' ')}
                            </span>
                            <span class="badge-priority-${task.priority}">
                                ${task.priority} priority
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    dailyTasksList.innerHTML = html;
}

/**
 * Get tasks for specific day range (utility function)
 */
function getTasksForDayRange(cropType, startDay, endDay) {
    if (!CROP_TASK_CALENDAR[cropType]) return [];
    
    return CROP_TASK_CALENDAR[cropType].tasks.filter(task => 
        task.day >= startDay && task.day <= endDay
    );
}

/**
 * Get high priority tasks for crop (utility function)
 */
function getHighPriorityTasks(cropType) {
    if (!CROP_TASK_CALENDAR[cropType]) return [];
    
    return CROP_TASK_CALENDAR[cropType].tasks.filter(task => task.priority === 'high');
}

/**
 * Get tasks by category for crop (utility function)
 */
function getTasksByCategory(cropType, category) {
    if (!CROP_TASK_CALENDAR[cropType]) return [];
    
    return CROP_TASK_CALENDAR[cropType].tasks.filter(task => task.category === category);
}

// ========================================
// USER AUTHENTICATION FUNCTIONS
// ========================================

/**
 * Check for saved user session
 */
function checkUserSession() {
    const savedUser = localStorage.getItem('farmassist_user');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        isLoggedIn = true;
        showUserProfile();
    }
}

/**
 * Handle user login
 */
async function handleLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('loginUsername').value.trim();
    
    if (!username) {
        showError('Please enter a username');
        return;
    }
    
    try {
        showLoading();
        
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentUser = data.user;
            isLoggedIn = true;
            
            // Save user session
            localStorage.setItem('farmassist_user', JSON.stringify(currentUser));
            
            showUserProfile();
            hideError();
            
            // Show success message
            setTimeout(() => {
                showError('Login successful! Welcome back.');
                setTimeout(hideError, 3000);
            }, 500);
            
        } else {
            showError(data.error || 'Login failed');
        }
    } catch (error) {
        console.error('Login error:', error);
        showError('Login failed. Please try again.');
    } finally {
        hideLoading();
    }
}

/**
 * Handle user registration
 */
async function handleRegister(event) {
    event.preventDefault();
    
    const formData = {
        username: document.getElementById('regUsername').value.trim(),
        email: document.getElementById('regEmail').value.trim(),
        fullName: document.getElementById('regFullName').value.trim(),
        phoneNumber: document.getElementById('regPhone').value.trim(),
        location: document.getElementById('regLocation').value.trim(),
        farmSize: parseFloat(document.getElementById('regFarmSize').value) || null,
        experienceLevel: document.getElementById('regExperience').value
    };
    
    // Basic validation
    if (!formData.username || !formData.email || !formData.fullName || !formData.experienceLevel) {
        showError('Please fill in all required fields');
        return;
    }
    
    try {
        showLoading();
        
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            // Auto-login after successful registration
            currentUser = data.user;
            isLoggedIn = true;
            
            // Save user session
            localStorage.setItem('farmassist_user', JSON.stringify(currentUser));
            
            showUserProfile();
            hideError();
            
            // Show success message
            setTimeout(() => {
                showError('Registration successful! Welcome to FarmAssist.');
                setTimeout(hideError, 3000);
            }, 500);
            
        } else {
            showError(data.error || 'Registration failed');
        }
    } catch (error) {
        console.error('Registration error:', error);
        showError('Registration failed. Please try again.');
    } finally {
        hideLoading();
    }
}

/**
 * Show register form
 */
function showRegisterForm() {
    loginForm.style.display = 'none';
    registerForm.style.display = 'block';
    authTitle.textContent = 'Create Your Farm Account';
}

/**
 * Show login form
 */
function showLoginForm() {
    registerForm.style.display = 'none';
    loginForm.style.display = 'block';
    authTitle.textContent = 'Login to Your Farm Account';
}

/**
 * Show user profile
 */
function showUserProfile() {
    loginForm.style.display = 'none';
    registerForm.style.display = 'none';
    userProfile.style.display = 'block';
    
    // Update profile display
    document.getElementById('userFullName').textContent = currentUser.fullName;
    document.getElementById('userUsername').textContent = currentUser.username;
    
    const farmInfo = currentUser.farmSize 
        ? `${currentUser.farmSize} hectares` 
        : 'Farm size not specified';
    document.getElementById('userFarmInfo').textContent = farmInfo;
    
    authTitle.textContent = 'Your Farm Account';
}

/**
 * Handle logout
 */
function handleLogout() {
    currentUser = null;
    isLoggedIn = false;
    
    // Clear saved session
    localStorage.removeItem('farmassist_user');
    
    // Reset forms
    loginForm.reset();
    registerForm.reset();
    
    // Show login form
    showLoginForm();
    
    // Clear any calculations and tasks
    resetForm();
}

/**
 * Save calculation to database
 */
async function saveCalculationToDatabase(calculation) {
    if (!isLoggedIn || !currentUser) {
        console.log('User not logged in, skipping database save');
        return;
    }
    
    try {
        const calculationData = {
            userId: currentUser.id,
            landSize: calculation.formData.landSize,
            landUnit: calculation.formData.landUnit,
            cropType: calculation.formData.cropType,
            plantingStyle: calculation.formData.plantingStyle,
            plantsNeeded: calculation.results.plantsNeeded,
            expectedYield: parseFloat(calculation.results.expectedYield),
            fertilizerRequired: parseFloat(calculation.results.fertilizerRequired),
            manureRequired: parseFloat(calculation.results.manureRequired),
            waterRequired: calculation.results.waterRequired !== 'Rain-dependent (no irrigation needed)' 
                ? parseFloat(calculation.results.waterRequired.replace(/[^\d.]/g, '')) 
                : null
        };
        
        const response = await fetch('/api/calculations', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(calculationData)
        });
        
        if (response.ok) {
            const data = await response.json();
            console.log('Calculation saved to database:', data.calculation.id);
            
            // Save tasks to database if available
            if (currentCropTasks) {
                await saveTasksToDatabase(data.calculation.id);
            }
        }
    } catch (error) {
        console.error('Failed to save calculation:', error);
    }
}

/**
 * Save tasks to database
 */
async function saveTasksToDatabase(farmCalculationId) {
    if (!isLoggedIn || !currentUser || !currentCropTasks) return;
    
    try {
        const today = new Date();
        const tasks = currentCropTasks.tasks.map(task => ({
            userId: currentUser.id,
            farmCalculationId: farmCalculationId,
            cropType: currentCalculation.formData.cropType,
            taskDay: task.day,
            taskDescription: task.task,
            taskCategory: task.category,
            priority: task.priority,
            dueDate: new Date(today.getTime() + (task.day * 24 * 60 * 60 * 1000)).toISOString().split('T')[0]
        }));
        
        const response = await fetch('/api/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ tasks })
        });
        
        if (response.ok) {
            console.log('Tasks saved to database');
        }
    } catch (error) {
        console.error('Failed to save tasks:', error);
    }
}

/**
 * Handle window resize for responsive adjustments
 */
function handleResize() {
    // Add any responsive adjustments here if needed
    console.log('Window resized');
}

/**
 * Handle offline/online status
 */
function handleOnlineStatus() {
    if (navigator.onLine) {
        console.log('Application is online');
    } else {
        console.log('Application is offline - all calculations work locally');
    }
}

// Event listeners for app lifecycle
window.addEventListener('resize', handleResize);
window.addEventListener('online', handleOnlineStatus);
window.addEventListener('offline', handleOnlineStatus);

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', initializeApp);

// Service Worker registration for offline functionality (future enhancement)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        // Service worker can be added here for offline functionality
        console.log('Service Worker support detected');
    });
}

console.log('FarmAssist Crop script loaded successfully');
