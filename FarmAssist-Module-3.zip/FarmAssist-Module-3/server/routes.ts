import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWeatherForecastSchema, insertCropAdvisorySchema, type WeatherData, type CropAdvisoryData, type WeatherDay } from "@shared/schema";
import { z } from "zod";

const OPENWEATHER_API_KEY = process.env.OPENWEATHER_API_KEY || process.env.API_KEY || "demo_key";

// Crop sensitivity data
const cropWeatherRisks = {
  tomato: {
    rain: {
      threshold: 10,
      message: "Fungal disease risk. Use preventive organic spray.",
      actions: [
        "Apply preventive organic copper spray before heavy rain",
        "Ensure proper drainage around plants",
        "Avoid overhead watering during rain period",
        "Monitor for early blight symptoms after rain"
      ]
    },
    heat: {
      threshold: 30,
      message: "May cause flower drop. Shade or mist.",
      actions: [
        "Increase watering frequency (early morning/evening)",
        "Consider shade cloth installation (30-50%)",
        "Apply mulch to keep roots cool",
        "Monitor soil moisture levels closely"
      ]
    },
    cold: {
      threshold: 15,
      message: "Slow growth expected. Monitor soil temp.",
      actions: [
        "Use row covers during cold nights",
        "Monitor soil temperature",
        "Delay transplanting until warmer",
        "Apply mulch for insulation"
      ]
    }
  },
  maize: {
    rain: {
      threshold: 15,
      message: "Risk of nutrient leaching. Delay fertilizer.",
      actions: [
        "Delay fertilizer application until after rain",
        "Check for waterlogging in fields",
        "Apply side-dress nitrogen after rain stops",
        "Monitor for fungal diseases"
      ]
    },
    heat: {
      threshold: 35,
      message: "Water stress. Increase irrigation.",
      actions: [
        "Increase irrigation frequency",
        "Check soil moisture at root depth",
        "Apply mulch to conserve moisture",
        "Monitor for heat stress symptoms"
      ]
    },
    cold: {
      threshold: 10,
      message: "Germination delay. Use treated seeds.",
      actions: [
        "Use cold-tolerant seed varieties",
        "Wait for soil temperature above 10°C",
        "Consider using seed treatments",
        "Monitor germination rates closely"
      ]
    }
  },
  pepper: {
    rain: {
      threshold: 8,
      message: "Root rot potential. Improve drainage.",
      actions: [
        "Ensure adequate drainage",
        "Reduce watering frequency",
        "Monitor for root rot symptoms",
        "Apply fungicide if necessary"
      ]
    },
    heat: {
      threshold: 32,
      message: "Reduced fruit set. Provide shade.",
      actions: [
        "Provide afternoon shade",
        "Increase humidity around plants",
        "Ensure consistent watering",
        "Monitor fruit development"
      ]
    },
    cold: {
      threshold: 12,
      message: "Stunted growth. Use row covers.",
      actions: [
        "Use row covers or tunnels",
        "Delay planting until warmer",
        "Monitor growth rates",
        "Provide wind protection"
      ]
    }
  }
};

async function fetchWeatherFromAPI(location: string) {
  const url = `https://api.openweathermap.org/data/2.5/forecast?q=${location}&appid=${OPENWEATHER_API_KEY}&units=metric`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Weather API error: ${response.statusText}`);
    }
    
    const data = await response.json();
    return processWeatherData(data, location);
  } catch (error) {
    console.error('Error fetching weather data:', error);
    throw new Error('Failed to fetch weather data. Please check your location and try again.');
  }
}

function processWeatherData(apiData: any, location: string): WeatherData {
  const days: WeatherDay[] = [];
  const dailyData = new Map();
  
  // Group forecasts by date
  apiData.list.forEach((item: any) => {
    const date = new Date(item.dt * 1000).toISOString().split('T')[0];
    if (!dailyData.has(date)) {
      dailyData.set(date, []);
    }
    dailyData.get(date).push(item);
  });
  
  // Process up to 7 days
  const dates = Array.from(dailyData.keys()).slice(0, 7);
  
  dates.forEach((date, index) => {
    const dayData = dailyData.get(date);
    const temps = dayData.map((d: any) => d.main.temp);
    const humidity = dayData.map((d: any) => d.main.humidity);
    const rainfall = dayData.reduce((sum: number, d: any) => {
      return sum + (d.rain?.['3h'] || 0);
    }, 0);
    
    const avgTemp = Math.round(temps.reduce((a: number, b: number) => a + b, 0) / temps.length);
    const avgHumidity = Math.round(humidity.reduce((a: number, b: number) => a + b, 0) / humidity.length);
    const description = dayData[0].weather[0].description;
    const icon = dayData[0].weather[0].icon;
    
    const dateObj = new Date(date);
    const dayLabel = index === 0 ? 'Today' : 
                    index === 1 ? 'Tomorrow' : 
                    dateObj.toLocaleDateString('en-US', { weekday: 'short' });
    
    days.push({
      date,
      dayLabel,
      temperature: avgTemp,
      description: description.charAt(0).toUpperCase() + description.slice(1),
      humidity: avgHumidity,
      rainfall: Math.round(rainfall),
      icon
    });
  });
  
  return {
    location,
    days,
    lastUpdated: new Date().toISOString()
  };
}

function generateCropAdvisory(weatherData: WeatherData, cropType: string): CropAdvisoryData {
  const cropRisks = cropWeatherRisks[cropType as keyof typeof cropWeatherRisks];
  if (!cropRisks) {
    throw new Error(`Unsupported crop type: ${cropType}`);
  }
  
  const risks: any[] = [];
  let goodDays = 0;
  let cautionDays = 0;
  let riskDays = 0;
  
  // Analyze rain risks
  const rainDays = weatherData.days.filter(day => day.rainfall > cropRisks.rain.threshold);
  if (rainDays.length > 0) {
    risks.push({
      type: 'rain',
      level: rainDays.length > 2 ? 'high' : 'medium',
      days: rainDays.map(d => d.dayLabel),
      title: `Fungal Disease Risk (${rainDays.map(d => d.dayLabel).join(', ')})`,
      description: `Heavy rainfall expected (${rainDays.map(d => `${d.rainfall}mm on ${d.dayLabel}`).join(', ')}). ${cropRisks.rain.message}`,
      actions: cropRisks.rain.actions
    });
    riskDays += rainDays.length;
  }
  
  // Analyze heat risks
  const heatDays = weatherData.days.filter(day => day.temperature > cropRisks.heat.threshold);
  if (heatDays.length > 0) {
    risks.push({
      type: 'heat',
      level: heatDays.some(d => d.temperature > cropRisks.heat.threshold + 3) ? 'high' : 'medium',
      days: heatDays.map(d => d.dayLabel),
      title: `Heat Stress Risk (${heatDays.map(d => d.dayLabel).join(', ')})`,
      description: `High temperatures (${heatDays.map(d => `${d.temperature}°C on ${d.dayLabel}`).join(', ')}). ${cropRisks.heat.message}`,
      actions: cropRisks.heat.actions
    });
    cautionDays += heatDays.length;
  }
  
  // Analyze cold risks
  const coldDays = weatherData.days.filter(day => day.temperature < cropRisks.cold.threshold);
  if (coldDays.length > 0) {
    risks.push({
      type: 'cold',
      level: 'medium',
      days: coldDays.map(d => d.dayLabel),
      title: `Cold Weather Impact (${coldDays.map(d => d.dayLabel).join(', ')})`,
      description: `Low temperatures (${coldDays.map(d => `${d.temperature}°C on ${d.dayLabel}`).join(', ')}). ${cropRisks.cold.message}`,
      actions: cropRisks.cold.actions
    });
    cautionDays += coldDays.length;
  }
  
  // Add good conditions if present
  const optimalDays = weatherData.days.filter(day => 
    day.rainfall <= cropRisks.rain.threshold && 
    day.temperature <= cropRisks.heat.threshold && 
    day.temperature >= cropRisks.cold.threshold
  );
  
  if (optimalDays.length > 0) {
    goodDays = optimalDays.length;
    risks.push({
      type: 'optimal',
      level: 'low',
      days: optimalDays.map(d => d.dayLabel),
      title: `Optimal Growing Conditions (${optimalDays.map(d => d.dayLabel).join(', ')})`,
      description: `Temperature and humidity levels are ideal for ${cropType} growth. Good opportunity for routine maintenance tasks.`,
      actions: [
        'Perfect time for transplanting seedlings',
        'Apply balanced fertilizer if needed',
        'Prune and stake plants',
        'Harvest mature fruits'
      ]
    });
  }
  
  return {
    cropType,
    location: weatherData.location,
    risks,
    summary: {
      goodDays,
      cautionDays,
      riskDays
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get weather forecast
  app.get("/api/weather/:location", async (req, res) => {
    try {
      const { location } = req.params;
      if (!location) {
        return res.status(400).json({ message: "Location is required" });
      }
      
      // Check if we have cached data
      const cached = await storage.getWeatherForecast(location);
      if (cached) {
        const cacheAge = Date.now() - new Date(cached.lastUpdated).getTime();
        if (cacheAge < 3600000) { // 1 hour cache
          return res.json(cached.forecastData);
        }
      }
      
      // Fetch fresh data
      const weatherData = await fetchWeatherFromAPI(location);
      
      // Save to storage
      await storage.saveWeatherForecast({
        location,
        forecastData: weatherData as any,
        lastUpdated: weatherData.lastUpdated
      });
      
      res.json(weatherData);
    } catch (error) {
      console.error('Weather API error:', error);
      res.status(500).json({ message: (error as Error).message });
    }
  });
  
  // Get crop advisory
  app.post("/api/advisory", async (req, res) => {
    try {
      const schema = z.object({
        location: z.string().min(1),
        cropType: z.enum(['tomato', 'maize', 'pepper'])
      });
      
      const { location, cropType } = schema.parse(req.body);
      
      // Get weather data first
      let weatherData;
      const cachedWeather = await storage.getWeatherForecast(location);
      if (cachedWeather) {
        weatherData = cachedWeather.forecastData as WeatherData;
      } else {
        weatherData = await fetchWeatherFromAPI(location);
        await storage.saveWeatherForecast({
          location,
          forecastData: weatherData as any,
          lastUpdated: weatherData.lastUpdated
        });
      }
      
      // Generate advisory
      const advisory = generateCropAdvisory(weatherData, cropType);
      
      // Save advisory
      await storage.saveCropAdvisory({
        location,
        cropType,
        advisoryData: advisory as any,
        riskLevel: advisory.risks.some(r => r.level === 'high') ? 'high' : 
                   advisory.risks.some(r => r.level === 'medium') ? 'medium' : 'low',
        createdAt: new Date().toISOString()
      });
      
      res.json(advisory);
    } catch (error) {
      console.error('Advisory error:', error);
      res.status(500).json({ message: (error as Error).message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
