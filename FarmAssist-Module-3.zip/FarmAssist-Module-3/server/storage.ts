import { type WeatherForecast, type InsertWeatherForecast, type CropAdvisory, type InsertCropAdvisory } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getWeatherForecast(location: string): Promise<WeatherForecast | undefined>;
  saveWeatherForecast(forecast: InsertWeatherForecast): Promise<WeatherForecast>;
  getCropAdvisory(location: string, cropType: string): Promise<CropAdvisory | undefined>;
  saveCropAdvisory(advisory: InsertCropAdvisory): Promise<CropAdvisory>;
}

export class MemStorage implements IStorage {
  private weatherForecasts: Map<string, WeatherForecast>;
  private cropAdvisories: Map<string, CropAdvisory>;

  constructor() {
    this.weatherForecasts = new Map();
    this.cropAdvisories = new Map();
  }

  async getWeatherForecast(location: string): Promise<WeatherForecast | undefined> {
    return Array.from(this.weatherForecasts.values()).find(
      (forecast) => forecast.location.toLowerCase() === location.toLowerCase()
    );
  }

  async saveWeatherForecast(insertForecast: InsertWeatherForecast): Promise<WeatherForecast> {
    const id = randomUUID();
    const forecast: WeatherForecast = { ...insertForecast, id };
    this.weatherForecasts.set(id, forecast);
    return forecast;
  }

  async getCropAdvisory(location: string, cropType: string): Promise<CropAdvisory | undefined> {
    return Array.from(this.cropAdvisories.values()).find(
      (advisory) => 
        advisory.location.toLowerCase() === location.toLowerCase() && 
        advisory.cropType === cropType
    );
  }

  async saveCropAdvisory(insertAdvisory: InsertCropAdvisory): Promise<CropAdvisory> {
    const id = randomUUID();
    const advisory: CropAdvisory = { ...insertAdvisory, id };
    this.cropAdvisories.set(id, advisory);
    return advisory;
  }
}

export const storage = new MemStorage();
