import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import WeatherDashboard from "@/pages/weather-dashboard";
import FarmChatbot from "@/pages/farm-chatbot";
import FarmFinance from "@/pages/farm-finance";
import PhotoJournal from "@/pages/photo-journal";
import FarmingGlossary from "@/pages/farming-glossary";
import EnvironmentalMonitoring from "@/pages/environmental-monitoring";
import PostHarvestTracking from "@/pages/post-harvest-tracking";

function Router() {
  return (
    <Switch>
      <Route path="/" component={WeatherDashboard}/>
      <Route path="/chatbot" component={FarmChatbot}/>
      <Route path="/finance" component={FarmFinance}/>
      <Route path="/photos" component={PhotoJournal}/>
      <Route path="/glossary" component={FarmingGlossary}/>
      <Route path="/monitoring" component={EnvironmentalMonitoring}/>
      <Route path="/harvest" component={PostHarvestTracking}/>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
