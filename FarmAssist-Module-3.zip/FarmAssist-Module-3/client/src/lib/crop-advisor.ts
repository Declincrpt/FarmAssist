import type { WeatherData, CropAdvisoryData, CropRisk } from "@shared/schema";

// Crop sensitivity thresholds and recommendations
export const cropWeatherProfiles = {
  tomato: {
    name: "Tomato",
    rain: {
      threshold: 10,
      message: "Fungal disease risk. Use preventive organic spray.",
      actions: [
        "Apply preventive organic copper spray before heavy rain",
        "Ensure proper drainage around plants",
        "Avoid overhead watering during rain period",
        "Monitor for early blight symptoms after rain"
      ]
    },
    heat: {
      threshold: 30,
      message: "May cause flower drop. Shade or mist.",
      actions: [
        "Increase watering frequency (early morning/evening)",
        "Consider shade cloth installation (30-50%)",
        "Apply mulch to keep roots cool",
        "Monitor soil moisture levels closely"
      ]
    },
    cold: {
      threshold: 15,
      message: "Slow growth expected. Monitor soil temp.",
      actions: [
        "Use row covers during cold nights",
        "Monitor soil temperature",
        "Delay transplanting until warmer",
        "Apply mulch for insulation"
      ]
    }
  },
  maize: {
    name: "Maize (Corn)",
    rain: {
      threshold: 15,
      message: "Risk of nutrient leaching. Delay fertilizer.",
      actions: [
        "Delay fertilizer application until after rain",
        "Check for waterlogging in fields",
        "Apply side-dress nitrogen after rain stops",
        "Monitor for fungal diseases"
      ]
    },
    heat: {
      threshold: 35,
      message: "Water stress. Increase irrigation.",
      actions: [
        "Increase irrigation frequency",
        "Check soil moisture at root depth",
        "Apply mulch to conserve moisture",
        "Monitor for heat stress symptoms"
      ]
    },
    cold: {
      threshold: 10,
      message: "Germination delay. Use treated seeds.",
      actions: [
        "Use cold-tolerant seed varieties",
        "Wait for soil temperature above 10°C",
        "Consider using seed treatments",
        "Monitor germination rates closely"
      ]
    }
  },
  pepper: {
    name: "Pepper",
    rain: {
      threshold: 8,
      message: "Root rot potential. Improve drainage.",
      actions: [
        "Ensure adequate drainage",
        "Reduce watering frequency",
        "Monitor for root rot symptoms",
        "Apply fungicide if necessary"
      ]
    },
    heat: {
      threshold: 32,
      message: "Reduced fruit set. Provide shade.",
      actions: [
        "Provide afternoon shade",
        "Increase humidity around plants",
        "Ensure consistent watering",
        "Monitor fruit development"
      ]
    },
    cold: {
      threshold: 12,
      message: "Stunted growth. Use row covers.",
      actions: [
        "Use row covers or tunnels",
        "Delay planting until warmer",
        "Monitor growth rates",
        "Provide wind protection"
      ]
    }
  }
};

export function generateCropAdvisory(weatherData: WeatherData, cropType: keyof typeof cropWeatherProfiles): CropAdvisoryData {
  const profile = cropWeatherProfiles[cropType];
  if (!profile) {
    throw new Error(`Unsupported crop type: ${cropType}`);
  }
  
  const risks: CropRisk[] = [];
  let goodDays = 0;
  let cautionDays = 0;
  let riskDays = 0;
  
  // Analyze rain risks
  const rainDays = weatherData.days.filter(day => day.rainfall > profile.rain.threshold);
  if (rainDays.length > 0) {
    const level = rainDays.length > 2 || rainDays.some(d => d.rainfall > 20) ? 'high' : 'medium';
    risks.push({
      type: 'rain',
      level,
      days: rainDays.map(d => d.dayLabel),
      title: `Fungal Disease Risk (${rainDays.map(d => d.dayLabel).join(', ')})`,
      description: `Heavy rainfall expected (${rainDays.map(d => `${d.rainfall}mm on ${d.dayLabel}`).join(', ')}). ${profile.rain.message}`,
      actions: profile.rain.actions
    });
    
    if (level === 'high') riskDays += rainDays.length;
    else cautionDays += rainDays.length;
  }
  
  // Analyze heat risks
  const heatDays = weatherData.days.filter(day => day.temperature > profile.heat.threshold);
  if (heatDays.length > 0) {
    const level = heatDays.some(d => d.temperature > profile.heat.threshold + 3) ? 'high' : 'medium';
    risks.push({
      type: 'heat',
      level,
      days: heatDays.map(d => d.dayLabel),
      title: `Heat Stress Risk (${heatDays.map(d => d.dayLabel).join(', ')})`,
      description: `High temperatures (${heatDays.map(d => `${d.temperature}°C on ${d.dayLabel}`).join(', ')}). ${profile.heat.message}`,
      actions: profile.heat.actions
    });
    
    if (level === 'high') riskDays += heatDays.length;
    else cautionDays += heatDays.length;
  }
  
  // Analyze cold risks
  const coldDays = weatherData.days.filter(day => day.temperature < profile.cold.threshold);
  if (coldDays.length > 0) {
    risks.push({
      type: 'cold',
      level: 'medium',
      days: coldDays.map(d => d.dayLabel),
      title: `Cold Weather Impact (${coldDays.map(d => d.dayLabel).join(', ')})`,
      description: `Low temperatures (${coldDays.map(d => `${d.temperature}°C on ${d.dayLabel}`).join(', ')}). ${profile.cold.message}`,
      actions: profile.cold.actions
    });
    
    cautionDays += coldDays.length;
  }
  
  // Calculate optimal days
  const optimalDays = weatherData.days.filter(day => 
    day.rainfall <= profile.rain.threshold && 
    day.temperature <= profile.heat.threshold && 
    day.temperature >= profile.cold.threshold
  );
  
  goodDays = optimalDays.length;
  
  // Add optimal conditions if present
  if (optimalDays.length > 0) {
    risks.push({
      type: 'cold', // Using cold as a placeholder for optimal
      level: 'low',
      days: optimalDays.map(d => d.dayLabel),
      title: `Optimal Growing Conditions (${optimalDays.map(d => d.dayLabel).join(', ')})`,
      description: `Temperature and humidity levels are ideal for ${profile.name.toLowerCase()} growth. Good opportunity for routine maintenance tasks.`,
      actions: [
        'Perfect time for transplanting seedlings',
        'Apply balanced fertilizer if needed',
        'Prune and stake plants',
        'Harvest mature fruits'
      ]
    });
  }
  
  return {
    cropType,
    location: weatherData.location,
    risks,
    summary: {
      goodDays,
      cautionDays,
      riskDays
    }
  };
}
