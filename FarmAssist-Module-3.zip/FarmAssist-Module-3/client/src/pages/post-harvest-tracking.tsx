import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Sprout, 
  Package, 
  Calendar,
  CloudSun,
  MessageSquare,
  DollarSign,
  Camera,
  BookOpen,
  Activity,
  User,
  Plus,
  Save,
  Edit,
  Trash2,
  TrendingUp,
  Archive,
  FileText
} from "lucide-react";

interface HarvestEntry {
  id: string;
  crop: string;
  quantity: number;
  unit: string;
  condition: string;
  purpose: string;
  date: string;
  notes: string;
  timestamp: number;
}

const CROP_OPTIONS = [
  "Tomato",
  "Maize (Corn)",
  "Pepper",
  "Rice",
  "Cassava",
  "Yam",
  "Plantain",
  "Beans",
  "Okra",
  "Sweet Potato",
  "Groundnut",
  "Sorghum"
];

const UNIT_OPTIONS = [
  "kg",
  "bags",
  "heaps",
  "pieces",
  "bundles",
  "tonnes",
  "baskets",
  "crates"
];

const CONDITION_OPTIONS = [
  "Fresh",
  "Stored", 
  "Drying",
  "Spoiled"
];

const PURPOSE_OPTIONS = [
  "Sold",
  "Stored",
  "Home Use",
  "Lost"
];

export default function PostHarvestTracking() {
  const [harvestLogs, setHarvestLogs] = useState<HarvestEntry[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  // Form state
  const [formData, setFormData] = useState({
    crop: '',
    quantity: '',
    unit: '',
    condition: '',
    purpose: '',
    date: new Date().toISOString().split('T')[0], // Today's date
    notes: ''
  });

  // Load harvest logs from localStorage on component mount
  useEffect(() => {
    const savedLogs = localStorage.getItem('harvestLogs');
    if (savedLogs) {
      try {
        const parsedLogs = JSON.parse(savedLogs);
        setHarvestLogs(parsedLogs);
      } catch (error) {
        console.error('Error loading harvest logs:', error);
      }
    }
  }, []);

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.crop || !formData.quantity || !formData.unit || !formData.condition || !formData.purpose) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    if (parseFloat(formData.quantity) <= 0) {
      toast({
        title: "Invalid Quantity",
        description: "Please enter a valid quantity greater than 0",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Create new harvest entry
      const newEntry: HarvestEntry = {
        id: Date.now().toString(),
        crop: formData.crop,
        quantity: parseFloat(formData.quantity),
        unit: formData.unit,
        condition: formData.condition,
        purpose: formData.purpose,
        date: formData.date,
        notes: formData.notes.trim(),
        timestamp: Date.now()
      };

      // Update state and localStorage
      const updatedLogs = [newEntry, ...harvestLogs];
      setHarvestLogs(updatedLogs);
      localStorage.setItem('harvestLogs', JSON.stringify(updatedLogs));

      // Reset form (keep date as today)
      setFormData({
        crop: '',
        quantity: '',
        unit: '',
        condition: '',
        purpose: '',
        date: new Date().toISOString().split('T')[0],
        notes: ''
      });

      toast({
        title: "Harvest Recorded",
        description: `${formData.quantity} ${formData.unit} of ${formData.crop} has been logged`,
      });

    } catch (error) {
      console.error('Error saving harvest entry:', error);
      toast({
        title: "Save Failed",
        description: "Failed to save harvest entry. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Get condition color
  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'Fresh': return 'bg-green-100 text-green-800';
      case 'Stored': return 'bg-blue-100 text-blue-800';
      case 'Drying': return 'bg-yellow-100 text-yellow-800';
      case 'Spoiled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Get purpose color
  const getPurposeColor = (purpose: string) => {
    switch (purpose) {
      case 'Sold': return 'bg-green-100 text-green-800';
      case 'Stored': return 'bg-blue-100 text-blue-800';
      case 'Home Use': return 'bg-purple-100 text-purple-800';
      case 'Lost': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Get crop emoji
  const getCropEmoji = (crop: string) => {
    const cropLower = crop.toLowerCase();
    if (cropLower.includes('tomato')) return '🍅';
    if (cropLower.includes('maize') || cropLower.includes('corn')) return '🌽';
    if (cropLower.includes('pepper')) return '🌶️';
    if (cropLower.includes('rice')) return '🌾';
    if (cropLower.includes('cassava')) return '🥔';
    if (cropLower.includes('yam')) return '🍠';
    if (cropLower.includes('plantain')) return '🍌';
    if (cropLower.includes('beans')) return '🫘';
    if (cropLower.includes('okra')) return '🥒';
    if (cropLower.includes('groundnut')) return '🥜';
    return '🌱';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-farm-green rounded-lg flex items-center justify-center">
                <Package className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">FarmAssist</h1>
                <p className="text-sm text-gray-500">Post-Harvest Tracking</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Link href="/">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <CloudSun className="w-4 h-4 mr-2" />
                  Weather
                </Button>
              </Link>
              <Link href="/photos">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Camera className="w-4 h-4 mr-2" />
                  Photos
                </Button>
              </Link>
              <Link href="/finance">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Finance
                </Button>
              </Link>
              <Link href="/glossary">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Glossary
                </Button>
              </Link>
              <Link href="/monitoring">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Activity className="w-4 h-4 mr-2" />
                  Monitor
                </Button>
              </Link>
              <Link href="/chatbot">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Ask AI
                </Button>
              </Link>
              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                <User className="text-gray-600 text-sm" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Page Title */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Post-Harvest Tracking</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Record and track your harvested crops with details about quantity, condition, and purpose. 
            Keep a complete log of your farm's production.
          </p>
        </div>

        {/* Harvest Entry Form */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Plus className="text-farm-green" />
              <span>Record New Harvest</span>
            </CardTitle>
            <p className="text-sm text-gray-600">
              Enter details about your recent harvest to keep track of production
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                
                {/* Crop Selection */}
                <div>
                  <Label htmlFor="crop" className="block text-sm font-medium text-gray-700 mb-2">
                    Crop Name *
                  </Label>
                  <Select 
                    value={formData.crop} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, crop: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select crop" />
                    </SelectTrigger>
                    <SelectContent>
                      {CROP_OPTIONS.map((crop) => (
                        <SelectItem key={crop} value={crop}>
                          {getCropEmoji(crop)} {crop}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Quantity */}
                <div>
                  <Label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-2">
                    Quantity *
                  </Label>
                  <Input
                    id="quantity"
                    type="number"
                    step="0.1"
                    min="0"
                    placeholder="e.g., 50"
                    value={formData.quantity}
                    onChange={(e) => setFormData(prev => ({ ...prev, quantity: e.target.value }))}
                    disabled={isSubmitting}
                  />
                </div>

                {/* Unit */}
                <div>
                  <Label htmlFor="unit" className="block text-sm font-medium text-gray-700 mb-2">
                    Unit *
                  </Label>
                  <Select 
                    value={formData.unit} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, unit: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select unit" />
                    </SelectTrigger>
                    <SelectContent>
                      {UNIT_OPTIONS.map((unit) => (
                        <SelectItem key={unit} value={unit}>
                          {unit}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Condition */}
                <div>
                  <Label htmlFor="condition" className="block text-sm font-medium text-gray-700 mb-2">
                    Condition *
                  </Label>
                  <Select 
                    value={formData.condition} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, condition: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      {CONDITION_OPTIONS.map((condition) => (
                        <SelectItem key={condition} value={condition}>
                          {condition}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Purpose */}
                <div>
                  <Label htmlFor="purpose" className="block text-sm font-medium text-gray-700 mb-2">
                    Purpose *
                  </Label>
                  <Select 
                    value={formData.purpose} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, purpose: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select purpose" />
                    </SelectTrigger>
                    <SelectContent>
                      {PURPOSE_OPTIONS.map((purpose) => (
                        <SelectItem key={purpose} value={purpose}>
                          {purpose}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Date */}
                <div>
                  <Label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-2">
                    Harvest Date *
                  </Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                    disabled={isSubmitting}
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <Label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-2">
                  Notes (Optional)
                </Label>
                <Textarea
                  id="notes"
                  placeholder="Additional notes about this harvest (e.g., quality, weather conditions, etc.)"
                  rows={3}
                  value={formData.notes}
                  onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  disabled={isSubmitting}
                />
              </div>

              {/* Submit Button */}
              <div className="flex justify-end pt-4">
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="bg-farm-green hover:bg-farm-green/90 text-white px-8 py-2"
                >
                  {isSubmitting ? (
                    <>
                      <span className="animate-spin mr-2">⏳</span>
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Record Harvest
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Harvest Log Display */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Archive className="text-farm-green" />
                <CardTitle>Harvest Log ({harvestLogs.length})</CardTitle>
              </div>
              {harvestLogs.length > 0 && (
                <Badge variant="outline" className="text-farm-green border-farm-green">
                  Total Entries: {harvestLogs.length}
                </Badge>
              )}
            </div>
            <p className="text-sm text-gray-600">
              View all your recorded harvest entries, sorted by most recent
            </p>
          </CardHeader>
          <CardContent>
            {harvestLogs.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No Harvest Records Yet</h3>
                <p className="text-gray-500">
                  Start by recording your first harvest using the form above
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {harvestLogs.map((entry) => (
                  <Card key={entry.id} className="border border-gray-200 hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-start">
                        
                        {/* Crop and Quantity */}
                        <div>
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="text-2xl">{getCropEmoji(entry.crop)}</span>
                            <h4 className="font-semibold text-gray-900">{entry.crop}</h4>
                          </div>
                          <p className="text-lg font-medium text-farm-green">
                            {entry.quantity} {entry.unit}
                          </p>
                        </div>

                        {/* Condition and Purpose */}
                        <div className="space-y-2">
                          <div>
                            <p className="text-xs text-gray-500 uppercase tracking-wide">Condition</p>
                            <Badge className={getConditionColor(entry.condition)}>
                              {entry.condition}
                            </Badge>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 uppercase tracking-wide">Purpose</p>
                            <Badge className={getPurposeColor(entry.purpose)}>
                              {entry.purpose}
                            </Badge>
                          </div>
                        </div>

                        {/* Date */}
                        <div>
                          <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">Date</p>
                          <div className="flex items-center space-x-1">
                            <Calendar className="w-4 h-4 text-gray-400" />
                            <span className="text-sm text-gray-700">{formatDate(entry.date)}</span>
                          </div>
                        </div>

                        {/* Notes */}
                        <div>
                          {entry.notes && (
                            <>
                              <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">Notes</p>
                              <p className="text-sm text-gray-600 italic">"{entry.notes}"</p>
                            </>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Stats (if there are entries) */}
        {harvestLogs.length > 0 && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="text-farm-green" />
                <span>Quick Summary</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-farm-green">{harvestLogs.length}</p>
                  <p className="text-sm text-gray-600">Total Records</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-600">
                    {new Set(harvestLogs.map(log => log.crop)).size}
                  </p>
                  <p className="text-sm text-gray-600">Crop Types</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-600">
                    {harvestLogs.filter(log => log.purpose === 'Sold').length}
                  </p>
                  <p className="text-sm text-gray-600">Sold Batches</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-600">
                    {harvestLogs.filter(log => log.condition === 'Fresh').length}
                  </p>
                  <p className="text-sm text-gray-600">Fresh Harvests</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}