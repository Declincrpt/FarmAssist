import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Thermometer, 
  CloudSun, 
  MessageSquare, 
  DollarSign, 
  Camera, 
  BookOpen, 
  User,
  Settings,
  Wifi,
  Edit,
  Activity,
  Gauge,
  Package
} from "lucide-react";

type MonitoringMode = 'manual' | 'iot' | null;

export default function EnvironmentalMonitoring() {
  const [monitoringMode, setMonitoringMode] = useState<MonitoringMode>(null);

  // Load saved mode from localStorage on component mount
  useEffect(() => {
    const savedMode = localStorage.getItem('environmentalMode') as MonitoringMode;
    if (savedMode) {
      setMonitoringMode(savedMode);
    }
  }, []);

  // Save mode selection to localStorage
  const handleModeSelection = (mode: MonitoringMode) => {
    setMonitoringMode(mode);
    if (mode) {
      localStorage.setItem('environmentalMode', mode);
    }
  };

  // Reset mode selection
  const resetMode = () => {
    setMonitoringMode(null);
    localStorage.removeItem('environmentalMode');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-farm-green rounded-lg flex items-center justify-center">
                <Activity className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">FarmAssist</h1>
                <p className="text-sm text-gray-500">Environmental Monitoring</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Link href="/">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <CloudSun className="w-4 h-4 mr-2" />
                  Weather
                </Button>
              </Link>
              <Link href="/photos">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Camera className="w-4 h-4 mr-2" />
                  Photos
                </Button>
              </Link>
              <Link href="/finance">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Finance
                </Button>
              </Link>
              <Link href="/glossary">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Glossary
                </Button>
              </Link>
              <Link href="/harvest">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Package className="w-4 h-4 mr-2" />
                  Harvest
                </Button>
              </Link>
              <Link href="/chatbot">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Ask AI
                </Button>
              </Link>
              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                <User className="text-gray-600 text-sm" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Page Title */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Environmental Monitoring</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Monitor weather conditions and soil data to get smart farming advice. 
            Choose how you want to collect your environmental data.
          </p>
        </div>

        {!monitoringMode ? (
          /* Mode Selection */
          <div className="max-w-2xl mx-auto">
            <Card className="mb-8">
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center space-x-2 text-2xl">
                  <Settings className="text-farm-green" />
                  <span>Choose Your Monitoring Mode</span>
                </CardTitle>
                <p className="text-gray-600 mt-2">
                  Select how you want to collect environmental data for your farm
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Manual Mode Option */}
                  <Card 
                    className="border-2 border-gray-200 hover:border-farm-green hover:shadow-lg transition-all duration-200 cursor-pointer"
                    onClick={() => handleModeSelection('manual')}
                  >
                    <CardHeader className="text-center">
                      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Edit className="text-blue-600 text-2xl" />
                      </div>
                      <CardTitle className="text-xl text-gray-900">Manual Mode</CardTitle>
                    </CardHeader>
                    <CardContent className="text-center">
                      <p className="text-gray-600 mb-4">
                        Enter soil conditions manually based on your observations and measurements
                      </p>
                      <div className="space-y-2">
                        <Badge variant="outline" className="text-blue-600 border-blue-200">
                          Easy Setup
                        </Badge>
                        <Badge variant="outline" className="text-blue-600 border-blue-200">
                          No Equipment Needed
                        </Badge>
                        <Badge variant="outline" className="text-blue-600 border-blue-200">
                          Full Control
                        </Badge>
                      </div>
                      <Button 
                        className="mt-6 w-full bg-blue-600 hover:bg-blue-700"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleModeSelection('manual');
                        }}
                      >
                        Choose Manual Mode
                      </Button>
                    </CardContent>
                  </Card>

                  {/* IoT Sensor Mode Option */}
                  <Card 
                    className="border-2 border-gray-200 hover:border-farm-green hover:shadow-lg transition-all duration-200 cursor-pointer"
                    onClick={() => handleModeSelection('iot')}
                  >
                    <CardHeader className="text-center">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Wifi className="text-green-600 text-2xl" />
                      </div>
                      <CardTitle className="text-xl text-gray-900">IoT Sensor Mode</CardTitle>
                      <Badge className="bg-orange-100 text-orange-800 text-xs">
                        Simulated
                      </Badge>
                    </CardHeader>
                    <CardContent className="text-center">
                      <p className="text-gray-600 mb-4">
                        Automatically collect soil data from connected sensors (simulated for demo)
                      </p>
                      <div className="space-y-2">
                        <Badge variant="outline" className="text-green-600 border-green-200">
                          Automatic Updates
                        </Badge>
                        <Badge variant="outline" className="text-green-600 border-green-200">
                          Real-time Data
                        </Badge>
                        <Badge variant="outline" className="text-green-600 border-green-200">
                          High Accuracy
                        </Badge>
                      </div>
                      <Button 
                        className="mt-6 w-full bg-green-600 hover:bg-green-700"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleModeSelection('iot');
                        }}
                      >
                        Choose IoT Mode
                      </Button>
                    </CardContent>
                  </Card>
                </div>

                <div className="mt-8 text-center">
                  <p className="text-sm text-gray-500">
                    You can change your monitoring mode anytime in the settings
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          /* Selected Mode Display */
          <div className="space-y-8">
            
            {/* Current Mode Status */}
            <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      monitoringMode === 'manual' ? 'bg-blue-100' : 'bg-green-100'
                    }`}>
                      {monitoringMode === 'manual' ? (
                        <Edit className="text-2xl text-blue-600" />
                      ) : (
                        <Wifi className="text-2xl text-green-600" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">
                        {monitoringMode === 'manual' ? 'Manual Mode Active' : 'IoT Sensor Mode Active'}
                      </h3>
                      <p className="text-gray-600">
                        {monitoringMode === 'manual' 
                          ? 'You are entering environmental data manually'
                          : 'Data is being collected from simulated IoT sensors'
                        }
                      </p>
                    </div>
                  </div>
                  <Button 
                    variant="outline" 
                    onClick={resetMode}
                    className="text-gray-600 border-gray-300 hover:bg-gray-50"
                  >
                    <Settings className="w-4 h-4 mr-2" />
                    Change Mode
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Coming Soon Placeholder */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Gauge className="text-farm-green" />
                  <span>Environmental Dashboard</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 rounded-lg p-8 text-center">
                  <Thermometer className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold text-gray-700 mb-2">
                    {monitoringMode === 'manual' ? 'Manual Data Entry' : 'IoT Sensor Dashboard'}
                  </h4>
                  <p className="text-gray-500">
                    Weather monitoring, soil data collection, and smart farming alerts will be available here soon.
                  </p>
                  <Badge className="mt-4 bg-farm-green text-white">
                    Coming in Next Update
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}