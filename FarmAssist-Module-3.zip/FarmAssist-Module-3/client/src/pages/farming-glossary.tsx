import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  BookOpen, 
  CloudSun, 
  MessageSquare, 
  DollarSign, 
  Camera, 
  User,
  ChevronDown,
  ChevronUp
} from "lucide-react";

// Glossary data structure
const glossaryTerms = [
  {
    id: 1,
    term: "Transplanting",
    category: "Planting",
    definition: "The process of moving seedlings from a nursery bed or seedling tray to the main field where they will grow to maturity. This is commonly done with crops like tomatoes, peppers, and cabbage to give them a strong start before facing field conditions."
  },
  {
    id: 2,
    term: "Leaching",
    category: "Soil",
    definition: "The downward movement of water through soil that carries away nutrients, especially nitrogen and potassium, beyond the reach of plant roots. This can happen during heavy rains or over-watering, leading to nutrient loss and reduced soil fertility."
  },
  {
    id: 3,
    term: "Germination",
    category: "Seeds",
    definition: "The process by which a seed begins to grow and develop into a new plant. It starts when the seed absorbs water and swells, then the root emerges first, followed by the shoot. Proper moisture, temperature, and oxygen are needed for successful germination."
  }
];

export default function FarmingGlossary() {
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedCard, setExpandedCard] = useState<number | null>(null);

  // Filter terms based on search
  const filteredTerms = glossaryTerms.filter(term =>
    term.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    term.definition.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const toggleCard = (id: number) => {
    setExpandedCard(expandedCard === id ? null : id);
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      "Planting": "bg-green-100 text-green-800",
      "Soil": "bg-amber-100 text-amber-800",
      "Seeds": "bg-blue-100 text-blue-800"
    };
    return colors[category as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-farm-green rounded-lg flex items-center justify-center">
                <BookOpen className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">FarmAssist</h1>
                <p className="text-sm text-gray-500">Farming Glossary</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Link href="/">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <CloudSun className="w-4 h-4 mr-2" />
                  Weather
                </Button>
              </Link>
              <Link href="/photos">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Camera className="w-4 h-4 mr-2" />
                  Photos
                </Button>
              </Link>
              <Link href="/finance">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Finance
                </Button>
              </Link>
              <Link href="/chatbot">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Ask AI
                </Button>
              </Link>
              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                <User className="text-gray-600 text-sm" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Page Title */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Farming Glossary</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Learn important farming terms explained in simple language. 
            Perfect for new farmers or anyone wanting to understand agriculture better.
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Search terms... (e.g., 'lea' for Leaching)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-farm-green focus:border-transparent"
            />
          </div>
          {searchTerm && (
            <p className="text-center text-sm text-gray-500 mt-2">
              Showing {filteredTerms.length} result{filteredTerms.length !== 1 ? 's' : ''} for "{searchTerm}"
            </p>
          )}
        </div>

        {/* Terms Count */}
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-semibold text-gray-800">
            Agricultural Terms ({filteredTerms.length})
          </h3>
          <Badge variant="outline" className="text-farm-green border-farm-green">
            English Only
          </Badge>
        </div>

        {/* Glossary Terms */}
        <div className="space-y-4">
          {filteredTerms.length === 0 ? (
            <Card className="text-center p-8">
              <CardContent>
                <p className="text-gray-500 text-lg">No terms found matching "{searchTerm}"</p>
                <p className="text-gray-400 text-sm mt-2">Try searching for terms like "transplanting", "leaching", or "germination"</p>
              </CardContent>
            </Card>
          ) : (
            filteredTerms.map((term) => (
              <Card key={term.id} className="hover:shadow-md transition-shadow duration-200">
                <CardHeader 
                  className="cursor-pointer"
                  onClick={() => toggleCard(term.id)}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <CardTitle className="text-xl text-gray-900">{term.term}</CardTitle>
                        <Badge className={getCategoryColor(term.category)}>
                          {term.category}
                        </Badge>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      {expandedCard === term.id ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </CardHeader>
                
                {expandedCard === term.id && (
                  <CardContent className="pt-0">
                    <div className="border-t pt-4">
                      <p className="text-gray-700 leading-relaxed">
                        {term.definition}
                      </p>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))
          )}
        </div>

        {/* Footer Info */}
        <div className="mt-12 text-center">
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h4 className="font-semibold text-gray-900 mb-2">Coming Soon</h4>
            <p className="text-gray-600 text-sm">
              More terms and multilingual support (Yoruba, Hausa, Swahili) will be added soon!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}