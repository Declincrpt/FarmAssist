import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { 
  Sprout, 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Plus, 
  ShoppingCart, 
  Calendar,
  CloudSun,
  MessageSquare,
  Coins,
  Receipt,
  BarChart3,
  User,
  Camera,
  BookOpen
} from "lucide-react";

// Currency configurations
const CURRENCIES = [
  { code: 'NGN', symbol: '₦', name: 'Nigerian Naira' },
  { code: 'GHS', symbol: '₵', name: 'Ghanaian Cedi' },
  { code: 'CFA', symbol: '₣', name: 'CFA Franc' },
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'GBP', symbol: '£', name: 'British Pound' }
];

const CROP_OPTIONS = [
  { value: "tomato", label: "Tomato" },
  { value: "maize", label: "Maize (Corn)" },
  { value: "pepper", label: "Pepper" },
  { value: "beans", label: "Beans" },
  { value: "cassava", label: "Cassava" },
  { value: "rice", label: "Rice" },
  { value: "yam", label: "Yam" },
  { value: "plantain", label: "Plantain" }
];

interface FarmInput {
  id: string;
  name: string;
  amount: number;
  crop: string;
  date: string;
  timestamp: number;
}

interface FarmOutput {
  id: string;
  crop: string;
  quantity: number;
  pricePerUnit: number;
  totalRevenue: number;
  date: string;
  timestamp: number;
}

interface CropSummary {
  crop: string;
  totalCost: number;
  totalRevenue: number;
  netProfit: number;
  status: 'profit' | 'loss' | 'breakeven';
}

export default function FarmFinance() {
  const [selectedCurrency, setSelectedCurrency] = useState('NGN');
  const [farmInputs, setFarmInputs] = useState<FarmInput[]>([]);
  const [farmOutputs, setFarmOutputs] = useState<FarmOutput[]>([]);
  const { toast } = useToast();

  // Input form states
  const [inputForm, setInputForm] = useState({
    name: '',
    amount: '',
    crop: '',
    date: new Date().toISOString().split('T')[0]
  });

  // Output form states
  const [outputForm, setOutputForm] = useState({
    crop: '',
    quantity: '',
    pricePerUnit: '',
    date: new Date().toISOString().split('T')[0]
  });

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedCurrency = localStorage.getItem('farmCurrency');
    const savedInputs = localStorage.getItem('farmInputs');
    const savedOutputs = localStorage.getItem('farmOutputs');

    if (savedCurrency) setSelectedCurrency(savedCurrency);
    if (savedInputs) setFarmInputs(JSON.parse(savedInputs));
    if (savedOutputs) setFarmOutputs(JSON.parse(savedOutputs));
  }, []);

  // Save currency to localStorage
  const handleCurrencyChange = (currency: string) => {
    setSelectedCurrency(currency);
    localStorage.setItem('farmCurrency', currency);
    toast({
      title: "Currency Updated",
      description: `Currency changed to ${CURRENCIES.find(c => c.code === currency)?.name}`,
    });
  };

  // Get currency symbol
  const getCurrencySymbol = () => {
    return CURRENCIES.find(c => c.code === selectedCurrency)?.symbol || '₦';
  };

  // Handle input form submission
  const handleInputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputForm.name || !inputForm.amount || !inputForm.crop || !inputForm.date) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    const amount = parseFloat(inputForm.amount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    const newInput: FarmInput = {
      id: Date.now().toString(),
      name: inputForm.name,
      amount,
      crop: inputForm.crop,
      date: inputForm.date,
      timestamp: Date.now()
    };

    const updatedInputs = [...farmInputs, newInput];
    setFarmInputs(updatedInputs);
    localStorage.setItem('farmInputs', JSON.stringify(updatedInputs));

    // Reset form
    setInputForm({
      name: '',
      amount: '',
      crop: '',
      date: new Date().toISOString().split('T')[0]
    });

    toast({
      title: "Expense Added",
      description: `${inputForm.name} recorded for ${getCurrencySymbol()}${amount.toLocaleString()}`,
    });
  };

  // Handle output form submission
  const handleOutputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!outputForm.crop || !outputForm.quantity || !outputForm.pricePerUnit || !outputForm.date) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    const quantity = parseFloat(outputForm.quantity);
    const pricePerUnit = parseFloat(outputForm.pricePerUnit);
    
    if (isNaN(quantity) || quantity <= 0 || isNaN(pricePerUnit) || pricePerUnit <= 0) {
      toast({
        title: "Invalid Values",
        description: "Please enter valid quantity and price",
        variant: "destructive",
      });
      return;
    }

    const totalRevenue = quantity * pricePerUnit;

    const newOutput: FarmOutput = {
      id: Date.now().toString(),
      crop: outputForm.crop,
      quantity,
      pricePerUnit,
      totalRevenue,
      date: outputForm.date,
      timestamp: Date.now()
    };

    const updatedOutputs = [...farmOutputs, newOutput];
    setFarmOutputs(updatedOutputs);
    localStorage.setItem('farmOutputs', JSON.stringify(updatedOutputs));

    // Reset form
    setOutputForm({
      crop: '',
      quantity: '',
      pricePerUnit: '',
      date: new Date().toISOString().split('T')[0]
    });

    toast({
      title: "Sale Recorded",
      description: `${outputForm.crop} sale recorded for ${getCurrencySymbol()}${totalRevenue.toLocaleString()}`,
    });
  };

  // Calculate crop summaries
  const getCropSummaries = (): CropSummary[] => {
    const crops = new Set([...farmInputs.map(i => i.crop), ...farmOutputs.map(o => o.crop)]);
    
    return Array.from(crops).map(crop => {
      const totalCost = farmInputs
        .filter(input => input.crop === crop)
        .reduce((sum, input) => sum + input.amount, 0);

      const totalRevenue = farmOutputs
        .filter(output => output.crop === crop)
        .reduce((sum, output) => sum + output.totalRevenue, 0);

      const netProfit = totalRevenue - totalCost;
      
      let status: 'profit' | 'loss' | 'breakeven' = 'breakeven';
      if (netProfit > 0) status = 'profit';
      else if (netProfit < 0) status = 'loss';

      return {
        crop,
        totalCost,
        totalRevenue,
        netProfit,
        status
      };
    }).filter(summary => summary.totalCost > 0 || summary.totalRevenue > 0);
  };

  const cropSummaries = getCropSummaries();

  // Get status styling
  const getStatusStyling = (status: string) => {
    switch (status) {
      case 'profit':
        return {
          bg: 'bg-green-50 border-green-200',
          text: 'text-green-800',
          icon: <TrendingUp className="w-5 h-5 text-green-600" />,
          badge: 'bg-green-100 text-green-800'
        };
      case 'loss':
        return {
          bg: 'bg-red-50 border-red-200',
          text: 'text-red-800',
          icon: <TrendingDown className="w-5 h-5 text-red-600" />,
          badge: 'bg-red-100 text-red-800'
        };
      default:
        return {
          bg: 'bg-yellow-50 border-yellow-200',
          text: 'text-yellow-800',
          icon: <Minus className="w-5 h-5 text-yellow-600" />,
          badge: 'bg-yellow-100 text-yellow-800'
        };
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-farm-green rounded-lg flex items-center justify-center">
                <Sprout className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">FarmAssist</h1>
                <p className="text-sm text-gray-500">Financial Tracker</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Link href="/">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <CloudSun className="w-4 h-4 mr-2" />
                  Weather
                </Button>
              </Link>
              <Link href="/photos">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Camera className="w-4 h-4 mr-2" />
                  Photos
                </Button>
              </Link>
              <Link href="/finance">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Finance
                </Button>
              </Link>
              <Link href="/glossary">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Glossary
                </Button>
              </Link>
              <Link href="/chatbot">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Ask AI
                </Button>
              </Link>
              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                <User className="text-gray-600 text-sm" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Currency Selection */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-farm-green/10 rounded-lg flex items-center justify-center">
                <Coins className="text-farm-green" />
              </div>
              <h2 className="text-lg font-semibold text-gray-900">Currency Settings</h2>
            </div>
            <div className="max-w-md">
              <Label htmlFor="currency" className="block text-sm font-medium text-gray-700 mb-2">
                Select Your Currency
              </Label>
              <Select value={selectedCurrency} onValueChange={handleCurrencyChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.symbol} {currency.name} ({currency.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Input (Expense) Logging */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Receipt className="text-red-600" />
                <span>Farm Expenses</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleInputSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="expense-name">Expense Name</Label>
                  <Input
                    id="expense-name"
                    placeholder="e.g., Fertilizer, Seeds, Labor"
                    value={inputForm.name}
                    onChange={(e) => setInputForm(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="expense-amount">Amount ({getCurrencySymbol()})</Label>
                  <Input
                    id="expense-amount"
                    type="number"
                    step="0.01"
                    placeholder="e.g., 2500"
                    value={inputForm.amount}
                    onChange={(e) => setInputForm(prev => ({ ...prev, amount: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="expense-crop">Crop</Label>
                  <Select value={inputForm.crop} onValueChange={(value) => setInputForm(prev => ({ ...prev, crop: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select crop" />
                    </SelectTrigger>
                    <SelectContent>
                      {CROP_OPTIONS.map((crop) => (
                        <SelectItem key={crop.value} value={crop.value}>
                          {crop.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="expense-date">Date</Label>
                  <Input
                    id="expense-date"
                    type="date"
                    value={inputForm.date}
                    onChange={(e) => setInputForm(prev => ({ ...prev, date: e.target.value }))}
                  />
                </div>
                <Button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Expense
                </Button>
              </form>

              {/* Recent Expenses */}
              {farmInputs.length > 0 && (
                <div className="mt-6">
                  <h4 className="font-medium text-gray-900 mb-3">Recent Expenses</h4>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {farmInputs.slice(-5).reverse().map((input) => (
                      <div key={input.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <div>
                          <span className="font-medium">{input.name}</span>
                          <div className="text-sm text-gray-600 capitalize">{input.crop} • {input.date}</div>
                        </div>
                        <span className="font-medium text-red-600">
                          -{getCurrencySymbol()}{input.amount.toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Output (Sales) Logging */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <ShoppingCart className="text-green-600" />
                <span>Farm Sales</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleOutputSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="sales-crop">Crop</Label>
                  <Select value={outputForm.crop} onValueChange={(value) => setOutputForm(prev => ({ ...prev, crop: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select crop" />
                    </SelectTrigger>
                    <SelectContent>
                      {CROP_OPTIONS.map((crop) => (
                        <SelectItem key={crop.value} value={crop.value}>
                          {crop.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="sales-quantity">Quantity Harvested</Label>
                  <Input
                    id="sales-quantity"
                    type="number"
                    step="0.01"
                    placeholder="e.g., 100 (kg, bags, pieces)"
                    value={outputForm.quantity}
                    onChange={(e) => setOutputForm(prev => ({ ...prev, quantity: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="sales-price">Price per Unit ({getCurrencySymbol()})</Label>
                  <Input
                    id="sales-price"
                    type="number"
                    step="0.01"
                    placeholder="e.g., 150"
                    value={outputForm.pricePerUnit}
                    onChange={(e) => setOutputForm(prev => ({ ...prev, pricePerUnit: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="sales-date">Date</Label>
                  <Input
                    id="sales-date"
                    type="date"
                    value={outputForm.date}
                    onChange={(e) => setOutputForm(prev => ({ ...prev, date: e.target.value }))}
                  />
                </div>
                <Button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Record Sale
                </Button>
              </form>

              {/* Recent Sales */}
              {farmOutputs.length > 0 && (
                <div className="mt-6">
                  <h4 className="font-medium text-gray-900 mb-3">Recent Sales</h4>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {farmOutputs.slice(-5).reverse().map((output) => (
                      <div key={output.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <div>
                          <span className="font-medium capitalize">{output.crop}</span>
                          <div className="text-sm text-gray-600">
                            {output.quantity} units @ {getCurrencySymbol()}{output.pricePerUnit} • {output.date}
                          </div>
                        </div>
                        <span className="font-medium text-green-600">
                          +{getCurrencySymbol()}{output.totalRevenue.toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Profit/Loss Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="text-farm-green" />
              <span>Profit & Loss Summary</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {cropSummaries.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <BarChart3 className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No financial data yet. Start by adding expenses and recording sales.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {cropSummaries.map((summary) => {
                  const styling = getStatusStyling(summary.status);
                  const cropEmoji = summary.crop === 'tomato' ? '🍅' : 
                                   summary.crop === 'maize' ? '🌽' : 
                                   summary.crop === 'pepper' ? '🌶️' : 
                                   summary.crop === 'beans' ? '🫘' : 
                                   summary.crop === 'rice' ? '🌾' : '🌱';
                  
                  return (
                    <div key={summary.crop} className={`p-4 rounded-lg border-2 ${styling.bg}`}>
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-2">
                          <span className="text-2xl">{cropEmoji}</span>
                          <h3 className={`font-semibold capitalize ${styling.text}`}>
                            {summary.crop}
                          </h3>
                        </div>
                        {styling.icon}
                      </div>
                      
                      <div className="space-y-2 text-sm mb-3">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Expenses:</span>
                          <span className="font-medium text-red-600">
                            {getCurrencySymbol()}{summary.totalCost.toLocaleString()}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Revenue:</span>
                          <span className="font-medium text-green-600">
                            {getCurrencySymbol()}{summary.totalRevenue.toLocaleString()}
                          </span>
                        </div>
                        <Separator />
                        <div className="flex justify-between">
                          <span className="font-medium">Net Result:</span>
                          <span className={`font-bold ${styling.text}`}>
                            {summary.netProfit >= 0 ? '+' : ''}
                            {getCurrencySymbol()}{summary.netProfit.toLocaleString()}
                          </span>
                        </div>
                      </div>
                      
                      <Badge className={styling.badge}>
                        {summary.status === 'profit' ? 'Profitable ✅' : 
                         summary.status === 'loss' ? 'Loss ❌' : 
                         'Break-even ➖'}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}