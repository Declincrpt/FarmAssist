import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Sprout, MapPin, CloudSun, Brain, Search, User, Droplets, Cloud, Sun, CloudRain, AlertTriangle, CircleAlert, CheckCircle, TrendingUp, Calendar, MessageSquare, Bot, DollarSign, Camera, BookOpen, Activity, Package } from "lucide-react";
import type { WeatherData, CropAdvisoryData } from "@shared/schema";

const CROP_OPTIONS = [
  { value: "tomato", label: "Tomato" },
  { value: "maize", label: "Maize (Corn)" },
  { value: "pepper", label: "Pepper" },
];

const getWeatherIcon = (description: string, isToday = false) => {
  const desc = description.toLowerCase();
  if (desc.includes('rain')) return <CloudRain className={isToday ? "text-yellow-300" : "text-blue-500"} />;
  if (desc.includes('cloud')) return <Cloud className={isToday ? "text-yellow-300" : "text-gray-400"} />;
  if (desc.includes('sun') || desc.includes('clear')) return <Sun className={isToday ? "text-yellow-300" : "text-yellow-500"} />;
  return <CloudSun className={isToday ? "text-yellow-300" : "text-gray-400"} />;
};

const getRiskIcon = (level: string) => {
  switch (level) {
    case 'high': return <AlertTriangle className="text-red-500" />;
    case 'medium': return <CircleAlert className="text-amber-500" />;
    case 'low': return <CheckCircle className="text-green-500" />;
    default: return <CheckCircle className="text-green-500" />;
  }
};

const getRiskColor = (level: string) => {
  switch (level) {
    case 'high': return 'border-red-500 bg-red-50';
    case 'medium': return 'border-amber-500 bg-amber-50';
    case 'low': return 'border-green-500 bg-green-50';
    default: return 'border-green-500 bg-green-50';
  }
};

const getRiskTextColor = (level: string) => {
  switch (level) {
    case 'high': return 'text-red-800';
    case 'medium': return 'text-amber-800';
    case 'low': return 'text-green-800';
    default: return 'text-green-800';
  }
};

const getRiskBgColor = (level: string) => {
  switch (level) {
    case 'high': return 'bg-red-100';
    case 'medium': return 'bg-amber-100';
    case 'low': return 'bg-green-100';
    default: return 'bg-green-100';
  }
};

export default function WeatherDashboard() {
  const [location, setLocation] = useState("");
  const [selectedCrop, setSelectedCrop] = useState("");
  const [activeLocation, setActiveLocation] = useState("");
  const { toast } = useToast();

  const { data: weatherData, isLoading: weatherLoading, error: weatherError } = useQuery<WeatherData>({
    queryKey: ['/api/weather', activeLocation],
    enabled: !!activeLocation,
  });

  const advisoryMutation = useMutation({
    mutationFn: async ({ location, cropType }: { location: string, cropType: string }) => {
      const response = await fetch('/api/advisory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ location, cropType }),
      });
      if (!response.ok) {
        throw new Error(`Failed to get advisory: ${response.statusText}`);
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/weather'] });
    },
    onError: (error) => {
      toast({
        title: "Advisory Error",
        description: (error as Error).message,
        variant: "destructive",
      });
    },
  });

  const handleGetWeather = () => {
    if (!location.trim()) {
      toast({
        title: "Location Required",
        description: "Please enter a city or region",
        variant: "destructive",
      });
      return;
    }
    setActiveLocation(location.trim());
  };

  const handleGetAdvisory = () => {
    if (!activeLocation) {
      toast({
        title: "Get Weather First",
        description: "Please get weather data before requesting crop advisory",
        variant: "destructive",
      });
      return;
    }
    if (!selectedCrop) {
      toast({
        title: "Select Crop",
        description: "Please select a crop type for advisory",
        variant: "destructive",
      });
      return;
    }
    advisoryMutation.mutate({ location: activeLocation, cropType: selectedCrop });
  };

  const advisoryData = advisoryMutation.data as CropAdvisoryData | undefined;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-farm-green rounded-lg flex items-center justify-center">
                <Sprout className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">FarmAssist</h1>
                <p className="text-sm text-gray-500">Weather & Crop Advisory</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Link href="/photos">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Camera className="w-4 h-4 mr-2" />
                  Photos
                </Button>
              </Link>
              <Link href="/finance">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Finance
                </Button>
              </Link>
              <Link href="/glossary">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Glossary
                </Button>
              </Link>
              <Link href="/monitoring">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Activity className="w-4 h-4 mr-2" />
                  Monitor
                </Button>
              </Link>
              <Link href="/harvest">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Package className="w-4 h-4 mr-2" />
                  Harvest
                </Button>
              </Link>
              <Link href="/chatbot">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Ask AI
                </Button>
              </Link>
              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                <User className="text-gray-600 text-sm" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Location Input */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-sky-blue/10 rounded-lg flex items-center justify-center">
                <MapPin className="text-sky-blue" />
              </div>
              <h2 className="text-lg font-semibold text-gray-900">Location & Crop Selection</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                  Farm Location
                </Label>
                <div className="relative">
                  <Input
                    id="location"
                    type="text"
                    placeholder="Enter city or region (e.g., Nairobi, Kenya)"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleGetWeather()}
                    className="pr-24"
                  />
                  <Button
                    onClick={handleGetWeather}
                    disabled={weatherLoading}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-farm-green hover:bg-emerald-600 text-white px-4 py-1.5 h-auto text-sm"
                  >
                    <Search className="w-3 h-3 mr-1" />
                    Get Weather
                  </Button>
                </div>
              </div>
              
              <div>
                <Label htmlFor="crop" className="block text-sm font-medium text-gray-700 mb-2">
                  Crop Type
                </Label>
                <Select value={selectedCrop} onValueChange={setSelectedCrop}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your crop" />
                  </SelectTrigger>
                  <SelectContent>
                    {CROP_OPTIONS.map((crop) => (
                      <SelectItem key={crop.value} value={crop.value}>
                        {crop.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {selectedCrop && activeLocation && (
              <div className="mt-4">
                <Button
                  onClick={handleGetAdvisory}
                  disabled={advisoryMutation.isPending}
                  className="bg-farm-green hover:bg-emerald-600 text-white"
                >
                  <Brain className="w-4 h-4 mr-2" />
                  {advisoryMutation.isPending ? 'Generating Advisory...' : 'Get Crop Advisory'}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Weather Error */}
        {weatherError && (
          <Card className="mb-8 border-red-200 bg-red-50">
            <CardContent className="p-6">
              <div className="flex items-center text-red-800">
                <AlertTriangle className="w-5 h-5 mr-2" />
                <span>Failed to fetch weather data. Please check your location and try again.</span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Weather Forecast */}
        {weatherData && (
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-sky-blue/10 rounded-lg flex items-center justify-center">
                    <CloudSun className="text-sky-blue" />
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold text-gray-900">7-Day Weather Forecast</h2>
                    <p className="text-sm text-gray-500">{weatherData.location}</p>
                  </div>
                </div>
                <div className="text-sm text-gray-500 flex items-center">
                  <Calendar className="w-4 h-4 mr-1" />
                  <span>Updated {new Date(weatherData.lastUpdated).toLocaleString()}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-4">
                {weatherData.days.map((day, index) => (
                  <div
                    key={day.date}
                    className={index === 0 ? "gradient-today text-white rounded-lg p-4 relative overflow-hidden" : "bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"}
                  >
                    <div className="relative z-10">
                      <div className="flex items-center justify-between mb-2">
                        <span className={`text-sm font-medium ${index === 0 ? 'text-white' : 'text-gray-600'}`}>
                          {day.dayLabel}
                        </span>
                        {getWeatherIcon(day.description, index === 0)}
                      </div>
                      <div className={`text-2xl font-bold mb-1 ${index === 0 ? 'text-white' : 'text-gray-900'}`}>
                        {day.temperature}°C
                      </div>
                      <div className={`text-sm mb-2 ${index === 0 ? 'text-white opacity-90' : 'text-gray-600'}`}>
                        {day.description}
                      </div>
                      <div className={`text-xs space-y-1 ${index === 0 ? 'text-white' : 'text-gray-500'}`}>
                        <div className="flex items-center">
                          <Droplets className="w-3 h-3 mr-2" />
                          <span>{day.humidity}%</span>
                        </div>
                        <div className="flex items-center">
                          <CloudRain className="w-3 h-3 mr-2" />
                          <span>{day.rainfall}mm</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Crop Advisory */}
        {advisoryData && (
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-8 h-8 bg-farm-green/10 rounded-lg flex items-center justify-center">
                  <Brain className="text-farm-green" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">AI Crop Advisory</h2>
                  <p className="text-sm text-gray-500">
                    Weather-based risk analysis for <span className="font-medium capitalize">{advisoryData.cropType}</span>
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                {advisoryData.risks.map((risk, index) => (
                  <div key={index} className={`border-l-4 ${getRiskColor(risk.level)} p-4 rounded-r-lg`}>
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        {getRiskIcon(risk.level)}
                      </div>
                      <div className="ml-3">
                        <h3 className={`text-sm font-medium ${getRiskTextColor(risk.level)}`}>
                          {risk.title}
                        </h3>
                        <div className={`mt-2 text-sm ${getRiskTextColor(risk.level)}`}>
                          <p>{risk.description}</p>
                        </div>
                        <div className="mt-3">
                          <div className={`${getRiskBgColor(risk.level)} rounded-lg p-3`}>
                            <h4 className={`text-sm font-medium ${getRiskTextColor(risk.level)} mb-2 flex items-center`}>
                              <TrendingUp className="w-4 h-4 mr-1" />
                              Recommended Actions:
                            </h4>
                            <ul className={`text-sm ${getRiskTextColor(risk.level)} space-y-1`}>
                              {risk.actions.map((action, actionIndex) => (
                                <li key={actionIndex}>• {action}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Weekly Summary */}
              <div className="mt-6 bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Week Summary for {advisoryData.cropType.charAt(0).toUpperCase() + advisoryData.cropType.slice(1)} Cultivation
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{advisoryData.summary.goodDays}</div>
                    <div className="text-gray-600">Good Days</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-amber-600">{advisoryData.summary.cautionDays}</div>
                    <div className="text-gray-600">Caution Days</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-600">{advisoryData.summary.riskDays}</div>
                    <div className="text-gray-600">High Risk Days</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
