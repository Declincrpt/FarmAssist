# Weather & Crop Advisory Application

## Overview

This is a full-stack TypeScript application that provides weather forecasting and crop advisory services for farmers. The application consists of a React frontend with a modern UI built using shadcn/ui components, and an Express backend that serves weather data and provides intelligent crop recommendations based on weather conditions.

**Current Status**: Core functionality is complete and working. The system includes weather forecasting, AI chatbot, financial tracking, and photo journal features. Ready for production use once the OpenWeatherMap API key is provided.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **API Design**: RESTful API endpoints for weather and advisory data
- **Data Storage**: In-memory storage with interface for future database integration
- **External APIs**: OpenWeather API integration for real-time weather data

### Database Schema (Prepared for PostgreSQL)
The application is configured with Drizzle ORM and has schema definitions ready for PostgreSQL:
- `weather_forecasts` table: Stores weather data with location and forecast information
- `crop_advisories` table: Stores crop-specific recommendations with risk levels

## Key Components

### Weather Service
- **Purpose**: Fetches and processes weather data from OpenWeather API
- **Features**: 7-day weather forecasts with temperature, humidity, and rainfall data
- **Caching**: Weather data is cached to reduce API calls

### Crop Advisory System
- **Purpose**: Provides intelligent farming recommendations based on weather conditions
- **Supported Crops**: Tomato, Maize, Pepper with crop-specific thresholds
- **Risk Assessment**: Categorizes risks as low, medium, or high based on weather parameters
- **Actionable Advice**: Provides specific farming actions for each weather condition

### Frontend Components
- **Weather Dashboard**: Main interface displaying weather forecasts and crop advisories
- **AI Chatbot**: Smart Q&A system for farming questions with keyword matching
- **Financial Tracker**: Expense logging, sales recording, and profit/loss analysis per crop
- **Photo Journal**: Offline-capable image logging with notes and timeline display
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Interactive Elements**: Search functionality, crop selection, detailed weather cards, chat interface, financial forms, and photo upload

## Data Flow

### Weather & Advisory System
1. **User Input**: User enters location and selects crop type
2. **Weather Fetch**: Backend retrieves weather data from OpenWeather API
3. **Data Processing**: Weather data is processed and stored in memory
4. **Risk Analysis**: Crop advisory system analyzes weather against crop-specific thresholds
5. **Response Generation**: Backend generates risk assessments and actionable recommendations
6. **Frontend Display**: React components render weather forecasts and advisory information

### Financial Tracking System
1. **Currency Selection**: User chooses local currency (NGN, GHS, CFA, USD, GBP)
2. **Expense Logging**: Users record farm inputs (fertilizer, seeds, labor) with amounts and crop association
3. **Sales Recording**: Users log harvest sales with quantity, price per unit, and total revenue
4. **Data Persistence**: All financial data stored in browser localStorage for offline access
5. **Profit Analysis**: System calculates profit/loss per crop and displays visual summaries with status indicators

### Photo Journal System
1. **Image Upload**: Users upload crop photos with file validation (type and size limits)
2. **Base64 Conversion**: Images converted to base64 strings for offline storage capability
3. **Entry Creation**: Photos saved with crop name, date, and optional notes in localStorage
4. **Timeline Display**: Visual timeline showing photo entries in reverse chronological order
5. **Offline Operation**: Complete functionality without internet connection or backend dependencies

## External Dependencies

### Backend Dependencies
- **@neondatabase/serverless**: PostgreSQL database driver (configured but not actively used)
- **drizzle-orm**: Type-safe database ORM
- **express**: Web framework
- **zod**: Schema validation

### Frontend Dependencies
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components
- **tailwindcss**: Utility-first CSS framework
- **wouter**: Lightweight routing library
- **lucide-react**: Icon library

### External APIs
- **OpenWeather API**: Real-time weather data source
- Requires API key configuration via environment variables

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR (Hot Module Replacement)
- **Backend**: tsx for TypeScript execution with automatic restarts
- **Integration**: Backend serves frontend in development via Vite middleware

### Production
- **Build Process**: 
  - Frontend built to static assets via Vite
  - Backend compiled to ESM bundle via esbuild
- **Serving**: Express serves both API routes and static frontend assets
- **Environment**: Node.js production environment with optimized builds

### Configuration
- **Database**: Configured for PostgreSQL via Drizzle with migration support
- **Environment Variables**: 
  - `DATABASE_URL` for PostgreSQL connection
  - `OPENWEATHER_API_KEY` for weather API access
- **TypeScript**: Strict mode enabled with path aliases for clean imports

The architecture supports easy scaling from the current in-memory storage to PostgreSQL by simply providing a database connection string, as all the ORM setup and schema definitions are already in place.