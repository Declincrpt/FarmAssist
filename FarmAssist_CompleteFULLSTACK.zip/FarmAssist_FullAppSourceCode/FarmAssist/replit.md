# FarmAssist - Smart Planting Calculator

## Overview

FarmAssist is a comprehensive farm management web application that helps farmers optimize their crop planning and track farming tasks throughout the growing season. The application provides planting calculations, task management, and progress tracking for various crops and farming methods.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18+ with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: TailwindCSS with custom CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Icons**: Lucide React for consistent iconography

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ESM modules
- **API Pattern**: RESTful API with type-safe endpoints
- **Development**: TSX for TypeScript execution with hot reload
- **Production**: ESBuild for server bundling

### Data Layer
- **Database**: PostgreSQL via Neon Database hosting
- **ORM**: Drizzle ORM for type-safe database operations
- **Connection**: @neondatabase/serverless with WebSocket support for edge compatibility
- **Migrations**: Drizzle Kit for schema management
- **Schema Location**: Shared TypeScript schema definitions

## Key Components

### 1. Database Schema
- **Users Table**: Farmer profiles with authentication data
- **Crops Table**: Master list of supported crops with scientific names
- **Planting Styles Table**: Different farming methods per crop (greenhouse, open field, etc.)
- **Farm Calculations Table**: Historical planting calculations and requirements
- **Task Progress Table**: Day-by-day farming tasks with completion tracking

### 2. Frontend Components
- **Farm Dashboard**: Main interface for task management and progress tracking
- **Shadcn/ui Components**: Comprehensive UI component library including:
  - Cards, Dialogs, Forms, Buttons
  - Data tables, Charts, Progress indicators
  - Navigation, Tooltips, Toast notifications

### 3. API Layer
- **Crop Management**: Endpoints for fetching crops and planting styles
- **Farm Calculations**: Save and retrieve planting calculations
- **Task Management**: CRUD operations for farming tasks
- **Progress Tracking**: Mark tasks complete with notes and timestamps

### 4. State Management
- **TanStack Query**: Server state management with caching and background updates
- **React Hooks**: Local state management for UI interactions
- **Form Handling**: React Hook Form with Zod validation

## Data Flow

1. **User Input**: Farmers input farm size, crop type, and planting method
2. **Calculation Engine**: Backend calculates plant requirements, yields, and resource needs
3. **Task Generation**: System creates day-by-day farming tasks based on crop calendar
4. **Progress Tracking**: Users mark tasks complete with optional notes
5. **Data Persistence**: All data stored in PostgreSQL with real-time updates

## External Dependencies

### Production Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI component primitives
- **react-hook-form**: Form state management
- **zod**: Runtime type validation
- **wouter**: Client-side routing

### Development Dependencies
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for development
- **esbuild**: Production server bundling
- **tailwindcss**: Utility-first CSS framework
- **@replit/vite-plugin-***: Replit-specific development enhancements

## Deployment Strategy

### Development Environment
- **Vite Dev Server**: Frontend development with HMR
- **TSX Execution**: Backend development with auto-restart
- **Database**: Neon PostgreSQL with connection pooling
- **Environment**: Replit environment with integrated development tools

### Production Build
- **Frontend**: Vite builds optimized static assets to `/dist/public`
- **Backend**: ESBuild bundles server to `/dist/index.js`
- **Static Serving**: Express serves built frontend assets
- **Database**: Production Neon PostgreSQL instance

### Architecture Decisions

1. **Monorepo Structure**: Frontend, backend, and shared code in single repository for easier development
2. **Type Safety**: End-to-end TypeScript with shared schema definitions
3. **Modern Stack**: Latest React patterns with server components preparation
4. **Database Choice**: PostgreSQL for relational data integrity and complex queries
5. **Edge Compatibility**: Neon serverless for global performance and scalability
6. **Component Library**: Shadcn/ui for consistent, accessible, and customizable UI components
7. **State Management**: TanStack Query for efficient server state with optimistic updates
8. **Build Optimization**: Separate frontend/backend builds for optimal performance

## Recent Changes - Stage 4 Implementation

### Recordkeeping System Completed (July 26, 2025)
- ✅ Integrated original FarmAssist HTML/CSS/JS application with modern React/TypeScript framework  
- ✅ Created comprehensive crop database from original script with 6 crops and task calendars
- ✅ Built farm calculator page with land size inputs, crop selection, and yield calculations
- ✅ Implemented task management dashboard with daily task calendar from original crop data
- ✅ Added "Mark as Done" functionality for each farming task with notes
- ✅ Created PostgreSQL database with proper schema for users, crops, calculations, and task progress
- ✅ Built recordkeeping log showing completed tasks with timestamps and farmer notes
- ✅ Added navigation between Calculator and Tasks pages
- ✅ Database seeded with tomato crop tasks and sample farm calculation
- ✅ Real-time task completion tracking integrated with backend API

### Technical Integration Details
- Preserved all original crop data (CROP_DATABASE) and task calendars (CROP_TASK_CALENDAR)
- Integrated complete Extension Intelligence Engine (EXTENSION_TIPS) with expert farming advice
- Converted static JavaScript logic to TypeScript with proper type safety
- Maintained Bootstrap styling concepts using shadcn/ui components and Tailwind CSS
- Connected frontend to PostgreSQL database via Drizzle ORM
- Task completion flow: Click "Mark Done" → Add notes → Save to database → Update completion log
- Extension Intelligence Engine: Select crop → Filter by day/category → View expert tips with priority levels

## Extension Intelligence Engine (AI Agronomist/Digital Extension Advisor)

### Overview
The Extension Intelligence Engine is the AI agronomist component that provides expert farming advice and tips filtered by crop type, growth stage, and farming activity category. This feature replicates the digital extension advisor from the original FarmAssist application.

### Features
- **Expert Tips Database**: Comprehensive farming advice for all 6 crops with day-specific guidance
- **Smart Filtering**: Filter tips by growth stage (days 1-30, 31-60, 61-90, 91-120) and category
- **Priority Levels**: Tips categorized as Critical, Important, Helpful, or Optional
- **Professional Categories**: Preparation, Planting, Watering, Fertilization, Maintenance, Pest Control, Disease Control, Monitoring, Harvesting
- **Navigation Integration**: Accessible via "AI Advisor" tab in main navigation

### Implementation
- **Frontend**: React component with shadcn/ui components for filtering and display
- **Data Source**: Shared TypeScript module with complete tip database from original script
- **User Interface**: Cards with priority badges, category tags, and day indicators
- **Expert Content**: 100+ professional farming tips across all supported crops