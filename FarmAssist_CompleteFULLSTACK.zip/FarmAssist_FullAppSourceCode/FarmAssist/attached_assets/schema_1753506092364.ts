import { pgTable, serial, text, integer, varchar, timestamp, boolean, date, decimal } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table - for farmer profiles
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  username: varchar('username', { length: 50 }).notNull().unique(),
  email: varchar('email', { length: 100 }).notNull().unique(),
  fullName: varchar('full_name', { length: 100 }).notNull(),
  phoneNumber: varchar('phone_number', { length: 20 }),
  location: varchar('location', { length: 100 }),
  farmSize: decimal('farm_size', { precision: 10, scale: 2 }), // in hectares
  experienceLevel: varchar('experience_level', { length: 20 }), // beginner, intermediate, advanced
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Farm calculations history
export const farmCalculations = pgTable('farm_calculations', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  landSize: decimal('land_size', { precision: 10, scale: 2 }).notNull(),
  landUnit: varchar('land_unit', { length: 20 }).notNull(), // acres, hectares, sqmeters, plots
  cropType: varchar('crop_type', { length: 50 }).notNull(),
  plantingStyle: varchar('planting_style', { length: 50 }).notNull(),
  plantsNeeded: integer('plants_needed').notNull(),
  expectedYield: decimal('expected_yield', { precision: 10, scale: 2 }).notNull(), // in kg
  fertilizerRequired: decimal('fertilizer_required', { precision: 10, scale: 2 }).notNull(), // in kg
  manureRequired: decimal('manure_required', { precision: 10, scale: 2 }).notNull(), // in kg
  waterRequired: decimal('water_required', { precision: 10, scale: 2 }), // liters per week
  createdAt: timestamp('created_at').defaultNow().notNull()
});

// Crop task progress tracking
export const taskProgress = pgTable('task_progress', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  farmCalculationId: integer('farm_calculation_id').references(() => farmCalculations.id),
  cropType: varchar('crop_type', { length: 50 }).notNull(),
  taskDay: integer('task_day').notNull(),
  taskDescription: text('task_description').notNull(),
  taskCategory: varchar('task_category', { length: 30 }).notNull(),
  priority: varchar('priority', { length: 10 }).notNull(),
  isCompleted: boolean('is_completed').default(false).notNull(),
  completedAt: timestamp('completed_at'),
  notes: text('notes'), // farmer's notes about the task
  createdAt: timestamp('created_at').defaultNow().notNull(),
  dueDate: date('due_date').notNull() // calculated based on planting date + task day
});

// Crop information and varieties
export const crops = pgTable('crops', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 100 }).notNull(),
  variety: varchar('variety', { length: 100 }),
  scientificName: varchar('scientific_name', { length: 150 }),
  category: varchar('category', { length: 50 }), // vegetable, grain, fruit, etc.
  maturityDays: integer('maturity_days').notNull(),
  spacingMeters: decimal('spacing_meters', { precision: 4, scale: 2 }).notNull(),
  seedsPerPlant: integer('seeds_per_plant').notNull(),
  seedsPerGram: integer('seeds_per_gram').notNull(),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull()
});

// Planting styles and their requirements
export const plantingStyles = pgTable('planting_styles', {
  id: serial('id').primaryKey(),
  cropId: integer('crop_id').references(() => crops.id),
  styleName: varchar('style_name', { length: 50 }).notNull(), // open_field_rainfed, greenhouse, etc.
  fertilizerKgPerHectare: decimal('fertilizer_kg_per_hectare', { precision: 8, scale: 2 }).notNull(),
  manureKgPerHectare: decimal('manure_kg_per_hectare', { precision: 10, scale: 2 }).notNull(),
  waterLitersPerPlantPerWeek: decimal('water_liters_per_plant_per_week', { precision: 6, scale: 2 }).notNull(),
  yieldKgPerPlant: decimal('yield_kg_per_plant', { precision: 6, scale: 2 }).notNull(),
  isActive: boolean('is_active').default(true).notNull()
});

// Farm records for tracking actual results
export const farmRecords = pgTable('farm_records', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  farmCalculationId: integer('farm_calculation_id').references(() => farmCalculations.id),
  plantingDate: date('planting_date').notNull(),
  harvestDate: date('harvest_date'),
  actualYield: decimal('actual_yield', { precision: 10, scale: 2 }), // kg
  totalCost: decimal('total_cost', { precision: 12, scale: 2 }), // total investment
  revenue: decimal('revenue', { precision: 12, scale: 2 }), // total sales
  profit: decimal('profit', { precision: 12, scale: 2 }), // revenue - cost
  notes: text('notes'),
  weatherConditions: varchar('weather_conditions', { length: 100 }),
  pestIssues: text('pest_issues'),
  diseaseIssues: text('disease_issues'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  farmCalculations: many(farmCalculations),
  taskProgress: many(taskProgress),
  farmRecords: many(farmRecords)
}));

export const farmCalculationsRelations = relations(farmCalculations, ({ one, many }) => ({
  user: one(users, {
    fields: [farmCalculations.userId],
    references: [users.id]
  }),
  taskProgress: many(taskProgress),
  farmRecords: many(farmRecords)
}));

export const taskProgressRelations = relations(taskProgress, ({ one }) => ({
  user: one(users, {
    fields: [taskProgress.userId],
    references: [users.id]
  }),
  farmCalculation: one(farmCalculations, {
    fields: [taskProgress.farmCalculationId],
    references: [farmCalculations.id]
  })
}));

export const cropsRelations = relations(crops, ({ many }) => ({
  plantingStyles: many(plantingStyles)
}));

export const plantingStylesRelations = relations(plantingStyles, ({ one }) => ({
  crop: one(crops, {
    fields: [plantingStyles.cropId],
    references: [crops.id]
  })
}));

export const farmRecordsRelations = relations(farmRecords, ({ one }) => ({
  user: one(users, {
    fields: [farmRecords.userId],
    references: [users.id]
  }),
  farmCalculation: one(farmCalculations, {
    fields: [farmRecords.farmCalculationId],
    references: [farmCalculations.id]
  })
}));

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export type FarmCalculation = typeof farmCalculations.$inferSelect;
export type InsertFarmCalculation = typeof farmCalculations.$inferInsert;

export type TaskProgress = typeof taskProgress.$inferSelect;
export type InsertTaskProgress = typeof taskProgress.$inferInsert;

export type Crop = typeof crops.$inferSelect;
export type InsertCrop = typeof crops.$inferInsert;

export type PlantingStyle = typeof plantingStyles.$inferSelect;
export type InsertPlantingStyle = typeof plantingStyles.$inferInsert;

export type FarmRecord = typeof farmRecords.$inferSelect;
export type InsertFarmRecord = typeof farmRecords.$inferInsert;

// Type exports for use in application
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type FarmCalculation = typeof farmCalculations.$inferSelect;
export type InsertFarmCalculation = typeof farmCalculations.$inferInsert;
export type TaskProgress = typeof taskProgress.$inferSelect;
export type InsertTaskProgress = typeof taskProgress.$inferInsert;
export type Crop = typeof crops.$inferSelect;
export type InsertCrop = typeof crops.$inferInsert;
export type PlantingStyle = typeof plantingStyles.$inferSelect;
export type InsertPlantingStyle = typeof plantingStyles.$inferInsert;
export type FarmRecord = typeof farmRecords.$inferSelect;
export type InsertFarmRecord = typeof farmRecords.$inferInsert;