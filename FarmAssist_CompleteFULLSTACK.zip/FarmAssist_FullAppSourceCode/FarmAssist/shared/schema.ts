import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, decimal, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const crops = pgTable("crops", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  scientificName: text("scientific_name"),
  description: text("description"),
  isActive: boolean("is_active").default(true).notNull(),
});

export const plantingStyles = pgTable("planting_styles", {
  id: serial("id").primaryKey(),
  cropId: integer("crop_id").references(() => crops.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  spacingBetweenPlants: decimal("spacing_between_plants", { precision: 5, scale: 2 }),
  spacingBetweenRows: decimal("spacing_between_rows", { precision: 5, scale: 2 }),
  plantsPerHectare: integer("plants_per_hectare"),
  growthPeriodDays: integer("growth_period_days"),
  isActive: boolean("is_active").default(true).notNull(),
});

export const farmCalculations = pgTable("farm_calculations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  cropId: integer("crop_id").references(() => crops.id).notNull(),
  plantingStyleId: integer("planting_style_id").references(() => plantingStyles.id).notNull(),
  farmSize: decimal("farm_size", { precision: 10, scale: 4 }).notNull(),
  totalPlants: integer("total_plants").notNull(),
  expectedYield: decimal("expected_yield", { precision: 10, scale: 2 }),
  calculationDate: timestamp("calculation_date").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const taskProgress = pgTable("task_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  farmCalculationId: integer("farm_calculation_id").references(() => farmCalculations.id).notNull(),
  taskDay: integer("task_day").notNull(),
  taskTitle: text("task_title").notNull(),
  taskDescription: text("task_description").notNull(),
  taskCategory: text("task_category").notNull(),
  priority: text("priority").notNull(),
  isCompleted: boolean("is_completed").default(false).notNull(),
  completedAt: timestamp("completed_at"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertFarmCalculationSchema = createInsertSchema(farmCalculations).omit({
  id: true,
  createdAt: true,
});

export const insertTaskProgressSchema = createInsertSchema(taskProgress).omit({
  id: true,
  createdAt: true,
});

export const updateTaskProgressSchema = createInsertSchema(taskProgress).partial().omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type FarmCalculation = typeof farmCalculations.$inferSelect;
export type TaskProgress = typeof taskProgress.$inferSelect;
export type Crop = typeof crops.$inferSelect;
export type PlantingStyle = typeof plantingStyles.$inferSelect;
export type InsertFarmCalculation = z.infer<typeof insertFarmCalculationSchema>;
export type InsertTaskProgress = z.infer<typeof insertTaskProgressSchema>;
export type UpdateTaskProgress = z.infer<typeof updateTaskProgressSchema>;
