/**
 * Extension Intelligence Engine - Expert farming tips by crop and day
 * AI Agronomist/Digital Extension Advisor System
 */

export interface ExtensionTip {
  day: number;
  tip: string;
  category: string;
  expertise_level: 'critical' | 'important' | 'helpful' | 'optional';
}

export interface CropExtensionTips {
  name: string;
  tips: ExtensionTip[];
}

export const EXTENSION_TIPS: Record<string, CropExtensionTips> = {
  tomato: {
    name: "Tomato Expert Tips",
    tips: [
      { 
        day: 1, 
        tip: "Clear the land thoroughly. Avoid replanting where tomatoes grew last season to reduce disease risk. Rotate with legumes or cereals.", 
        category: "preparation",
        expertise_level: "critical"
      },
      { 
        day: 2, 
        tip: "Use well-draining soil for nursery. Mix garden soil with compost (2:1 ratio) and ensure good drainage to prevent damping-off disease.", 
        category: "preparation",
        expertise_level: "important"
      },
      { 
        day: 4, 
        tip: "Sow seeds 0.5cm deep only. Deeper planting reduces germination rate. Cover lightly with fine soil or compost.", 
        category: "planting",
        expertise_level: "critical"
      },
      { 
        day: 7, 
        tip: "Monitor soil moisture closely. Nursery beds should be moist but not waterlogged. Water gently with fine spray to avoid displacing seeds.", 
        category: "watering",
        expertise_level: "important"
      },
      { 
        day: 14, 
        tip: "First true leaves should appear. Begin hardening off seedlings by reducing watering slightly and increasing air circulation.", 
        category: "monitoring",
        expertise_level: "important"
      },
      { 
        day: 21, 
        tip: "Transplant when seedlings are 10-15cm tall with 4-6 true leaves. Choose cloudy day or late afternoon to reduce transplant shock.", 
        category: "planting",
        expertise_level: "critical"
      },
      { 
        day: 28, 
        tip: "Apply first dose of balanced fertilizer (NPK 15:15:15) at 2 weeks after transplanting. Side-dress around plants, not touching stems.", 
        category: "fertilization",
        expertise_level: "important"
      },
      { 
        day: 35, 
        tip: "Install support stakes or cages now before plants get too large. This prevents root damage and ensures proper support throughout growth.", 
        category: "maintenance",
        expertise_level: "critical"
      },
      { 
        day: 42, 
        tip: "Begin removing suckers (shoots between main stem and branches). This improves air circulation and directs energy to fruit production.", 
        category: "maintenance",
        expertise_level: "important"
      },
      { 
        day: 49, 
        tip: "First flowers should appear. Tap flower clusters gently to aid pollination, or use electric toothbrush for greenhouse tomatoes.", 
        category: "monitoring",
        expertise_level: "helpful"
      },
      { 
        day: 56, 
        tip: "Apply high-potassium fertilizer as fruits begin to set. Reduce nitrogen to prevent excessive leaf growth at expense of fruits.", 
        category: "fertilization",
        expertise_level: "important"
      },
      { 
        day: 63, 
        tip: "Watch for early blight symptoms (brown spots on lower leaves). Remove affected leaves immediately and improve air circulation.", 
        category: "disease_control",
        expertise_level: "critical"
      },
      { 
        day: 70, 
        tip: "Mulch around plants with organic matter to retain moisture, suppress weeds, and prevent soil-borne diseases from splashing on leaves.", 
        category: "maintenance",
        expertise_level: "important"
      },
      { 
        day: 77, 
        tip: "Monitor for hornworms and other pests. Check undersides of leaves for eggs and remove by hand. Consider beneficial insects as control.", 
        category: "pest_control",
        expertise_level: "important"
      },
      { 
        day: 84, 
        tip: "First fruits should be forming. Maintain consistent watering to prevent blossom end rot. Deep watering 2-3 times per week is better than daily shallow watering.", 
        category: "watering",
        expertise_level: "critical"
      }
    ]
  },
  maize: {
    name: "Maize (Corn) Expert Tips",
    tips: [
      { 
        day: 1, 
        tip: "Test soil pH - maize grows best in soil pH 6.0-7.0. Lime acidic soils at least 2 weeks before planting.", 
        category: "preparation",
        expertise_level: "important"
      },
      { 
        day: 3, 
        tip: "Plant when soil temperature is consistently above 15°C. Cold soil leads to poor germination and fungal problems.", 
        category: "planting",
        expertise_level: "critical"
      },
      { 
        day: 7, 
        tip: "Plant seeds 2.5-3cm deep. Deeper planting in dry conditions, shallower in wet conditions. Firm soil gently after planting.", 
        category: "planting",
        expertise_level: "critical"
      },
      { 
        day: 14, 
        tip: "Emergence should occur 7-14 days after planting. Check for uneven germination and replant gaps if necessary.", 
        category: "monitoring",
        expertise_level: "important"
      },
      { 
        day: 21, 
        tip: "Begin cultivation to control weeds while plants are small. Avoid deep cultivation near plants as it damages surface roots.", 
        category: "maintenance",
        expertise_level: "important"
      },
      { 
        day: 35, 
        tip: "Apply first nitrogen side-dressing when plants are knee-high (6-8 leaves). This is critical for yield potential.", 
        category: "fertilization",
        expertise_level: "critical"
      },
      { 
        day: 45, 
        tip: "Monitor for corn borer eggs on undersides of leaves. Remove egg masses or apply appropriate biological controls.", 
        category: "pest_control",
        expertise_level: "important"
      },
      { 
        day: 55, 
        tip: "Tasseling stage begins. Ensure adequate water supply as moisture stress now severely reduces yield. Apply 25mm water per week.", 
        category: "watering",
        expertise_level: "critical"
      },
      { 
        day: 65, 
        tip: "Silking stage - critical pollination period. Each silk must be pollinated to produce a kernel. Avoid water stress at all costs.", 
        category: "monitoring",
        expertise_level: "critical"
      },
      { 
        day: 80, 
        tip: "Grain filling stage. Maintain soil moisture but reduce nitrogen application. Monitor for late season pests like fall armyworm.", 
        category: "monitoring",
        expertise_level: "important"
      }
    ]
  },
  pepper: {
    name: "Pepper Expert Tips", 
    tips: [
      { 
        day: 1, 
        tip: "Peppers need warm soil. Use black plastic mulch or row covers to warm soil before planting in cooler climates.", 
        category: "preparation",
        expertise_level: "important"
      },
      { 
        day: 5, 
        tip: "Start seeds indoors 8-10 weeks before last frost. Maintain soil temperature at 27-29°C for optimal germination.", 
        category: "planting",
        expertise_level: "critical"
      },
      { 
        day: 14, 
        tip: "Seedlings need strong light. Provide 14-16 hours of artificial light or place in brightest window available.", 
        category: "monitoring",
        expertise_level: "important"
      },
      { 
        day: 28, 
        tip: "Begin hardening off seedlings 7-10 days before transplanting. Gradually expose to outdoor conditions.", 
        category: "maintenance",
        expertise_level: "important"
      },
      { 
        day: 42, 
        tip: "Transplant after soil warms to 18°C and night temperatures stay above 13°C. Cold stress stunts growth permanently.", 
        category: "planting",
        expertise_level: "critical"
      },
      { 
        day: 56, 
        tip: "Pinch first flowers to encourage stronger plant development. This results in higher total yield later in season.", 
        category: "maintenance",
        expertise_level: "helpful"
      },
      { 
        day: 70, 
        tip: "Apply balanced fertilizer (10-10-10) every 3-4 weeks. Avoid high nitrogen which promotes leaves at expense of fruits.", 
        category: "fertilization",
        expertise_level: "important"
      },
      { 
        day: 84, 
        tip: "First peppers should be setting. Maintain consistent moisture - fluctuations cause blossom end rot and misshapen fruits.", 
        category: "watering",
        expertise_level: "critical"
      }
    ]
  },
  beans: {
    name: "Beans Expert Tips",
    tips: [
      { 
        day: 1, 
        tip: "Beans fix their own nitrogen. Avoid high-nitrogen fertilizers which promote excessive leaf growth and reduce flowering.", 
        category: "preparation",
        expertise_level: "important"
      },
      { 
        day: 3, 
        tip: "Inoculate seeds with rhizobia bacteria for better nitrogen fixation. This is especially important in new garden areas.", 
        category: "planting",
        expertise_level: "helpful"
      },
      { 
        day: 7, 
        tip: "Plant when soil temperature is at least 18°C. Cold, wet soil causes poor germination and seed rot.", 
        category: "planting",
        expertise_level: "critical"
      },
      { 
        day: 14, 
        tip: "Emergence typically occurs 6-10 days after planting. Thin if overcrowded to prevent disease and competition.", 
        category: "monitoring",
        expertise_level: "important"
      },
      { 
        day: 21, 
        tip: "Side-dress with phosphorus-rich fertilizer when first true leaves appear. Phosphorus promotes root development and flowering.", 
        category: "fertilization",
        expertise_level: "important"
      },
      { 
        day: 35, 
        tip: "Install support structures for pole beans now. Bush beans are self-supporting but may need light support in windy areas.", 
        category: "maintenance",
        expertise_level: "helpful"
      },
      { 
        day: 45, 
        tip: "First flowers appear. Beans are self-pollinating but benefit from gentle air movement. Avoid overhead watering during flowering.", 
        category: "monitoring",
        expertise_level: "important"
      },
      { 
        day: 55, 
        tip: "Begin harvesting when pods are young and tender. Regular picking encourages continued production throughout season.", 
        category: "harvesting",
        expertise_level: "critical"
      }
    ]
  },
  cabbage: {
    name: "Cabbage Expert Tips",
    tips: [
      { 
        day: 1, 
        tip: "Cabbage is a cool-season crop. Plant in early spring or late summer for fall harvest in most climates.", 
        category: "preparation",
        expertise_level: "important"
      },
      { 
        day: 5, 
        tip: "Start transplants indoors 6-8 weeks before planting date. Maintain temperature at 18-21°C for best germination.", 
        category: "planting",
        expertise_level: "important"
      },
      { 
        day: 21, 
        tip: "Transplant when seedlings have 3-4 true leaves. Harden off gradually over 7 days before transplanting.", 
        category: "planting",
        expertise_level: "important"
      },
      { 
        day: 35, 
        tip: "Apply high-nitrogen fertilizer to promote rapid leaf development. Cabbage needs steady nutrition throughout growth.", 
        category: "fertilization",
        expertise_level: "critical"
      },
      { 
        day: 49, 
        tip: "Monitor for cabbage worms and aphids. Use row covers or apply Bt (Bacillus thuringiensis) for organic control.", 
        category: "pest_control",
        expertise_level: "important"
      },
      { 
        day: 63, 
        tip: "Maintain consistent soil moisture. Drought stress followed by heavy watering causes heads to split.", 
        category: "watering",
        expertise_level: "critical"
      },
      { 
        day: 77, 
        tip: "Heads should be forming. Reduce nitrogen and increase potassium to improve head quality and storage life.", 
        category: "fertilization",
        expertise_level: "important"
      },
      { 
        day: 90, 
        tip: "Harvest when heads are firm and before they split. Cut at base leaving outer leaves if you want smaller secondary heads.", 
        category: "harvesting",
        expertise_level: "critical"
      }
    ]
  },
  onion: {
    name: "Onion Expert Tips",
    tips: [
      { 
        day: 1, 
        tip: "Choose day-length appropriate varieties. Long-day onions for northern climates, short-day for southern areas.", 
        category: "preparation",
        expertise_level: "critical"
      },
      { 
        day: 7, 
        tip: "Plant sets or transplants in well-drained soil. Onions rot quickly in waterlogged conditions.", 
        category: "planting",
        expertise_level: "critical"
      },
      { 
        day: 14, 
        tip: "Keep soil consistently moist but not waterlogged. Shallow roots require frequent, light watering.", 
        category: "watering",
        expertise_level: "important"
      },
      { 
        day: 28, 
        tip: "Side-dress with high-nitrogen fertilizer monthly until bulbing begins. Onions are heavy nitrogen feeders early in growth.", 
        category: "fertilization",
        expertise_level: "important"
      },
      { 
        day: 42, 
        tip: "Keep area weed-free. Onions have minimal foliage and cannot compete with weeds for nutrients and water.", 
        category: "maintenance",
        expertise_level: "critical"
      },
      { 
        day: 70, 
        tip: "Stop nitrogen fertilization when bulbing begins (when day-length triggers bulb formation). Switch to phosphorus and potassium.", 
        category: "fertilization",
        expertise_level: "critical"
      },
      { 
        day: 90, 
        tip: "Reduce watering as bulbs mature. This concentrates flavors and improves storage quality.", 
        category: "watering",
        expertise_level: "important"
      },
      { 
        day: 120, 
        tip: "Harvest when tops begin to fall over naturally. Cure in warm, dry, ventilated area for 2-3 weeks before storage.", 
        category: "harvesting",
        expertise_level: "critical"
      }
    ]
  }
};