import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { queryClient } from "./lib/queryClient";
import { Calculator, Calendar, LogOut, Sprout, Brain } from "lucide-react";
import FarmDashboard from "@/pages/farm-dashboard";
import FarmCalculator from "@/pages/farm-calculator";
import ExtensionAdvisor from "@/pages/extension-advisor";
import AuthPage from "@/pages/auth";
import NotFound from "@/pages/not-found";

interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  phone?: string;
  location?: string;
  farmSize?: number;
  experience: string;
  createdAt: Date;
}

function Navigation({ currentUser, onLogout }: { currentUser: User; onLogout: () => void }) {
  const [location, setLocation] = useLocation();
  
  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center gap-3">
            <Sprout className="h-8 w-8 text-green-600" />
            <h1 className="text-xl font-bold text-green-600">FarmAssist Crop</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <Button
              variant={location === "/calculator" ? "default" : "ghost"}
              onClick={() => setLocation("/calculator")}
              className="flex items-center gap-2"
            >
              <Calculator className="h-4 w-4" />
              Calculator
            </Button>
            <Button
              variant={location === "/dashboard" ? "default" : "ghost"}
              onClick={() => setLocation("/dashboard")}
              className="flex items-center gap-2"
            >
              <Calendar className="h-4 w-4" />
              Tasks
            </Button>
            <Button
              variant={location === "/advisor" ? "default" : "ghost"}
              onClick={() => setLocation("/advisor")}
              className="flex items-center gap-2"
            >
              <Brain className="h-4 w-4" />
              AI Advisor
            </Button>
            
            <div className="border-l pl-4 ml-4">
              <span className="text-sm text-gray-600 mr-3">
                Welcome, {currentUser.fullName}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={onLogout}
                className="text-red-600 border-red-300 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4 mr-1" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [location, setLocation] = useLocation();

  // Load user from localStorage on app start
  useEffect(() => {
    const savedUser = localStorage.getItem("farmassist_user");
    if (savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch (error) {
        localStorage.removeItem("farmassist_user");
      }
    }
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem("farmassist_user", JSON.stringify(user));
    setLocation("/calculator");
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("farmassist_user");
    setLocation("/");
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-gray-50">
          {/* Show authentication if no user is logged in */}
          {!currentUser ? (
            <AuthPage 
              currentUser={currentUser} 
              onLogin={handleLogin} 
              onLogout={handleLogout} 
            />
          ) : (
            <>
              <Navigation currentUser={currentUser} onLogout={handleLogout} />
              <Switch>
                <Route path="/" component={() => <FarmCalculator currentUser={currentUser} />} />
                <Route path="/calculator" component={() => <FarmCalculator currentUser={currentUser} />} />
                <Route path="/dashboard" component={() => <FarmDashboard currentUser={currentUser} />} />
                <Route path="/advisor" component={() => <ExtensionAdvisor currentUser={currentUser} />} />
                <Route component={NotFound} />
              </Switch>
            </>
          )}
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
