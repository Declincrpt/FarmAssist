import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Calculator, 
  Sprout, 
  MapPin, 
  Droplets, 
  Wheat, 
  Package,
  TrendingUp,
  CheckCircle,
  AlertTriangle
} from "lucide-react";
import { CROP_DATABASE, UNIT_CONVERSIONS } from "@shared/crop-data";

interface CalculationResult {
  plantsNeeded: number;
  plantSpacing: number;
  landUtilization: number;
  seedsRequired: number;
  fertilizerRequired: number;
  manureRequired: number;
  waterRequired: number;
  expectedYield: number;
  cropData: any;
  formData: FormData;
}

interface FormData {
  landSize: number;
  landUnit: string;
  cropType: string;
  plantingStyle: string;
}

interface User {
  id: number;
  username: string;
  fullName: string;
}

export default function FarmCalculator({ currentUser }: { currentUser?: User }) {
  const [formData, setFormData] = useState<FormData>({
    landSize: 0,
    landUnit: "hectares",
    cropType: "",
    plantingStyle: ""
  });
  const [calculation, setCalculation] = useState<CalculationResult | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const cropOptions = [
    { value: "tomato", label: "🍅 Tomato", emoji: "🍅" },
    { value: "maize", label: "🌽 Maize (Corn)", emoji: "🌽" },
    { value: "pepper", label: "🌶️ Pepper", emoji: "🌶️" },
    { value: "beans", label: "🫘 Beans", emoji: "🫘" },
    { value: "cabbage", label: "🥬 Cabbage", emoji: "🥬" },
    { value: "onion", label: "🧅 Onion", emoji: "🧅" }
  ];

  const plantingStyleOptions = [
    { value: "open_field_rainfed", label: "Open Field (Rainfed)" },
    { value: "open_field_irrigated", label: "Open Field (Irrigated)" },
    { value: "greenhouse", label: "Greenhouse" },
    { value: "polytunnel", label: "Polytunnel" }
  ];

  const unitOptions = [
    { value: "hectares", label: "Hectares" },
    { value: "acres", label: "Acres" },
    { value: "sqmeters", label: "Square Meters" },
    { value: "plots", label: "Plots (50x100 ft)" }
  ];

  const validateForm = (): boolean => {
    if (!formData.landSize || formData.landSize <= 0) {
      setError("Please enter a valid land size greater than 0");
      return false;
    }
    if (!formData.cropType) {
      setError("Please select a crop type");
      return false;
    }
    if (!formData.plantingStyle) {
      setError("Please select a planting style");
      return false;
    }
    setError(null);
    return true;
  };

  const calculateRequirements = (): CalculationResult => {
    const cropData = CROP_DATABASE[formData.cropType as keyof typeof CROP_DATABASE];
    if (!cropData) {
      throw new Error("Invalid crop type selected");
    }

    // Convert land size to square meters
    const landSizeInSqMeters = formData.landSize * UNIT_CONVERSIONS[formData.landUnit as keyof typeof UNIT_CONVERSIONS];
    const landSizeInHectares = landSizeInSqMeters / 10000;

    // Calculate plant spacing and number of plants
    const spacingMeters = cropData.spacingMeters;
    const areaPerPlant = spacingMeters * spacingMeters;
    const plantsNeeded = Math.floor(landSizeInSqMeters / areaPerPlant);

    // Calculate land utilization
    const actualUsedArea = plantsNeeded * areaPerPlant;
    const landUtilization = (actualUsedArea / landSizeInSqMeters) * 100;

    // Calculate seeds required
    const totalSeedsNeeded = plantsNeeded * cropData.seedsPerPlant;
    const seedsRequired = totalSeedsNeeded / cropData.seedsPerGram;

    // Get requirements based on planting style
    const plantingStyle = formData.plantingStyle as keyof typeof cropData.fertilizer;
    const fertilizerRequired = cropData.fertilizer[plantingStyle] * landSizeInHectares;
    const manureRequired = cropData.manure[plantingStyle] * landSizeInHectares;
    const waterRequired = cropData.waterPerWeek[plantingStyle] * plantsNeeded;
    const expectedYield = cropData.yieldPerPlant[plantingStyle] * plantsNeeded;

    return {
      plantsNeeded,
      plantSpacing: spacingMeters * 100, // Convert to cm for display
      landUtilization,
      seedsRequired,
      fertilizerRequired,
      manureRequired,
      waterRequired,
      expectedYield,
      cropData,
      formData
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsCalculating(true);
    setError(null);

    try {
      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const result = calculateRequirements();
      setCalculation(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred during calculation");
    } finally {
      setIsCalculating(false);
    }
  };

  const resetForm = () => {
    setFormData({
      landSize: 0,
      landUnit: "hectares",
      cropType: "",
      plantingStyle: ""
    });
    setCalculation(null);
    setError(null);
  };

  const selectedCrop = cropOptions.find(crop => crop.value === formData.cropType);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-green-600 to-green-500 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center">
                <Sprout className="mr-3" size={36} />
                FarmAssist Crop
              </h1>
              <p className="text-lg opacity-90">Smart Planting Calculator for Farmers</p>
            </div>
            <div className="text-right">
              <Calculator className="mx-auto mb-2" size={32} />
              <div className="text-sm">Calculate & Plan</div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Input Form */}
        <Card className="mb-8">
          <CardHeader className="bg-green-50 border-b">
            <CardTitle className="text-2xl text-green-800 flex items-center">
              <Calculator className="mr-3" size={24} />
              Farm Planning Calculator
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Land Size Input */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <Label htmlFor="landSize" className="text-base font-semibold">
                    <MapPin className="inline mr-2" size={16} />
                    Land Size *
                  </Label>
                  <Input
                    id="landSize"
                    type="number"
                    min="0.1"
                    step="0.1"
                    placeholder="Enter land size"
                    value={formData.landSize || ""}
                    onChange={(e) => setFormData({...formData, landSize: parseFloat(e.target.value) || 0})}
                    className="mt-2"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="landUnit" className="text-base font-semibold">Unit</Label>
                  <Select value={formData.landUnit} onValueChange={(value) => setFormData({...formData, landUnit: value})}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {unitOptions.map(unit => (
                        <SelectItem key={unit.value} value={unit.value}>{unit.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Crop Selection */}
              <div>
                <Label htmlFor="cropType" className="text-base font-semibold">
                  <Sprout className="inline mr-2" size={16} />
                  Select Crop *
                </Label>
                <Select value={formData.cropType} onValueChange={(value) => setFormData({...formData, cropType: value})}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Choose a crop..." />
                  </SelectTrigger>
                  <SelectContent>
                    {cropOptions.map(crop => (
                      <SelectItem key={crop.value} value={crop.value}>{crop.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Planting Style */}
              <div>
                <Label htmlFor="plantingStyle" className="text-base font-semibold">
                  <Package className="inline mr-2" size={16} />
                  Planting Method *
                </Label>
                <Select value={formData.plantingStyle} onValueChange={(value) => setFormData({...formData, plantingStyle: value})}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Choose planting method..." />
                  </SelectTrigger>
                  <SelectContent>
                    {plantingStyleOptions.map(style => (
                      <SelectItem key={style.value} value={style.value}>{style.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Error Display */}
              {error && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {/* Action Buttons */}
              <div className="flex gap-4">
                <Button 
                  type="submit" 
                  disabled={isCalculating}
                  className="bg-green-600 hover:bg-green-700 flex-1"
                >
                  {isCalculating ? "Calculating..." : "Calculate Requirements"}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={resetForm}
                  disabled={isCalculating}
                >
                  Reset
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Results Section */}
        {calculation && (
          <Card className="mb-8">
            <CardHeader className="bg-blue-50 border-b">
              <CardTitle className="text-2xl text-blue-800 flex items-center">
                <CheckCircle className="mr-3" size={24} />
                Your Farm Plan Results
                {selectedCrop && <span className="ml-2 text-3xl">{selectedCrop.emoji}</span>}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <Card className="border-l-4 border-l-green-500">
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-green-600">{calculation.plantsNeeded.toLocaleString()}</div>
                    <div className="text-sm text-gray-600">Plants Needed</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {calculation.plantSpacing}cm spacing
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-blue-500">
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-blue-600">{Math.round(calculation.landUtilization)}%</div>
                    <div className="text-sm text-gray-600">Land Utilization</div>
                    <div className="text-xs text-gray-500 mt-1">Efficiency rate</div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-orange-500">
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-orange-600">{Math.round(calculation.seedsRequired)}g</div>
                    <div className="text-sm text-gray-600">Seeds Required</div>
                    <div className="text-xs text-gray-500 mt-1">{calculation.plantsNeeded} seeds total</div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-purple-500">
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-purple-600">{Math.round(calculation.expectedYield)}kg</div>
                    <div className="text-sm text-gray-600">Expected Yield</div>
                    <div className="text-xs text-gray-500 mt-1">Total harvest</div>
                  </CardContent>
                </Card>
              </div>

              <Separator className="my-6" />

              {/* Detailed Requirements */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4 flex items-center">
                    <Wheat className="mr-2" size={20} />
                    Fertilizer & Nutrients
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">NPK Fertilizer</span>
                      <Badge variant="secondary">{Math.round(calculation.fertilizerRequired)} kg</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Organic Manure</span>
                      <Badge variant="secondary">{Math.round(calculation.manureRequired)} kg</Badge>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4 flex items-center">
                    <Droplets className="mr-2" size={20} />
                    Water Requirements
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                      <span className="font-medium">Weekly Water</span>
                      <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                        {Math.round(calculation.waterRequired)} L/week
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                      <span className="font-medium">Per Plant</span>
                      <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                        {calculation.cropData.waterPerWeek[calculation.formData.plantingStyle as keyof typeof calculation.cropData.waterPerWeek]} L/week
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>

              {/* Yield Projection */}
              <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-200">
                <h3 className="text-lg font-semibold text-green-800 mb-2 flex items-center">
                  <TrendingUp className="mr-2" size={20} />
                  Yield Projection
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="font-medium text-green-700">Total Expected Yield</div>
                    <div className="text-2xl font-bold text-green-800">{Math.round(calculation.expectedYield)} kg</div>
                  </div>
                  <div>
                    <div className="font-medium text-green-700">Yield per Plant</div>
                    <div className="text-xl font-semibold text-green-800">
                      {calculation.cropData.yieldPerPlant[calculation.formData.plantingStyle as keyof typeof calculation.cropData.yieldPerPlant]} kg
                    </div>
                  </div>
                  <div>
                    <div className="font-medium text-green-700">Planting Method</div>
                    <div className="text-lg font-semibold text-green-800 capitalize">
                      {calculation.formData.plantingStyle.replace('_', ' ')}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}