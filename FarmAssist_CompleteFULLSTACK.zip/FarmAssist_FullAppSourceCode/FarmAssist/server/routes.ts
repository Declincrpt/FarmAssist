import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTaskProgressSchema, updateTaskProgressSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username } = req.body;
      if (!username) {
        return res.status(400).json({ message: "Username is required" });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error during login:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = {
        ...req.body,
        password: req.body.password || "demo_password", // Simple demo password
      };
      const newUser = await storage.createUser(userData);
      res.status(201).json(newUser);
    } catch (error) {
      console.error("Error during registration:", error);
      res.status(400).json({ message: "Registration failed: " + (error as Error).message });
    }
  });

  // Get all crops
  app.get("/api/crops", async (req, res) => {
    try {
      const crops = await storage.getCrops();
      res.json(crops);
    } catch (error) {
      console.error("Error fetching crops:", error);
      res.status(500).json({ message: "Failed to fetch crops" });
    }
  });

  // Get planting styles for a crop
  app.get("/api/crops/:cropId/planting-styles", async (req, res) => {
    try {
      const cropId = parseInt(req.params.cropId);
      if (isNaN(cropId)) {
        return res.status(400).json({ message: "Invalid crop ID" });
      }
      
      const plantingStyles = await storage.getPlantingStyles(cropId);
      res.json(plantingStyles);
    } catch (error) {
      console.error("Error fetching planting styles:", error);
      res.status(500).json({ message: "Failed to fetch planting styles" });
    }
  });

  // Save farm calculation
  app.post("/api/farm-calculations", async (req, res) => {
    try {
      const validatedData = insertTaskProgressSchema.omit({ 
        userId: true, 
        farmCalculationId: true,
        taskDay: true,
        taskTitle: true,
        taskDescription: true,
        taskCategory: true,
        priority: true
      }).parse(req.body);
      
      // For demo purposes, use userId 1 - in real app, get from session
      const userId = 1;
      
      const calculation = await storage.saveFarmCalculation({
        ...validatedData,
        userId
      });
      
      res.json(calculation);
    } catch (error) {
      console.error("Error saving farm calculation:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save farm calculation" });
    }
  });

  // Get farm calculations for user
  app.get("/api/farm-calculations", async (req, res) => {
    try {
      // For demo purposes, use userId 1 - in real app, get from session
      const userId = 1;
      const calculations = await storage.getFarmCalculations(userId);
      res.json(calculations);
    } catch (error) {
      console.error("Error fetching farm calculations:", error);
      res.status(500).json({ message: "Failed to fetch farm calculations" });
    }
  });

  // Get tasks for a user
  app.get("/api/tasks/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const tasks = await storage.getTaskProgress(userId);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  // Get tasks for a farm calculation
  app.get("/api/farm-calculations/:id/tasks", async (req, res) => {
    try {
      const farmCalculationId = parseInt(req.params.id);
      if (isNaN(farmCalculationId)) {
        return res.status(400).json({ message: "Invalid farm calculation ID" });
      }
      
      // For demo purposes, use userId 1 - in real app, get from session
      const userId = 1;
      const tasks = await storage.getTaskProgress(userId, farmCalculationId);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  // Save task progress
  app.post("/api/tasks", async (req, res) => {
    try {
      const validatedData = insertTaskProgressSchema.parse(req.body);
      
      const task = await storage.saveTaskProgress(validatedData);
      res.json(task);
    } catch (error) {
      console.error("Error saving task:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save task" });
    }
  });

  // Mark task as completed
  app.patch("/api/tasks/:id/complete", async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const { notes } = req.body;
      const task = await storage.markTaskCompleted(taskId, notes);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error completing task:", error);
      res.status(500).json({ message: "Failed to complete task" });
    }
  });

  // Update task
  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const validatedData = updateTaskProgressSchema.parse(req.body);
      const task = await storage.updateTaskProgress(taskId, validatedData);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error updating task:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
