import { db } from "./db";
import { users, crops, plantingStyles, farmCalculations, taskProgress } from "@shared/schema";
import { CROP_DATABASE, CROP_TASK_CALENDAR } from "@shared/crop-data";
import { eq } from "drizzle-orm";

async function seedDatabase() {
  try {
    console.log("Starting database seeding...");

    // Create a demo user
    const [user] = await db.insert(users).values({
      username: "demo_farmer",
      password: "demo123",
    }).returning();

    console.log("Created demo user:", user.username);

    // Seed crops
    const cropEntries = Object.entries(CROP_DATABASE);
    const createdCrops = [];

    for (const [key, cropData] of cropEntries) {
      const [crop] = await db.insert(crops).values({
        name: cropData.name,
        scientificName: key === "tomato" ? "Solanum lycopersicum" : 
                      key === "maize" ? "Zea mays" : 
                      key === "pepper" ? "Capsicum annuum" :
                      key === "beans" ? "Phaseolus vulgaris" :
                      key === "cabbage" ? "Brassica oleracea" :
                      key === "onion" ? "Allium cepa" : null,
        description: `${cropData.name} farming with multiple planting styles`,
        isActive: true,
      }).returning();

      createdCrops.push({ key, crop });
      console.log(`Created crop: ${crop.name}`);

      // Create planting styles for each crop
      const plantingStyleKeys = Object.keys(cropData.fertilizer);
      for (const styleKey of plantingStyleKeys) {
        await db.insert(plantingStyles).values({
          cropId: crop.id,
          name: styleKey.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          description: `${styleKey.replace(/_/g, ' ')} farming method`,
          spacingBetweenPlants: cropData.spacingMeters.toString(),
          spacingBetweenRows: cropData.spacingMeters.toString(),
          plantsPerHectare: Math.floor(10000 / (cropData.spacingMeters * cropData.spacingMeters)),
          growthPeriodDays: key === "tomato" ? 90 : key === "maize" ? 120 : key === "pepper" ? 85 : 75,
          isActive: true,
        });
      }
    }

    // Create a sample farm calculation
    const tomatoCrop = createdCrops.find(c => c.key === "tomato");
    if (tomatoCrop) {
      const [tomatoPlantingStyle] = await db.select()
        .from(plantingStyles)
        .where(eq(plantingStyles.cropId, tomatoCrop.crop.id))
        .limit(1);

      const [calculation] = await db.insert(farmCalculations).values({
        userId: user.id,
        cropId: tomatoCrop.crop.id,
        plantingStyleId: tomatoPlantingStyle.id,
        farmSize: "1.0",
        totalPlants: 2777, // Based on 0.6m spacing
        expectedYield: "13885.0", // 5kg per plant * 2777 plants
      }).returning();

      console.log("Created sample farm calculation");

      // Create tasks from the tomato calendar
      const tomatoTasks = CROP_TASK_CALENDAR.tomato.tasks;
      const currentDay = 45;

      for (const task of tomatoTasks.slice(0, 15)) { // First 15 tasks
        await db.insert(taskProgress).values({
          userId: user.id,
          farmCalculationId: calculation.id,
          taskDay: task.day,
          taskTitle: task.task,
          taskDescription: task.task,
          taskCategory: task.category,
          priority: task.priority,
          isCompleted: task.day < currentDay - 2 ? Math.random() > 0.4 : false,
          completedAt: task.day < currentDay - 2 && Math.random() > 0.4 ? 
            new Date(Date.now() - (currentDay - task.day) * 24 * 60 * 60 * 1000) : null,
          notes: task.day < currentDay - 2 && Math.random() > 0.4 ? 
            "Task completed successfully" : null,
        });
      }

      console.log("Created sample tasks from tomato calendar");
    }

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

// Run seeding automatically when this module is executed
seedDatabase()
  .then(() => {
    console.log("Seeding completed!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Seeding failed:", error);
    process.exit(1);
  });

export { seedDatabase };