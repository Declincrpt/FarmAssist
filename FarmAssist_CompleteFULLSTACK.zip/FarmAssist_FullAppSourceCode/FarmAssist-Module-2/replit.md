# Pest & Disease Diagnosis Tool

## Overview

This is a modular Flask-based Progressive Web App that provides crop pest and disease diagnosis through symptom analysis. The application includes voice accessibility features and PWA capabilities, designed as a component for the larger FarmAssist Crop project. Users can select their crop type, describe symptoms, and receive expert recommendations with text-to-speech support and offline functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Vanilla HTML/CSS/JavaScript with Bootstrap 5
- **Theme**: Dark theme using Bootstrap agent theme from Replit CDN
- **UI Library**: Bootstrap 5 for responsive design and components
- **Icons**: Font Awesome 6.4.0 for visual elements
- **Styling**: Custom CSS with scoped styles and animations

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Structure**: Simple single-file application with minimal routes
- **Session Management**: Flask sessions with configurable secret key
- **Template Engine**: Jinja2 (Flask's default templating)

### Application Structure
```
├── app.py              # Main Flask application
├── main.py             # Entry point for deployment
├── templates/
│   └── index.html      # Main application template
└── static/
    ├── css/
    │   └── styles.css  # Custom styling with animations
    └── js/
        └── symptom-diagnoser.js  # Core diagnosis logic
```

## Key Components

### 1. Diagnosis Engine
- **Location**: `static/js/symptom-diagnoser.js`
- **Purpose**: Client-side symptom matching and diagnosis
- **Data Structure**: Keyword-based matching system with severity levels
- **Crops Supported**: Currently includes 8 crops (tomato, maize, pepper, potato, cabbage, beans, rice, wheat)

### 2. Disease Recognition Module
- **Location**: `static/js/disease-recognition.js`
- **Purpose**: Visual analysis of plant diseases through image processing
- **Features**: Image upload, color analysis, pattern matching, confidence scoring
- **Technology**: HTML5 Canvas, JavaScript image processing, modular architecture

### 3. Voice Accessibility Module
- **Location**: `static/js/voice-accessibility.js`
- **Purpose**: Text-to-speech functionality for farmers with reading difficulties
- **Features**: Multi-language support (English, Swahili, Yoruba), read-aloud buttons
- **Technology**: Browser's native SpeechSynthesis API for offline functionality

### 4. Progressive Web App (PWA) Layer
- **Location**: `static/sw.js`, `static/js/pwa-install.js`, `static/manifest.json`
- **Purpose**: Offline functionality and native app-like experience
- **Features**: Install prompts, offline caching, update management, connection status
- **Technology**: Service Workers, Web App Manifest, Cache API

### 5. Web Interface
- **Template**: Single-page application with form-based interaction
- **Features**: Crop selection, symptom input, image upload, real-time results, voice accessibility, PWA capabilities
- **Responsiveness**: Mobile-first design using Bootstrap grid system
- **Accessibility**: Read-aloud functionality for text content
- **PWA Features**: Installable, offline-capable, native app experience
- **Image Analysis**: Drag-and-drop image upload with visual disease detection

### 6. Styling System
- **Approach**: Scoped CSS to avoid conflicts with parent applications
- **Animations**: Custom CSS animations for better user experience
- **Theme**: Dark theme optimized for agricultural applications
- **Voice UI**: Specialized styling for read-aloud buttons and language selector
- **PWA UI**: Install prompts, offline indicators, and native app styling
- **Image UI**: Upload zones, analysis animations, and confidence indicators

## Data Flow

1. **User Input**: User selects crop type and enters symptom description
2. **Client-side Processing**: JavaScript processes symptoms against local database
3. **Keyword Matching**: System matches input keywords to known symptom patterns
4. **Result Generation**: Returns diagnosis, treatment actions, and prevention tips
5. **Display**: Results shown with severity indicators and actionable recommendations
6. **Voice Output**: Text-to-speech reads results aloud in selected language
7. **Offline Caching**: Service worker caches content for offline use

## Project Status

**Current Status:** Production-ready, feature-complete modular system
**Integration Ready:** All modules designed for easy integration into main FarmAssist Crop application
**Documentation:** Complete with architectural decisions and implementation details

## Recent Changes (January 2025)

### Voice Accessibility Module (Added)
- Multi-language text-to-speech support (English, Swahili, Yoruba)
- Automatic read-aloud buttons for all text content
- Browser compatibility detection with graceful fallbacks
- Mobile-optimized voice controls

### Progressive Web App Implementation (Added)
- Complete PWA manifest with app metadata and icons
- Service worker for offline functionality and caching
- Install prompts for native app experience
- Automatic update management
- Connection status monitoring
- Comprehensive demo pages for feature showcase

### Disease Recognition Module (Added)
- Image-based disease detection through visual analysis
- Canvas-based image processing and feature extraction
- Color profile matching and pattern recognition
- Confidence scoring system for detected diseases
- Integration with existing symptom database for treatment recommendations
- Drag-and-drop image upload with mobile-responsive interface

### Integration Readiness
- All modules designed for easy integration into main FarmAssist Crop application
- Modular JavaScript architecture prevents conflicts
- Scoped CSS styling to avoid interference with parent applications
- Complete documentation for deployment and integration

## External Dependencies

### Frontend Dependencies (CDN)
- **Bootstrap CSS**: Replit's Bootstrap agent dark theme
- **Font Awesome**: Version 6.4.0 for icons
- **No JavaScript Frameworks**: Pure vanilla JavaScript implementation

### Backend Dependencies
- **Flask**: Python web framework
- **Python Standard Library**: OS module for environment variables

### Environment Variables
- `SESSION_SECRET`: Optional session key (defaults to "dev-secret-key")

## Deployment Strategy

### Current Setup
- **Entry Point**: `main.py` imports and runs the Flask app
- **Host Configuration**: Configured to run on `0.0.0.0:5000`
- **Debug Mode**: Enabled for development environment
- **Static Files**: Served directly by Flask for simplicity

### Production Considerations
- Session secret should be set via environment variable
- Debug mode should be disabled in production
- Consider using a proper WSGI server (gunicorn, uWSGI)
- Static files could be served by a reverse proxy (nginx)

## Notable Design Decisions

### Client-side Processing
- **Decision**: All diagnosis logic runs in the browser
- **Rationale**: Reduces server load and provides instant responses
- **Trade-off**: Limited by browser capabilities but suitable for current scope

### Modular JavaScript Architecture
- **Decision**: Encapsulated symptom diagnoser as a reusable module
- **Rationale**: Allows integration into larger agricultural applications
- **Benefits**: Non-conflicting CSS classes and isolated functionality

### Minimal Backend
- **Decision**: Single-route Flask application
- **Rationale**: Keeps the application simple and focused
- **Future**: Can be expanded to include database storage and user management

### Keyword-based Matching
- **Decision**: Simple keyword matching for symptom identification
- **Rationale**: Easy to understand and maintain without ML complexity
- **Limitation**: May miss complex symptom combinations but provides good baseline functionality