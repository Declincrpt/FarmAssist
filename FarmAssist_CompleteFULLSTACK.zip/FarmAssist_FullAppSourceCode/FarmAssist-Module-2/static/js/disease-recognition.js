/**
 * Disease Recognition Module - Visual Analysis
 * Adds image-based disease detection to complement symptom analysis
 */

class DiseaseRecognition {
    constructor() {
        this.imageDatabase = this.initializeImageDatabase();
        this.canvas = null;
        this.ctx = null;
        this.currentImage = null;
        this.analysisResults = [];
        
        this.init();
    }

    /**
     * Initialize the disease recognition module
     */
    init() {
        this.createImageAnalysisInterface();
        this.bindEventListeners();
        console.log('[Disease Recognition] Module initialized');
    }

    /**
     * Initialize image pattern database for disease recognition
     */
    initializeImageDatabase() {
        return {
            tomato: [
                {
                    disease: "Early Blight",
                    patterns: ["dark_spots", "concentric_rings", "yellow_halo"],
                    colorProfile: { dominant: "brown", secondary: "yellow" },
                    confidence: 0.85,
                    description: "Dark brown spots with concentric rings and yellow halos on leaves"
                },
                {
                    disease: "Late Blight",
                    patterns: ["water_soaked", "brown_lesions", "white_mold"],
                    colorProfile: { dominant: "brown", secondary: "white" },
                    confidence: 0.90,
                    description: "Water-soaked brown lesions with white mold on undersides"
                },
                {
                    disease: "Bacterial Spot",
                    patterns: ["small_spots", "dark_brown", "raised_lesions"],
                    colorProfile: { dominant: "dark_brown", secondary: "black" },
                    confidence: 0.80,
                    description: "Small, dark brown raised spots on leaves and fruit"
                },
                {
                    disease: "Mosaic Virus",
                    patterns: ["mottled_pattern", "light_green", "dark_green"],
                    colorProfile: { dominant: "light_green", secondary: "dark_green" },
                    confidence: 0.75,
                    description: "Mottled light and dark green pattern on leaves"
                }
            ],
            potato: [
                {
                    disease: "Late Blight",
                    patterns: ["brown_lesions", "water_soaked", "white_growth"],
                    colorProfile: { dominant: "brown", secondary: "white" },
                    confidence: 0.90,
                    description: "Brown water-soaked lesions with white fungal growth"
                },
                {
                    disease: "Common Scab",
                    patterns: ["corky_patches", "rough_texture", "brown_spots"],
                    colorProfile: { dominant: "brown", secondary: "tan" },
                    confidence: 0.85,
                    description: "Rough, corky brown patches on tuber surface"
                }
            ],
            maize: [
                {
                    disease: "Northern Corn Leaf Blight",
                    patterns: ["elongated_lesions", "gray_green", "boat_shaped"],
                    colorProfile: { dominant: "gray", secondary: "green" },
                    confidence: 0.80,
                    description: "Long, boat-shaped gray-green lesions on leaves"
                },
                {
                    disease: "Common Rust",
                    patterns: ["rust_pustules", "orange_brown", "oval_spots"],
                    colorProfile: { dominant: "orange", secondary: "brown" },
                    confidence: 0.85,
                    description: "Orange-brown rust pustules on both leaf surfaces"
                }
            ]
        };
    }

    /**
     * Create the image analysis interface
     */
    createImageAnalysisInterface() {
        const container = document.createElement('div');
        container.className = 'disease-recognition-container';
        container.innerHTML = `
            <div class="card mb-4" id="imageAnalysisCard" style="display: none;">
                <div class="card-header bg-info text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-camera me-2"></i>
                        Image-Based Disease Recognition
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="image-upload-zone mb-3" id="imageUploadZone">
                                <div class="upload-placeholder text-center p-4 border border-dashed">
                                    <i class="fas fa-cloud-upload-alt fa-3x text-muted mb-3"></i>
                                    <p class="mb-2">Drop image here or click to upload</p>
                                    <p class="small text-muted">Supports JPG, PNG formats</p>
                                    <input type="file" id="imageInput" accept="image/*" style="display: none;">
                                    <button type="button" class="btn btn-outline-primary btn-sm" id="selectImageBtn">
                                        <i class="fas fa-folder-open me-2"></i>
                                        Select Image
                                    </button>
                                </div>
                            </div>
                            
                            <div class="image-preview" id="imagePreview" style="display: none;">
                                <canvas id="analysisCanvas" class="img-fluid border"></canvas>
                                <div class="mt-2">
                                    <button type="button" class="btn btn-primary btn-sm" id="analyzeImageBtn">
                                        <i class="fas fa-search me-2"></i>
                                        Analyze Disease
                                    </button>
                                    <button type="button" class="btn btn-outline-secondary btn-sm ms-2" id="clearImageBtn">
                                        <i class="fas fa-times me-2"></i>
                                        Clear
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="analysis-results" id="analysisResults">
                                <div class="text-center text-muted p-4">
                                    <i class="fas fa-microscope fa-2x mb-3"></i>
                                    <p>Upload an image to start visual disease analysis</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Insert after the main diagnosis form
        const mainCard = document.querySelector('.card');
        if (mainCard && mainCard.parentNode) {
            mainCard.parentNode.insertBefore(container, mainCard.nextSibling);
        }
    }

    /**
     * Bind event listeners for image analysis
     */
    bindEventListeners() {
        // File input change
        const imageInput = document.getElementById('imageInput');
        if (imageInput) {
            imageInput.addEventListener('change', (e) => this.handleImageUpload(e));
        }

        // Select image button
        const selectBtn = document.getElementById('selectImageBtn');
        if (selectBtn) {
            selectBtn.addEventListener('click', () => {
                imageInput?.click();
            });
        }

        // Drag and drop
        const uploadZone = document.getElementById('imageUploadZone');
        if (uploadZone) {
            uploadZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadZone.classList.add('drag-over');
            });

            uploadZone.addEventListener('dragleave', () => {
                uploadZone.classList.remove('drag-over');
            });

            uploadZone.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadZone.classList.remove('drag-over');
                this.handleImageDrop(e);
            });
        }

        // Analyze button
        const analyzeBtn = document.getElementById('analyzeImageBtn');
        if (analyzeBtn) {
            analyzeBtn.addEventListener('click', () => this.analyzeImage());
        }

        // Clear button
        const clearBtn = document.getElementById('clearImageBtn');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearImage());
        }

        // Toggle image analysis when crop is selected
        const cropSelect = document.getElementById('cropSelect');
        if (cropSelect) {
            cropSelect.addEventListener('change', () => this.toggleImageAnalysis());
        }
    }

    /**
     * Toggle image analysis based on crop selection
     */
    toggleImageAnalysis() {
        const cropSelect = document.getElementById('cropSelect');
        const imageCard = document.getElementById('imageAnalysisCard');
        
        if (cropSelect && imageCard) {
            if (cropSelect.value && cropSelect.value !== '') {
                imageCard.style.display = 'block';
            } else {
                imageCard.style.display = 'none';
            }
        }
    }

    /**
     * Handle image upload from file input
     */
    handleImageUpload(event) {
        const file = event.target.files[0];
        if (file) {
            this.loadImage(file);
        }
    }

    /**
     * Handle image drop
     */
    handleImageDrop(event) {
        const files = event.dataTransfer.files;
        if (files.length > 0) {
            this.loadImage(files[0]);
        }
    }

    /**
     * Load and display image for analysis
     */
    loadImage(file) {
        if (!this.isValidImageFile(file)) {
            this.showError('Please upload a valid image file (JPG, PNG)');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                this.displayImage(img);
                this.currentImage = img;
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }

    /**
     * Display image on canvas
     */
    displayImage(img) {
        const canvas = document.getElementById('analysisCanvas');
        const ctx = canvas.getContext('2d');
        
        // Set canvas size
        const maxWidth = 400;
        const maxHeight = 300;
        let { width, height } = img;
        
        if (width > maxWidth || height > maxHeight) {
            const ratio = Math.min(maxWidth / width, maxHeight / height);
            width *= ratio;
            height *= ratio;
        }
        
        canvas.width = width;
        canvas.height = height;
        
        // Draw image
        ctx.drawImage(img, 0, 0, width, height);
        
        this.canvas = canvas;
        this.ctx = ctx;
        
        // Show preview section
        document.getElementById('imageUploadZone').style.display = 'none';
        document.getElementById('imagePreview').style.display = 'block';
        
        // Clear previous results
        this.clearResults();
    }

    /**
     * Analyze the uploaded image for diseases
     */
    analyzeImage() {
        if (!this.currentImage || !this.canvas) {
            this.showError('Please upload an image first');
            return;
        }

        const cropSelect = document.getElementById('cropSelect');
        const selectedCrop = cropSelect?.value;
        
        if (!selectedCrop) {
            this.showError('Please select a crop type first');
            return;
        }

        this.showAnalysisLoading();
        
        // Simulate analysis with timeout
        setTimeout(() => {
            this.performImageAnalysis(selectedCrop);
        }, 2000);
    }

    /**
     * Perform image analysis (simulated for demonstration)
     */
    performImageAnalysis(crop) {
        const imageData = this.extractImageFeatures();
        const cropDatabase = this.imageDatabase[crop.toLowerCase()];
        
        if (!cropDatabase) {
            this.showError('Image analysis not available for this crop yet');
            return;
        }

        // Simulate disease detection with confidence scores
        const detectedDiseases = this.simulateDiseasDetection(cropDatabase, imageData);
        this.displayAnalysisResults(detectedDiseases, crop);
    }

    /**
     * Extract basic image features for analysis
     */
    extractImageFeatures() {
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const data = imageData.data;
        
        let totalR = 0, totalG = 0, totalB = 0;
        let pixelCount = 0;
        
        // Sample every 10th pixel for performance
        for (let i = 0; i < data.length; i += 40) {
            totalR += data[i];
            totalG += data[i + 1];
            totalB += data[i + 2];
            pixelCount++;
        }
        
        return {
            avgRed: Math.round(totalR / pixelCount),
            avgGreen: Math.round(totalG / pixelCount),
            avgBlue: Math.round(totalB / pixelCount),
            brightness: Math.round((totalR + totalG + totalB) / (pixelCount * 3)),
            pixelCount: pixelCount
        };
    }

    /**
     * Simulate disease detection based on image features
     */
    simulateDiseasDetection(cropDatabase, imageFeatures) {
        const results = [];
        
        cropDatabase.forEach(disease => {
            // Simple heuristic-based matching
            let confidence = Math.random() * 0.3 + 0.4; // Base confidence 40-70%
            
            // Adjust confidence based on color matching
            if (this.matchesColorProfile(imageFeatures, disease.colorProfile)) {
                confidence += 0.2;
            }
            
            // Add some randomness to simulate real analysis
            confidence *= (0.8 + Math.random() * 0.4);
            confidence = Math.min(confidence, 0.95);
            
            if (confidence > 0.5) {
                results.push({
                    ...disease,
                    confidence: Math.round(confidence * 100) / 100,
                    imageFeatures: imageFeatures
                });
            }
        });
        
        // Sort by confidence
        return results.sort((a, b) => b.confidence - a.confidence);
    }

    /**
     * Check if image features match disease color profile
     */
    matchesColorProfile(imageFeatures, colorProfile) {
        const { avgRed, avgGreen, avgBlue } = imageFeatures;
        
        // Simple color matching logic
        if (colorProfile.dominant === 'brown') {
            return avgRed > 100 && avgGreen > 60 && avgBlue < 80;
        } else if (colorProfile.dominant === 'yellow') {
            return avgRed > 150 && avgGreen > 150 && avgBlue < 100;
        } else if (colorProfile.dominant === 'orange') {
            return avgRed > 180 && avgGreen > 100 && avgBlue < 80;
        }
        
        return false;
    }

    /**
     * Display analysis results
     */
    displayAnalysisResults(diseases, crop) {
        const resultsContainer = document.getElementById('analysisResults');
        
        if (diseases.length === 0) {
            resultsContainer.innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    No diseases detected with high confidence. Try a clearer image or use symptom analysis.
                </div>
            `;
            return;
        }

        let resultsHTML = `
            <div class="analysis-header mb-3">
                <h6 class="fw-bold text-success">
                    <i class="fas fa-check-circle me-2"></i>
                    Analysis Complete
                </h6>
                <p class="small text-muted mb-0">Found ${diseases.length} potential disease(s)</p>
            </div>
        `;

        diseases.forEach((disease, index) => {
            const confidenceClass = disease.confidence >= 0.8 ? 'success' : 
                                  disease.confidence >= 0.6 ? 'warning' : 'info';
            
            resultsHTML += `
                <div class="disease-result mb-3 p-3 border rounded">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h6 class="fw-bold mb-1">${disease.disease}</h6>
                        <span class="badge bg-${confidenceClass}">${Math.round(disease.confidence * 100)}%</span>
                    </div>
                    <p class="small text-muted mb-2">${disease.description}</p>
                    <button type="button" class="btn btn-outline-primary btn-sm" 
                            onclick="diseaseRecognition.getDetailedInfo('${disease.disease}', '${crop}')">
                        <i class="fas fa-info-circle me-1"></i>
                        Get Treatment Info
                    </button>
                </div>
            `;
        });

        resultsContainer.innerHTML = resultsHTML;
    }

    /**
     * Get detailed information about detected disease
     */
    getDetailedInfo(diseaseName, crop) {
        // Get corresponding symptom-based diagnosis if available
        if (window.symptomDiagnoser && window.symptomDiagnoser.database) {
            const cropData = window.symptomDiagnoser.database[crop.toLowerCase()];
            if (cropData) {
                const matchingDisease = cropData.find(d => 
                    d.diagnosis.toLowerCase().includes(diseaseName.toLowerCase()) ||
                    diseaseName.toLowerCase().includes(d.diagnosis.toLowerCase())
                );
                
                if (matchingDisease) {
                    this.showDetailedModal(matchingDisease, diseaseName);
                    return;
                }
            }
        }
        
        // Fallback if no detailed info available
        this.showBasicInfo(diseaseName);
    }

    /**
     * Show detailed treatment modal
     */
    showDetailedModal(diseaseInfo, detectedName) {
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.innerHTML = `
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title">
                            <i class="fas fa-leaf me-2"></i>
                            ${detectedName} - Treatment Guide
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="fw-bold text-primary">Immediate Action Required:</h6>
                                <p class="small">${diseaseInfo.action}</p>
                            </div>
                            <div class="col-md-6">
                                <h6 class="fw-bold text-info">Prevention for Future:</h6>
                                <p class="small">${diseaseInfo.prevention}</p>
                            </div>
                        </div>
                        <div class="alert alert-${diseaseInfo.severity === 'high' ? 'danger' : diseaseInfo.severity === 'moderate' ? 'warning' : 'info'} mt-3">
                            <strong>Severity Level: ${diseaseInfo.severity.toUpperCase()}</strong>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
        
        modal.addEventListener('hidden.bs.modal', () => modal.remove());
    }

    /**
     * Show basic info when detailed treatment not available
     */
    showBasicInfo(diseaseName) {
        alert(`Disease detected: ${diseaseName}\n\nFor detailed treatment information, please consult with your local agricultural extension officer or use our symptom-based diagnosis tool.`);
    }

    /**
     * Clear the uploaded image and results
     */
    clearImage() {
        document.getElementById('imageUploadZone').style.display = 'block';
        document.getElementById('imagePreview').style.display = 'none';
        document.getElementById('imageInput').value = '';
        
        this.currentImage = null;
        this.canvas = null;
        this.ctx = null;
        
        this.clearResults();
    }

    /**
     * Clear analysis results
     */
    clearResults() {
        const resultsContainer = document.getElementById('analysisResults');
        resultsContainer.innerHTML = `
            <div class="text-center text-muted p-4">
                <i class="fas fa-microscope fa-2x mb-3"></i>
                <p>Upload an image to start visual disease analysis</p>
            </div>
        `;
    }

    /**
     * Show analysis loading state
     */
    showAnalysisLoading() {
        const resultsContainer = document.getElementById('analysisResults');
        resultsContainer.innerHTML = `
            <div class="text-center p-4">
                <div class="spinner-border text-primary mb-3" role="status">
                    <span class="visually-hidden">Analyzing...</span>
                </div>
                <p class="mb-0">Analyzing image for disease patterns...</p>
                <p class="small text-muted">This may take a few moments</p>
            </div>
        `;
    }

    /**
     * Show error message
     */
    showError(message) {
        const resultsContainer = document.getElementById('analysisResults');
        resultsContainer.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                ${message}
            </div>
        `;
    }

    /**
     * Check if file is a valid image
     */
    isValidImageFile(file) {
        const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        return validTypes.includes(file.type);
    }
}

// Initialize disease recognition when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    console.log('[Disease Recognition] Initializing module...');
    window.diseaseRecognition = new DiseaseRecognition();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DiseaseRecognition;
}