import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const weatherForecasts = pgTable("weather_forecasts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  location: text("location").notNull(),
  forecastData: jsonb("forecast_data").notNull(),
  lastUpdated: text("last_updated").notNull(),
});

export const cropAdvisories = pgTable("crop_advisories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  location: text("location").notNull(),
  cropType: text("crop_type").notNull(),
  advisoryData: jsonb("advisory_data").notNull(),
  riskLevel: text("risk_level").notNull(),
  createdAt: text("created_at").notNull(),
});

export const insertWeatherForecastSchema = createInsertSchema(weatherForecasts).pick({
  location: true,
  forecastData: true,
  lastUpdated: true,
});

export const insertCropAdvisorySchema = createInsertSchema(cropAdvisories).pick({
  location: true,
  cropType: true,
  advisoryData: true,
  riskLevel: true,
  createdAt: true,
});

export type InsertWeatherForecast = z.infer<typeof insertWeatherForecastSchema>;
export type WeatherForecast = typeof weatherForecasts.$inferSelect;
export type InsertCropAdvisory = z.infer<typeof insertCropAdvisorySchema>;
export type CropAdvisory = typeof cropAdvisories.$inferSelect;

// Weather data types
export interface WeatherDay {
  date: string;
  dayLabel: string;
  temperature: number;
  description: string;
  humidity: number;
  rainfall: number;
  icon: string;
}

export interface WeatherData {
  location: string;
  days: WeatherDay[];
  lastUpdated: string;
}

// Crop advisory types
export interface CropRisk {
  type: 'rain' | 'heat' | 'cold';
  level: 'high' | 'medium' | 'low';
  days: string[];
  title: string;
  description: string;
  actions: string[];
}

export interface CropAdvisoryData {
  cropType: string;
  location: string;
  risks: CropRisk[];
  summary: {
    goodDays: number;
    cautionDays: number;
    riskDays: number;
  };
}
