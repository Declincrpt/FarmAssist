import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Sprout, 
  Camera, 
  Upload, 
  Calendar,
  CloudSun,
  MessageSquare,
  DollarSign,
  User,
  Trash2,
  Edit,
  Image as ImageIcon,
  Plus,
  FileImage,
  BookOpen
} from "lucide-react";

interface PhotoEntry {
  id: string;
  crop: string;
  imageData: string; // base64 encoded image
  notes: string;
  date: string;
  timestamp: number;
}

export default function PhotoJournal() {
  const [photoJournal, setPhotoJournal] = useState<PhotoEntry[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Form states
  const [formData, setFormData] = useState({
    crop: '',
    notes: '',
    imageFile: null as File | null,
    imagePreview: '' as string
  });

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedJournal = localStorage.getItem('photoJournal');
    if (savedJournal) {
      try {
        const parsedJournal = JSON.parse(savedJournal);
        setPhotoJournal(parsedJournal);
      } catch (error) {
        console.error('Error loading photo journal:', error);
      }
    }
  }, []);

  // Handle file selection
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid File Type",
        description: "Please select an image file (JPG, PNG, etc.)",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      });
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = (event) => {
      const imagePreview = event.target?.result as string;
      setFormData(prev => ({
        ...prev,
        imageFile: file,
        imagePreview
      }));
    };
    reader.readAsDataURL(file);
  };

  // Convert file to base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.crop.trim()) {
      toast({
        title: "Missing Information",
        description: "Please enter a crop name",
        variant: "destructive",
      });
      return;
    }

    if (!formData.imageFile) {
      toast({
        title: "Missing Image",
        description: "Please select an image to upload",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Convert image to base64
      const imageData = await fileToBase64(formData.imageFile);

      // Create new photo entry
      const newEntry: PhotoEntry = {
        id: Date.now().toString(),
        crop: formData.crop.trim(),
        imageData,
        notes: formData.notes.trim(),
        date: new Date().toISOString().split('T')[0],
        timestamp: Date.now()
      };

      // Update state and localStorage
      const updatedJournal = [newEntry, ...photoJournal];
      setPhotoJournal(updatedJournal);
      localStorage.setItem('photoJournal', JSON.stringify(updatedJournal));

      // Reset form
      setFormData({
        crop: '',
        notes: '',
        imageFile: null,
        imagePreview: ''
      });
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }

      toast({
        title: "Photo Added",
        description: `${formData.crop} photo added to your journal`,
      });

    } catch (error) {
      console.error('Error saving photo:', error);
      toast({
        title: "Save Failed",
        description: "Failed to save photo. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle delete entry
  const handleDelete = (id: string) => {
    const updatedJournal = photoJournal.filter(entry => entry.id !== id);
    setPhotoJournal(updatedJournal);
    localStorage.setItem('photoJournal', JSON.stringify(updatedJournal));
    
    toast({
      title: "Photo Deleted",
      description: "Photo entry has been removed from your journal",
    });
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Get crop emoji
  const getCropEmoji = (crop: string) => {
    const cropLower = crop.toLowerCase();
    if (cropLower.includes('tomato')) return '🍅';
    if (cropLower.includes('maize') || cropLower.includes('corn')) return '🌽';
    if (cropLower.includes('pepper')) return '🌶️';
    if (cropLower.includes('bean')) return '🫘';
    if (cropLower.includes('rice')) return '🌾';
    if (cropLower.includes('cassava')) return '🥔';
    if (cropLower.includes('yam')) return '🍠';
    if (cropLower.includes('plantain') || cropLower.includes('banana')) return '🍌';
    return '🌱';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-farm-green rounded-lg flex items-center justify-center">
                <Sprout className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">FarmAssist</h1>
                <p className="text-sm text-gray-500">Photo Journal</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Link href="/">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <CloudSun className="w-4 h-4 mr-2" />
                  Weather
                </Button>
              </Link>
              <Link href="/finance">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Finance
                </Button>
              </Link>
              <Link href="/glossary">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Glossary
                </Button>
              </Link>
              <Link href="/chatbot">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Ask AI
                </Button>
              </Link>
              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                <User className="text-gray-600 text-sm" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Image Logging Form */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Camera className="text-farm-green" />
              <span>Add New Photo Entry</span>
            </CardTitle>
            <p className="text-sm text-gray-600">
              Document your crop progress with photos and notes
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="crop-name" className="block text-sm font-medium text-gray-700 mb-2">
                    Crop Name
                  </Label>
                  <Input
                    id="crop-name"
                    placeholder="e.g., Tomato, Maize, Pepper"
                    value={formData.crop}
                    onChange={(e) => setFormData(prev => ({ ...prev, crop: e.target.value }))}
                    disabled={isSubmitting}
                  />
                </div>
                
                <div>
                  <Label htmlFor="photo-upload" className="block text-sm font-medium text-gray-700 mb-2">
                    Upload Photo
                  </Label>
                  <Input
                    id="photo-upload"
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileSelect}
                    disabled={isSubmitting}
                    className="cursor-pointer"
                  />
                </div>
              </div>

              {/* Image Preview */}
              {formData.imagePreview && (
                <div className="mt-4">
                  <Label className="block text-sm font-medium text-gray-700 mb-2">
                    Photo Preview
                  </Label>
                  <div className="relative">
                    <img
                      src={formData.imagePreview}
                      alt="Preview"
                      className="w-full max-w-md h-48 object-cover rounded-lg border border-gray-300"
                    />
                  </div>
                </div>
              )}

              <div>
                <Label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-2">
                  Notes (Optional)
                </Label>
                <Textarea
                  id="notes"
                  placeholder="Record observations about growth, health, treatments applied, etc."
                  value={formData.notes}
                  onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  disabled={isSubmitting}
                  rows={3}
                />
              </div>

              <Button 
                type="submit" 
                disabled={isSubmitting || !formData.crop || !formData.imageFile}
                className="w-full bg-farm-green hover:bg-emerald-600 text-white"
              >
                {isSubmitting ? (
                  <>
                    <Upload className="w-4 h-4 mr-2 animate-spin" />
                    Saving Photo...
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4 mr-2" />
                    Add to Journal
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Timeline Display */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileImage className="text-farm-green" />
              <span>Photo Timeline</span>
            </CardTitle>
            <p className="text-sm text-gray-600">
              Your crop progress over time
            </p>
          </CardHeader>
          <CardContent>
            {photoJournal.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <ImageIcon className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-400 mb-2">No Photos Yet</h3>
                <p>Start documenting your crops by adding your first photo above.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {photoJournal.map((entry) => (
                  <div key={entry.id} className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{getCropEmoji(entry.crop)}</span>
                        <div>
                          <h3 className="font-semibold text-gray-900 capitalize">
                            {entry.crop}
                          </h3>
                          <div className="flex items-center text-sm text-gray-500 mt-1">
                            <Calendar className="w-4 h-4 mr-1" />
                            {formatDate(entry.date)}
                          </div>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(entry.id)}
                        className="text-red-600 border-red-200 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    <div className="mb-4">
                      <img
                        src={entry.imageData}
                        alt={`${entry.crop} on ${entry.date}`}
                        className="w-full max-w-2xl h-64 object-cover rounded-lg border border-gray-300"
                      />
                    </div>

                    {entry.notes && (
                      <div className="bg-gray-50 rounded-lg p-4">
                        <h4 className="font-medium text-gray-900 mb-2">Notes:</h4>
                        <p className="text-gray-700 text-sm leading-relaxed">
                          {entry.notes}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}