import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { MessageSquare, Send, Bot, User, HelpCircle, Lightbulb, Sprout, CloudSun, DollarSign, Camera, BookOpen, Activity } from "lucide-react";

// Comprehensive farming knowledge base
const farmFAQ = {
  tomato: [
    {
      keywords: ["yellow", "leaves", "tomato", "yellowing"],
      category: "Disease & Nutrition",
      answer: "Tomato leaves turn yellow due to nitrogen deficiency or overwatering. Apply compost or urea fertilizer (2-3 tablespoons per plant). Ensure proper drainage and avoid overhead watering."
    },
    {
      keywords: ["transplant", "tomato", "when", "seedling"],
      category: "Planting",
      answer: "Transplant tomatoes when seedlings are 3–6 inches tall (21–30 days after sowing). Ensure soil temperature is above 16°C and no frost risk remains."
    },
    {
      keywords: ["blight", "tomato", "disease", "spots"],
      category: "Disease & Nutrition",
      answer: "Early blight appears as dark spots with concentric rings. Remove affected leaves, improve air circulation, and spray with copper-based fungicide or neem oil every 7-10 days."
    },
    {
      keywords: ["pruning", "tomato", "sucker", "trim"],
      category: "Care & Maintenance",
      answer: "Remove suckers (shoots between main stem and branches) weekly. Prune lower leaves touching the ground. Support plants with stakes or cages when 12 inches tall."
    },
    {
      keywords: ["fertilizer", "tomato", "feed", "nutrition"],
      category: "Disease & Nutrition",
      answer: "Use balanced fertilizer (10-10-10) at planting, then high-potassium fertilizer during flowering. Feed every 2-3 weeks. Avoid over-fertilizing with nitrogen during fruiting."
    }
  ],
  maize: [
    {
      keywords: ["armyworm", "maize", "control", "pest", "worm"],
      category: "Pest Control",
      answer: "Control armyworms with neem oil or biological insecticides (Bt spray). Monitor fields early morning when larvae are active. Apply insecticide to whorl and young leaves."
    },
    {
      keywords: ["planting", "maize", "spacing", "distance"],
      category: "Planting",
      answer: "Plant maize 75cm between rows and 25cm between plants. Sow 2-3 seeds per hole, 2-3cm deep. Thin to one strong plant per position after germination."
    },
    {
      keywords: ["fertilizer", "maize", "nitrogen", "feed"],
      category: "Disease & Nutrition",
      answer: "Apply basal fertilizer (DAP) at planting: 200kg/hectare. Side-dress with urea (100kg/hectare) when plants are knee-high, before tasseling."
    },
    {
      keywords: ["harvest", "maize", "when", "ready"],
      category: "Harvesting",
      answer: "Harvest maize when husks turn brown and kernels are firm. Moisture content should be 20-25%. Test by pressing thumbnail into kernel - should leave slight dent."
    }
  ],
  pepper: [
    {
      keywords: ["pepper", "transplant", "seedling", "when"],
      category: "Planting",
      answer: "Transplant pepper seedlings when 4-6 inches tall with 4-6 true leaves. Soil temperature should be consistently above 18°C. Harden off seedlings for 7-10 days before transplanting."
    },
    {
      keywords: ["pepper", "aphid", "pest", "control"],
      category: "Pest Control",
      answer: "Control aphids on peppers with insecticidal soap or neem oil spray. Encourage beneficial insects like ladybugs. Spray early morning or evening to avoid leaf burn."
    },
    {
      keywords: ["pepper", "watering", "irrigation", "water"],
      category: "Care & Maintenance",
      answer: "Water peppers deeply but infrequently. Maintain consistent soil moisture - avoid alternating wet/dry cycles. Mulch around plants to retain moisture and prevent root rot."
    }
  ],
  general: [
    {
      keywords: ["soil", "test", "ph", "fertility"],
      category: "Soil Management",
      answer: "Test soil pH annually. Most vegetables prefer pH 6.0-7.0. Use lime to raise pH, sulfur to lower it. Add organic matter like compost to improve soil structure and fertility."
    },
    {
      keywords: ["organic", "pesticide", "natural", "spray"],
      category: "Pest Control",
      answer: "Natural pesticides: Neem oil for soft-bodied insects, diatomaceous earth for crawling pests, bacillus thuringiensis (Bt) for caterpillars. Always spray in evening to protect beneficial insects."
    },
    {
      keywords: ["compost", "fertilizer", "organic", "manure"],
      category: "Disease & Nutrition",
      answer: "Good compost contains kitchen scraps, dry leaves, and garden waste in 3:1 carbon:nitrogen ratio. Turn weekly, keep moist. Ready in 3-6 months when dark and earthy-smelling."
    },
    {
      keywords: ["irrigation", "water", "schedule", "watering"],
      category: "Care & Maintenance",
      answer: "Water early morning to reduce evaporation and disease risk. Deep, less frequent watering encourages deep roots. Check soil moisture 2-3 inches deep before watering."
    }
  ]
};

interface ChatMessage {
  id: number;
  type: 'user' | 'bot';
  message: string;
  category?: string;
  timestamp: Date;
}

function findBestAnswer(question: string): { answer: string; category: string; confidence: number } | null {
  const questionWords = question.toLowerCase().split(/\s+/);
  let bestMatch = null;
  let bestScore = 0;

  // Search through all categories
  Object.values(farmFAQ).flat().forEach((faq) => {
    let score = 0;
    const keywordMatches: string[] = [];
    
    // Count keyword matches
    faq.keywords.forEach((keyword) => {
      if (questionWords.some(word => word.includes(keyword.toLowerCase()) || keyword.toLowerCase().includes(word))) {
        score += 1;
        keywordMatches.push(keyword);
      }
    });
    
    // Bonus for exact phrase matches
    const questionText = question.toLowerCase();
    faq.keywords.forEach((keyword) => {
      if (questionText.includes(keyword.toLowerCase())) {
        score += 0.5;
      }
    });
    
    if (score > bestScore && score > 0) {
      bestScore = score;
      bestMatch = {
        answer: faq.answer,
        category: faq.category,
        confidence: Math.min(score / faq.keywords.length, 1)
      };
    }
  });

  return bestScore >= 1 ? bestMatch : null;
}

export default function FarmChatbot() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 1,
      type: 'bot',
      message: "Hello! I'm your farming assistant. Ask me about crop care, pest control, planting schedules, or any farming questions you have!",
      category: "Welcome",
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputMessage.trim()) return;

    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now(),
      type: 'user',
      message: inputMessage.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsTyping(true);

    // Simulate typing delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Find best answer
    const result = findBestAnswer(inputMessage);
    
    let botResponse: ChatMessage;
    if (result) {
      botResponse = {
        id: Date.now() + 1,
        type: 'bot',
        message: result.answer,
        category: result.category,
        timestamp: new Date()
      };
    } else {
      botResponse = {
        id: Date.now() + 1,
        type: 'bot',
        message: "I'm not sure about that specific question. Could you try asking about crop care, pest control, planting, harvesting, or soil management? You can also be more specific about which crop you're asking about (tomato, maize, or pepper).",
        category: "Help",
        timestamp: new Date()
      };
    }

    setIsTyping(false);
    setMessages(prev => [...prev, botResponse]);
  };

  const suggestedQuestions = [
    "When should I transplant tomato seedlings?",
    "How do I control armyworms in maize?",
    "Why are my tomato leaves turning yellow?",
    "What's the best spacing for planting maize?",
    "How often should I water peppers?"
  ];

  const handleSuggestionClick = (question: string) => {
    setInputMessage(question);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-farm-green rounded-lg flex items-center justify-center">
                <Sprout className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">FarmAssist</h1>
                <p className="text-sm text-gray-500">Smart Farming Assistant</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Link href="/">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <CloudSun className="w-4 h-4 mr-2" />
                  Weather
                </Button>
              </Link>
              <Link href="/photos">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Camera className="w-4 h-4 mr-2" />
                  Photos
                </Button>
              </Link>
              <Link href="/finance">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Finance
                </Button>
              </Link>
              <Link href="/glossary">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Glossary
                </Button>
              </Link>
              <Link href="/monitoring">
                <Button variant="outline" size="sm" className="text-farm-green border-farm-green hover:bg-farm-green hover:text-white">
                  <Activity className="w-4 h-4 mr-2" />
                  Monitor
                </Button>
              </Link>
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                <Bot className="text-farm-green text-sm" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Chat Interface */}
        <Card className="h-[600px] flex flex-col">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center space-x-2">
              <MessageSquare className="text-farm-green" />
              <span>Farming Q&A Assistant</span>
            </CardTitle>
            <p className="text-sm text-gray-600">
              Ask questions about crop care, pest control, planting, and more
            </p>
          </CardHeader>
          
          <CardContent className="flex-1 flex flex-col p-0">
            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-4 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-farm-green text-white rounded-br-sm'
                        : 'bg-gray-100 text-gray-900 rounded-bl-sm'
                    }`}
                  >
                    <div className="flex items-start space-x-2">
                      {message.type === 'bot' && (
                        <Bot className="w-4 h-4 mt-0.5 text-farm-green" />
                      )}
                      {message.type === 'user' && (
                        <User className="w-4 h-4 mt-0.5 text-white" />
                      )}
                      <div className="flex-1">
                        <p className="text-sm leading-relaxed">{message.message}</p>
                        {message.category && message.type === 'bot' && (
                          <div className="mt-2">
                            <Badge variant="secondary" className="text-xs">
                              {message.category}
                            </Badge>
                          </div>
                        )}
                        <p className={`text-xs mt-2 ${message.type === 'user' ? 'text-green-100' : 'text-gray-500'}`}>
                          {message.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 p-4 rounded-lg rounded-bl-sm max-w-[80%]">
                    <div className="flex items-center space-x-2">
                      <Bot className="w-4 h-4 text-farm-green" />
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <Separator />

            {/* Input Area */}
            <div className="p-6">
              <form onSubmit={handleSubmit} className="flex space-x-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Ask me anything about farming..."
                  className="flex-1"
                  disabled={isTyping}
                />
                <Button 
                  type="submit" 
                  disabled={!inputMessage.trim() || isTyping}
                  className="bg-farm-green hover:bg-emerald-600 text-white"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>

        {/* Suggested Questions */}
        <Card className="mt-6">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2 mb-4">
              <HelpCircle className="text-farm-green w-5 h-5" />
              <h3 className="font-semibold text-gray-900">Popular Questions</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {suggestedQuestions.map((question, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionClick(question)}
                  className="text-left p-3 bg-gray-50 hover:bg-gray-100 rounded-lg border border-gray-200 transition-colors duration-200"
                  disabled={isTyping}
                >
                  <div className="flex items-start space-x-2">
                    <Lightbulb className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gray-700">{question}</span>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}