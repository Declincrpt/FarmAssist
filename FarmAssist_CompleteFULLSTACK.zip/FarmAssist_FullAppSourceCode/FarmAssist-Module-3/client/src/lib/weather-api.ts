import type { WeatherData } from "@shared/schema";

export async function fetchWeatherData(location: string): Promise<WeatherData> {
  const response = await fetch(`/api/weather/${encodeURIComponent(location)}`);
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Failed to fetch weather data');
  }
  
  return response.json();
}

export async function fetchCropAdvisory(location: string, cropType: string) {
  const response = await fetch('/api/advisory', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ location, cropType }),
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Failed to fetch crop advisory');
  }
  
  return response.json();
}
