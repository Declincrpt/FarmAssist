import os
from flask import Flask, render_template, send_from_directory, jsonify

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

@app.route('/')
def index():
    """Serve the pest and disease diagnosis tool"""
    return render_template('index.html')

@app.route('/voice-demo')
def voice_demo():
    """Serve the voice accessibility demonstration page"""
    return render_template('voice-demo.html')

@app.route('/static/sw.js')
def service_worker():
    """Serve the service worker file with correct MIME type"""
    return send_from_directory('static', 'sw.js', mimetype='application/javascript')

@app.route('/static/manifest.json')
def manifest():
    """Serve the PWA manifest file with correct MIME type"""
    return send_from_directory('static', 'manifest.json', mimetype='application/manifest+json')

@app.route('/pwa-demo')
def pwa_demo():
    """Serve the PWA features demonstration page"""
    return render_template('pwa-demo.html')

@app.route('/disease-recognition-demo')
def disease_recognition_demo():
    """Serve the disease recognition demonstration page"""
    return render_template('disease-recognition-demo.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
