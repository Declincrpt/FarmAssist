/**
 * Modular Pest and Disease Symptom Diagnosis Tool
 * This module can be easily integrated into larger agricultural applications
 */

// Comprehensive symptom database with keyword matching
const symptomDiagnoser = {
    tomato: [
        {
            keywords: ["yellow", "spot", "leaves", "black", "dark"],
            diagnosis: "Early Blight (Alternaria solani)",
            action: "Remove infected leaves immediately. Apply copper-based fungicide or neem oil spray. Ensure good air circulation and avoid overhead watering.",
            severity: "moderate",
            prevention: "Rotate crops, mulch around plants, and water at soil level."
        },
        {
            keywords: ["curled", "leaf", "twist", "yellow", "curl"],
            diagnosis: "Tomato Yellow Leaf Curl Virus (TYLCV)",
            action: "Remove and destroy infected plants immediately. Control whiteflies with insecticidal soap or neem oil. Use reflective mulch.",
            severity: "high",
            prevention: "Use virus-resistant varieties and control whitefly populations."
        },
        {
            keywords: ["wilt", "wilting", "brown", "stem", "drooping"],
            diagnosis: "Fusarium Wilt",
            action: "Remove affected plants and soil around roots. Do not compost infected material. Apply beneficial microorganisms to soil.",
            severity: "high",
            prevention: "Use resistant varieties and avoid planting in infected soil for 3-4 years."
        },
        {
            keywords: ["white", "powder", "powdery", "mildew"],
            diagnosis: "Powdery Mildew",
            action: "Spray with baking soda solution (1 tsp per quart water) or neem oil. Improve air circulation around plants.",
            severity: "low",
            prevention: "Avoid overhead watering and ensure proper spacing between plants."
        },
        {
            keywords: ["blossom", "end", "rot", "black", "bottom"],
            diagnosis: "Blossom End Rot",
            action: "Ensure consistent watering and adequate calcium in soil. Mulch to retain moisture. Test soil pH (should be 6.0-6.8).",
            severity: "moderate",
            prevention: "Maintain consistent soil moisture and ensure proper calcium uptake."
        }
    ],
    
    maize: [
        {
            keywords: ["white", "lines", "leaf", "streak", "stripe"],
            diagnosis: "Maize Streak Virus",
            action: "Remove and destroy infected plants. Control leafhopper vectors with insecticide. Plant resistant varieties in future seasons.",
            severity: "high",
            prevention: "Use certified virus-free seeds and control leafhopper populations."
        },
        {
            keywords: ["rust", "orange", "spots", "pustules", "reddish"],
            diagnosis: "Common Rust",
            action: "Apply fungicide containing propiconazole or azoxystrobin. Remove infected plant debris. Ensure good air circulation.",
            severity: "moderate",
            prevention: "Plant resistant varieties and avoid excessive nitrogen fertilization."
        },
        {
            keywords: ["borer", "holes", "stem", "tunnel", "larvae"],
            diagnosis: "Stem Borer Infestation",
            action: "Apply biological control agents like Bacillus thuringiensis. Use pheromone traps. Remove and destroy infested stems.",
            severity: "high",
            prevention: "Practice crop rotation and remove crop residues after harvest."
        },
        {
            keywords: ["smut", "galls", "swollen", "black", "tumor"],
            diagnosis: "Common Smut",
            action: "Remove and destroy galls before they open. Avoid excessive nitrogen fertilization. Plant resistant varieties.",
            severity: "moderate",
            prevention: "Use balanced fertilization and avoid plant injuries."
        }
    ],
    
    pepper: [
        {
            keywords: ["anthracnose", "dark", "spots", "sunken", "fruit"],
            diagnosis: "Anthracnose",
            action: "Remove infected fruits and debris. Apply copper fungicide. Ensure good drainage and air circulation.",
            severity: "moderate",
            prevention: "Avoid overhead irrigation and practice crop rotation."
        },
        {
            keywords: ["bacterial", "spot", "brown", "leaves", "halo"],
            diagnosis: "Bacterial Spot",
            action: "Apply copper-based bactericide. Remove infected plant material. Avoid working with plants when wet.",
            severity: "moderate",
            prevention: "Use pathogen-free seeds and avoid overhead watering."
        },
        {
            keywords: ["virus", "mosaic", "mottled", "distorted", "yellow"],
            diagnosis: "Pepper Mosaic Virus",
            action: "Remove infected plants immediately. Control aphid vectors with insecticidal soap. Disinfect tools between plants.",
            severity: "high",
            prevention: "Use virus-resistant varieties and control aphid populations."
        }
    ],
    
    potato: [
        {
            keywords: ["late", "blight", "brown", "lesions", "white", "mold"],
            diagnosis: "Late Blight",
            action: "Apply fungicide immediately (copper or chlorothalonil). Remove infected foliage. Harvest tubers in dry weather.",
            severity: "high",
            prevention: "Use certified seed potatoes and ensure good air circulation."
        },
        {
            keywords: ["scab", "rough", "corky", "patches", "tuber"],
            diagnosis: "Common Scab",
            action: "Maintain soil pH below 5.2. Ensure adequate soil moisture during tuber formation. Avoid fresh manure.",
            severity: "low",
            prevention: "Use scab-resistant varieties and maintain proper soil conditions."
        },
        {
            keywords: ["colorado", "beetle", "striped", "larvae", "defoliation"],
            diagnosis: "Colorado Potato Beetle",
            action: "Hand-pick beetles and larvae. Apply Bacillus thuringiensis or spinosad. Use row covers early in season.",
            severity: "high",
            prevention: "Rotate crops and use resistant varieties where available."
        }
    ],
    
    cabbage: [
        {
            keywords: ["clubroot", "swollen", "roots", "wilting", "stunted"],
            diagnosis: "Clubroot",
            action: "Remove infected plants and surrounding soil. Lime soil to pH 7.2 or higher. Practice 4-year crop rotation.",
            severity: "high",
            prevention: "Use resistant varieties and maintain proper soil pH."
        },
        {
            keywords: ["black", "rot", "v-shaped", "yellow", "vascular"],
            diagnosis: "Black Rot",
            action: "Remove infected plants. Apply copper bactericide. Avoid overhead watering. Practice crop rotation.",
            severity: "moderate",
            prevention: "Use pathogen-free seeds and practice good sanitation."
        },
        {
            keywords: ["cabbage", "worm", "holes", "green", "caterpillar"],
            diagnosis: "Cabbage Worm Infestation",
            action: "Apply Bacillus thuringiensis spray. Hand-pick large caterpillars. Use row covers during egg-laying periods.",
            severity: "moderate",
            prevention: "Monitor regularly and use beneficial insects like parasitic wasps."
        }
    ],
    
    beans: [
        {
            keywords: ["rust", "orange", "pustules", "undersides", "leaves"],
            diagnosis: "Bean Rust",
            action: "Apply sulfur-based fungicide. Remove infected plant debris. Ensure good air circulation between plants.",
            severity: "moderate",
            prevention: "Plant resistant varieties and avoid overhead watering."
        },
        {
            keywords: ["mosaic", "mottled", "distorted", "virus", "stunted"],
            diagnosis: "Bean Mosaic Virus",
            action: "Remove infected plants immediately. Control aphid vectors. Use virus-free seeds for next planting.",
            severity: "high",
            prevention: "Use certified seeds and control aphid populations."
        },
        {
            keywords: ["bacterial", "blight", "water", "soaked", "brown"],
            diagnosis: "Bacterial Blight",
            action: "Remove infected plants. Apply copper bactericide. Avoid working with wet plants. Practice crop rotation.",
            severity: "moderate",
            prevention: "Use pathogen-free seeds and practice good sanitation."
        }
    ],
    
    rice: [
        {
            keywords: ["blast", "diamond", "lesions", "gray", "center"],
            diagnosis: "Rice Blast",
            action: "Apply tricyclazole or azoxystrobin fungicide. Maintain proper water management. Remove infected plant debris.",
            severity: "high",
            prevention: "Use resistant varieties and balanced nitrogen fertilization."
        },
        {
            keywords: ["brown", "spot", "oval", "lesions", "seedling"],
            diagnosis: "Brown Spot",
            action: "Apply mancozeb or copper fungicide. Ensure proper seed treatment. Maintain adequate nutrition.",
            severity: "moderate",
            prevention: "Use healthy seeds and ensure balanced fertilization."
        },
        {
            keywords: ["sheath", "blight", "irregular", "patches", "water"],
            diagnosis: "Sheath Blight",
            action: "Apply propiconazole fungicide. Maintain proper water levels. Remove infected plant material.",
            severity: "moderate",
            prevention: "Avoid excessive nitrogen and maintain proper plant spacing."
        }
    ],
    
    wheat: [
        {
            keywords: ["stripe", "rust", "yellow", "linear", "pustules"],
            diagnosis: "Stripe Rust",
            action: "Apply triazole fungicide immediately. Monitor weather conditions. Use resistant varieties in future plantings.",
            severity: "high",
            prevention: "Plant resistant varieties and monitor regional rust reports."
        },
        {
            keywords: ["powdery", "mildew", "white", "powder", "leaves"],
            diagnosis: "Powdery Mildew",
            action: "Apply sulfur or triazole fungicide. Ensure good air circulation. Avoid excessive nitrogen fertilization.",
            severity: "moderate",
            prevention: "Use resistant varieties and maintain proper plant nutrition."
        },
        {
            keywords: ["fusarium", "head", "blight", "pink", "scab"],
            diagnosis: "Fusarium Head Blight",
            action: "Apply fungicide at early flowering. Harvest early if possible. Dry grain thoroughly to prevent mycotoxins.",
            severity: "high",
            prevention: "Use resistant varieties and practice crop rotation."
        }
    ]
};

/**
 * Symptom Diagnoser Class - Modular implementation for easy integration
 */
class SymptomDiagnoser {
    constructor(symptomDatabase = symptomDiagnoser) {
        this.database = symptomDatabase;
        this.initializeEventListeners();
    }

    /**
     * Initialize event listeners for the form
     */
    initializeEventListeners() {
        const form = document.getElementById('diagnosisForm');
        if (form) {
            form.addEventListener('submit', (e) => this.handleFormSubmit(e));
        }

        // Optional: Real-time diagnosis as user types (debounced)
        const symptomInput = document.getElementById('symptomInput');
        if (symptomInput) {
            let timeout;
            symptomInput.addEventListener('input', () => {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    const crop = document.getElementById('cropSelect').value;
                    if (crop && symptomInput.value.length > 3) {
                        this.performDiagnosis(crop, symptomInput.value, false);
                    }
                }, 1000);
            });
        }
    }

    /**
     * Handle form submission
     * @param {Event} event - Form submit event
     */
    handleFormSubmit(event) {
        event.preventDefault();
        
        const crop = document.getElementById('cropSelect').value;
        const symptoms = document.getElementById('symptomInput').value;

        if (!crop || !symptoms.trim()) {
            this.showValidationError('Please select a crop and describe the symptoms.');
            return;
        }

        this.performDiagnosis(crop, symptoms, true);
    }

    /**
     * Perform diagnosis based on crop and symptoms
     * @param {string} crop - Selected crop
     * @param {string} symptoms - Symptom description
     * @param {boolean} showLoading - Whether to show loading indicator
     */
    performDiagnosis(crop, symptoms, showLoading = true) {
        if (showLoading) {
            this.showLoading();
        }

        // Simulate processing time for better UX
        setTimeout(() => {
            const matches = this.findMatches(crop, symptoms);
            
            if (matches.length > 0) {
                this.displayResults(matches, crop, symptoms);
            } else {
                this.showNoResults();
            }
        }, showLoading ? 1500 : 0);
    }

    /**
     * Find matching diagnoses based on keywords
     * @param {string} crop - Selected crop
     * @param {string} symptoms - Symptom description
     * @returns {Array} Array of matching diagnoses with scores
     */
    findMatches(crop, symptoms) {
        const cropData = this.database[crop.toLowerCase()];
        if (!cropData) return [];

        const symptomsLower = symptoms.toLowerCase();
        const symptomWords = symptomsLower.split(/\s+/);
        
        const matches = [];

        cropData.forEach(entry => {
            let score = 0;
            let matchedKeywords = [];

            entry.keywords.forEach(keyword => {
                // Check for exact keyword matches
                if (symptomsLower.includes(keyword.toLowerCase())) {
                    score += 2;
                    matchedKeywords.push(keyword);
                }
                
                // Check for partial matches in individual words
                symptomWords.forEach(word => {
                    if (word.includes(keyword.toLowerCase()) || keyword.toLowerCase().includes(word)) {
                        score += 1;
                        if (!matchedKeywords.includes(keyword)) {
                            matchedKeywords.push(keyword);
                        }
                    }
                });
            });

            if (score > 0) {
                matches.push({
                    ...entry,
                    score,
                    matchedKeywords,
                    confidence: this.calculateConfidence(score, entry.keywords.length)
                });
            }
        });

        // Sort by score (highest first) and confidence
        return matches.sort((a, b) => {
            if (b.score !== a.score) return b.score - a.score;
            return b.confidence - a.confidence;
        });
    }

    /**
     * Calculate confidence percentage based on keyword matches
     * @param {number} score - Match score
     * @param {number} totalKeywords - Total keywords for the diagnosis
     * @returns {number} Confidence percentage
     */
    calculateConfidence(score, totalKeywords) {
        const maxPossibleScore = totalKeywords * 2;
        return Math.min(Math.round((score / maxPossibleScore) * 100), 95);
    }

    /**
     * Display diagnosis results
     * @param {Array} matches - Array of matching diagnoses
     * @param {string} crop - Selected crop
     * @param {string} symptoms - Original symptoms
     */
    displayResults(matches, crop, symptoms) {
        const resultsContent = document.getElementById('resultsContent');
        const topMatch = matches[0];
        
        let html = `
            <div class="mb-4">
                <div class="d-flex align-items-center mb-2">
                    <i class="fas fa-bullseye text-success me-2"></i>
                    <span class="badge bg-success fs-6">${topMatch.confidence}% Match</span>
                </div>
                <h4 class="text-success mb-3">${topMatch.diagnosis}</h4>
                
                <div class="alert alert-${this.getSeverityClass(topMatch.severity)} mb-3">
                    <div class="d-flex align-items-center mb-2">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Severity: ${topMatch.severity.charAt(0).toUpperCase() + topMatch.severity.slice(1)}</strong>
                    </div>
                </div>

                <div class="mb-4">
                    <h6 class="fw-bold text-primary">
                        <i class="fas fa-prescription-bottle me-2"></i>
                        Recommended Action:
                    </h6>
                    <p class="mb-2">${topMatch.action}</p>
                    
                    ${topMatch.prevention ? `
                        <h6 class="fw-bold text-info mt-3">
                            <i class="fas fa-shield-alt me-2"></i>
                            Prevention:
                        </h6>
                        <p class="mb-2">${topMatch.prevention}</p>
                    ` : ''}
                </div>

                <div class="mb-3">
                    <h6 class="fw-bold">
                        <i class="fas fa-tags me-2"></i>
                        Matched Keywords:
                    </h6>
                    <div>
                        ${topMatch.matchedKeywords.map(keyword => 
                            `<span class="badge bg-secondary me-1">${keyword}</span>`
                        ).join('')}
                    </div>
                </div>
            </div>
        `;

        // Show alternative diagnoses if available
        if (matches.length > 1) {
            html += `
                <div class="mt-4">
                    <h6 class="fw-bold text-muted">
                        <i class="fas fa-list-alt me-2"></i>
                        Alternative Possibilities:
                    </h6>
                    <div class="row">
            `;
            
            matches.slice(1, 3).forEach((match, index) => {
                html += `
                    <div class="col-md-6 mb-2">
                        <div class="card border-secondary">
                            <div class="card-body py-2">
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="fw-bold">${match.diagnosis}</small>
                                    <span class="badge bg-secondary">${match.confidence}%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            html += '</div></div>';
        }

        // Add expert consultation recommendation
        html += `
            <div class="mt-4 p-3 bg-light rounded">
                <p class="mb-2 text-dark">
                    <i class="fas fa-user-md me-2 text-primary"></i>
                    <strong>Expert Recommendation:</strong>
                </p>
                <p class="mb-0 text-dark small">
                    For the most accurate diagnosis and treatment plan, consider consulting with your local agricultural extension officer or plant pathologist, especially for high-severity issues.
                </p>
            </div>
        `;

        resultsContent.innerHTML = html;
        this.showSection('resultsSection');
        
        // Add voice accessibility to newly created content
        if (window.voiceAccessibility) {
            setTimeout(() => {
                window.voiceAccessibility.addReadAloudButtons();
            }, 100);
        }
    }

    /**
     * Get CSS class for severity level
     * @param {string} severity - Severity level
     * @returns {string} Bootstrap alert class
     */
    getSeverityClass(severity) {
        const severityMap = {
            'low': 'info',
            'moderate': 'warning',
            'high': 'danger'
        };
        return severityMap[severity] || 'info';
    }

    /**
     * Show no results found
     */
    showNoResults() {
        this.showSection('noResultsSection');
    }

    /**
     * Show loading indicator
     */
    showLoading() {
        this.hideAllSections();
        document.getElementById('loadingSection').style.display = 'block';
    }

    /**
     * Show validation error
     * @param {string} message - Error message
     */
    showValidationError(message) {
        // Create or update error message
        let errorDiv = document.getElementById('validationError');
        if (!errorDiv) {
            errorDiv = document.createElement('div');
            errorDiv.id = 'validationError';
            errorDiv.className = 'alert alert-danger mt-3';
            document.getElementById('diagnosisForm').appendChild(errorDiv);
        }
        
        errorDiv.innerHTML = `
            <i class="fas fa-exclamation-circle me-2"></i>
            ${message}
        `;
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            if (errorDiv) {
                errorDiv.remove();
            }
        }, 5000);
    }

    /**
     * Show specific section and hide others
     * @param {string} sectionId - ID of section to show
     */
    showSection(sectionId) {
        this.hideAllSections();
        document.getElementById(sectionId).style.display = 'block';
    }

    /**
     * Hide all result sections
     */
    hideAllSections() {
        ['resultsSection', 'noResultsSection', 'loadingSection'].forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.style.display = 'none';
            }
        });
    }

    /**
     * Get diagnosis for external integration
     * @param {string} crop - Crop name
     * @param {string} symptoms - Symptom description
     * @returns {Array} Array of diagnoses
     */
    getDiagnosis(crop, symptoms) {
        return this.findMatches(crop, symptoms);
    }

    /**
     * Add custom crop data for integration
     * @param {string} crop - Crop name
     * @param {Array} data - Array of symptom objects
     */
    addCropData(crop, data) {
        this.database[crop.toLowerCase()] = data;
    }

    /**
     * Get available crops
     * @returns {Array} Array of crop names
     */
    getAvailableCrops() {
        return Object.keys(this.database);
    }
}

// Initialize the diagnoser when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Create global instance for easy integration
    window.symptomDiagnoser = new SymptomDiagnoser();
    
    // Export for module-based integration
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = { SymptomDiagnoser, symptomDiagnoser };
    }
});

// Additional utility functions for external integration
const DiagnosisUtils = {
    /**
     * Format diagnosis results for API response
     * @param {Array} results - Diagnosis results
     * @returns {Object} Formatted response
     */
    formatForAPI: function(results) {
        return {
            success: results.length > 0,
            count: results.length,
            primary_diagnosis: results[0] || null,
            alternatives: results.slice(1),
            timestamp: new Date().toISOString()
        };
    },

    /**
     * Extract keywords from symptom text
     * @param {string} text - Symptom text
     * @returns {Array} Array of keywords
     */
    extractKeywords: function(text) {
        const commonWords = ['the', 'is', 'are', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'];
        return text.toLowerCase()
            .split(/\s+/)
            .filter(word => word.length > 2 && !commonWords.includes(word))
            .filter((word, index, arr) => arr.indexOf(word) === index);
    },

    /**
     * Calculate similarity between two symptom descriptions
     * @param {string} text1 - First text
     * @param {string} text2 - Second text
     * @returns {number} Similarity score (0-100)
     */
    calculateSimilarity: function(text1, text2) {
        const keywords1 = this.extractKeywords(text1);
        const keywords2 = this.extractKeywords(text2);
        
        const intersection = keywords1.filter(word => keywords2.includes(word));
        const union = [...new Set([...keywords1, ...keywords2])];
        
        return union.length > 0 ? Math.round((intersection.length / union.length) * 100) : 0;
    }
};

// Export utilities for external use
if (typeof window !== 'undefined') {
    window.DiagnosisUtils = DiagnosisUtils;
}
