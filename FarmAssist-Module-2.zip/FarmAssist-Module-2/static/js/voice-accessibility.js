/**
 * Voice & Language Accessibility Module
 * Modular text-to-speech implementation for agricultural applications
 * Supports multiple languages and offline functionality
 */

class VoiceAccessibilityModule {
    constructor() {
        this.synth = window.speechSynthesis;
        this.voices = [];
        this.currentLanguage = 'en';
        this.currentVoice = null;
        this.isReading = false;
        
        // Language mappings for voice selection
        this.languageMap = {
            'en': { code: 'en-US', name: 'English', fallback: 'en' },
            'sw': { code: 'sw-KE', name: 'Swahili', fallback: 'en' },
            'yo': { code: 'yo-NG', name: 'Yoruba', fallback: 'en' }
        };

        this.init();
    }

    /**
     * Initialize the voice accessibility module
     */
    init() {
        this.loadVoices();
        this.createLanguageSelector();
        this.addReadAloudButtons();
        
        // Listen for voice changes (some browsers load voices asynchronously)
        if (this.synth.onvoiceschanged !== undefined) {
            this.synth.onvoiceschanged = () => this.loadVoices();
        }
    }

    /**
     * Load available voices from the browser
     */
    loadVoices() {
        this.voices = this.synth.getVoices();
        this.selectBestVoice();
        console.log('Available voices loaded:', this.voices.length);
    }

    /**
     * Select the best voice for current language
     */
    selectBestVoice() {
        const langConfig = this.languageMap[this.currentLanguage];
        if (!langConfig) return;

        // Try to find voice for exact language code
        let voice = this.voices.find(v => v.lang === langConfig.code);
        
        // Fallback to language without region
        if (!voice) {
            voice = this.voices.find(v => v.lang.startsWith(langConfig.code.split('-')[0]));
        }
        
        // Final fallback to English
        if (!voice) {
            voice = this.voices.find(v => v.lang.startsWith('en'));
        }
        
        this.currentVoice = voice;
        console.log('Selected voice:', voice?.name, voice?.lang);
    }

    /**
     * Create language selector dropdown
     */
    createLanguageSelector() {
        // Check if selector already exists
        if (document.getElementById('languageSelector')) return;

        const selectorHtml = `
            <div class="language-selector-container mb-3">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <label for="languageSelector" class="form-label fw-semibold mb-0">
                            <i class="fas fa-globe me-2"></i>
                            Language:
                        </label>
                    </div>
                    <div class="col-auto">
                        <select class="form-select form-select-sm" id="languageSelector">
                            <option value="en">🇺🇸 English</option>
                            <option value="sw">🇰🇪 Swahili</option>
                            <option value="yo">🇳🇬 Yoruba</option>
                        </select>
                    </div>
                    <div class="col-auto">
                        <button type="button" class="btn btn-outline-secondary btn-sm" id="testVoiceBtn">
                            <i class="fas fa-volume-up me-1"></i>
                            Test Voice
                        </button>
                    </div>
                </div>
            </div>
        `;

        // Insert at the top of the main container
        const container = document.querySelector('.container');
        if (container) {
            container.insertAdjacentHTML('afterbegin', selectorHtml);
            this.bindLanguageSelectorEvents();
        }
    }

    /**
     * Bind events to language selector
     */
    bindLanguageSelectorEvents() {
        const selector = document.getElementById('languageSelector');
        const testBtn = document.getElementById('testVoiceBtn');

        if (selector) {
            selector.addEventListener('change', (e) => {
                this.currentLanguage = e.target.value;
                this.selectBestVoice();
                console.log('Language changed to:', this.currentLanguage);
            });
        }

        if (testBtn) {
            testBtn.addEventListener('click', () => {
                const testText = this.getTestText();
                this.speakText(testText);
            });
        }
    }

    /**
     * Get test text for current language
     */
    getTestText() {
        const testTexts = {
            'en': 'Hello farmer! This is how the voice will sound in English.',
            'sw': 'Hujambo mkulima! Hii ni jinsi sauti itakavyosikika kwa Kiswahili.',
            'yo': 'Bawo agbe! Eyi ni bi ohun naa ti yoo dun ni ede Yoruba.'
        };
        return testTexts[this.currentLanguage] || testTexts['en'];
    }

    /**
     * Add read aloud buttons to existing content
     */
    addReadAloudButtons() {
        // Find all elements that could benefit from read-aloud functionality
        const targetSelectors = [
            '.card-body p',
            '.alert',
            '.diagnosis-result',
            'li',
            '.form-text'
        ];

        targetSelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                // Skip if already has read button or is very short
                if (element.querySelector('.read-aloud-btn') || 
                    element.textContent.trim().length < 10) return;

                this.addReadAloudButton(element);
            });
        });
    }

    /**
     * Add read aloud button to specific element
     */
    addReadAloudButton(element) {
        const button = document.createElement('button');
        button.className = 'btn btn-sm btn-outline-primary read-aloud-btn ms-2';
        button.type = 'button';
        button.innerHTML = '<i class="fas fa-volume-up"></i>';
        button.title = 'Read Aloud';
        
        // Style the button to be inline and subtle
        button.style.fontSize = '0.75rem';
        button.style.padding = '0.25rem 0.5rem';
        button.style.verticalAlign = 'middle';

        button.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.speakText(element.textContent.trim());
        });

        // Insert button at the end of the element
        element.style.position = 'relative';
        element.appendChild(button);
    }

    /**
     * Speak text using browser's text-to-speech
     */
    speakText(text) {
        if (!text || text.trim().length === 0) return;

        // Stop any ongoing speech
        this.stopSpeaking();

        // Clean the text
        const cleanText = this.cleanTextForSpeech(text);

        // Create speech utterance
        const utterance = new SpeechSynthesisUtterance(cleanText);
        
        // Configure utterance
        utterance.rate = 0.9; // Slightly slower for clarity
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        
        if (this.currentVoice) {
            utterance.voice = this.currentVoice;
        } else {
            utterance.lang = this.languageMap[this.currentLanguage]?.code || 'en-US';
        }

        // Event handlers
        utterance.onstart = () => {
            this.isReading = true;
            this.highlightActiveButtons(true);
            console.log('Started speaking:', cleanText.substring(0, 50) + '...');
        };

        utterance.onend = () => {
            this.isReading = false;
            this.highlightActiveButtons(false);
            console.log('Finished speaking');
        };

        utterance.onerror = (event) => {
            console.error('Speech synthesis error:', event.error);
            this.isReading = false;
            this.highlightActiveButtons(false);
            this.showErrorNotification('Unable to read text aloud. Please check your browser settings.');
        };

        // Speak the text
        this.synth.speak(utterance);
    }

    /**
     * Clean text for better speech synthesis
     */
    cleanTextForSpeech(text) {
        return text
            .replace(/[📱💡🌱🔍📊🎯]/g, '') // Remove emojis
            .replace(/\s+/g, ' ') // Normalize spaces
            .replace(/([.!?])\s*([A-Z])/g, '$1 $2') // Add pauses between sentences
            .trim();
    }

    /**
     * Stop current speech
     */
    stopSpeaking() {
        if (this.synth.speaking) {
            this.synth.cancel();
            this.isReading = false;
            this.highlightActiveButtons(false);
        }
    }

    /**
     * Highlight active read-aloud buttons
     */
    highlightActiveButtons(active) {
        const buttons = document.querySelectorAll('.read-aloud-btn');
        buttons.forEach(btn => {
            if (active) {
                btn.classList.add('btn-primary');
                btn.classList.remove('btn-outline-primary');
                btn.innerHTML = '<i class="fas fa-pause"></i>';
                btn.title = 'Stop Reading';
            } else {
                btn.classList.remove('btn-primary');
                btn.classList.add('btn-outline-primary');
                btn.innerHTML = '<i class="fas fa-volume-up"></i>';
                btn.title = 'Read Aloud';
            }
        });
    }

    /**
     * Show error notification
     */
    showErrorNotification(message) {
        // Create temporary notification
        const notification = document.createElement('div');
        notification.className = 'alert alert-warning alert-dismissible fade show position-fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.zIndex = '9999';
        notification.style.maxWidth = '300px';
        
        notification.innerHTML = `
            <strong>Voice Error:</strong> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        document.body.appendChild(notification);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    /**
     * Add read-aloud capability to dynamic content
     */
    addToElement(element) {
        if (element && !element.querySelector('.read-aloud-btn')) {
            this.addReadAloudButton(element);
        }
    }

    /**
     * Get current language
     */
    getCurrentLanguage() {
        return this.currentLanguage;
    }

    /**
     * Set language programmatically
     */
    setLanguage(languageCode) {
        if (this.languageMap[languageCode]) {
            this.currentLanguage = languageCode;
            this.selectBestVoice();
            
            const selector = document.getElementById('languageSelector');
            if (selector) {
                selector.value = languageCode;
            }
        }
    }

    /**
     * Check if text-to-speech is supported
     */
    static isSupported() {
        return 'speechSynthesis' in window;
    }
}

// Initialize the voice accessibility module when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    if (VoiceAccessibilityModule.isSupported()) {
        window.voiceAccessibility = new VoiceAccessibilityModule();
        console.log('Voice Accessibility Module initialized successfully');
    } else {
        console.warn('Text-to-speech not supported in this browser');
        // Initialize fallback mode that shows the interface but with disabled functionality
        window.voiceAccessibility = new VoiceAccessibilityFallback();
    }
});

/**
 * Fallback implementation for browsers without SpeechSynthesis support
 */
class VoiceAccessibilityFallback {
    constructor() {
        this.init();
    }

    init() {
        this.createLanguageSelector();
        this.addReadAloudButtons();
    }

    createLanguageSelector() {
        // Check if selector already exists
        if (document.getElementById('languageSelector')) return;

        const selectorHtml = `
            <div class="language-selector-container mb-3">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <label for="languageSelector" class="form-label fw-semibold mb-0">
                            <i class="fas fa-globe me-2"></i>
                            Language:
                        </label>
                    </div>
                    <div class="col-auto">
                        <select class="form-select form-select-sm" id="languageSelector">
                            <option value="en">🇺🇸 English</option>
                            <option value="sw">🇰🇪 Swahili</option>
                            <option value="yo">🇳🇬 Yoruba</option>
                        </select>
                    </div>
                    <div class="col-auto">
                        <div class="alert alert-warning mb-0 py-2 px-3" style="font-size: 0.8rem;">
                            <i class="fas fa-exclamation-triangle me-1"></i>
                            Voice not supported in this browser
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Insert at the top of the main container
        const container = document.querySelector('.container');
        if (container) {
            container.insertAdjacentHTML('afterbegin', selectorHtml);
        }
    }

    addReadAloudButtons() {
        // Find all elements that could benefit from read-aloud functionality
        const targetSelectors = [
            '.card-body p',
            '.alert',
            '.diagnosis-result',
            'li',
            '.form-text'
        ];

        targetSelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                // Skip if already has read button or is very short
                if (element.querySelector('.read-aloud-btn') || 
                    element.textContent.trim().length < 10) return;

                this.addReadAloudButton(element);
            });
        });
    }

    addReadAloudButton(element) {
        const button = document.createElement('button');
        button.className = 'btn btn-sm btn-outline-secondary read-aloud-btn ms-2';
        button.type = 'button';
        button.innerHTML = '<i class="fas fa-volume-up"></i>';
        button.title = 'Voice not supported in this browser';
        button.disabled = true;
        
        // Style the button to be inline and subtle
        button.style.fontSize = '0.75rem';
        button.style.padding = '0.25rem 0.5rem';
        button.style.verticalAlign = 'middle';

        button.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.showNotSupportedMessage();
        });

        // Insert button at the end of the element
        element.style.position = 'relative';
        element.appendChild(button);
    }

    showNotSupportedMessage() {
        // Create temporary notification
        const notification = document.createElement('div');
        notification.className = 'alert alert-info alert-dismissible fade show position-fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.zIndex = '9999';
        notification.style.maxWidth = '300px';
        
        notification.innerHTML = `
            <strong>Voice Feature:</strong> Text-to-speech is not supported in this browser environment. The feature will work in modern browsers like Chrome, Firefox, or Safari.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        document.body.appendChild(notification);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    getCurrentLanguage() {
        const selector = document.getElementById('languageSelector');
        return selector ? selector.value : 'en';
    }

    setLanguage(languageCode) {
        const selector = document.getElementById('languageSelector');
        if (selector) {
            selector.value = languageCode;
        }
    }

    addToElement(element) {
        if (element && !element.querySelector('.read-aloud-btn')) {
            this.addReadAloudButton(element);
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VoiceAccessibilityModule;
}