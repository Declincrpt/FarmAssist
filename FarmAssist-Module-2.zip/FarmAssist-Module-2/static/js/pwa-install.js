/**
 * PWA Installation and Service Worker Management
 * Handles app installation prompts and offline functionality
 */

class PWAInstaller {
    constructor() {
        this.deferredPrompt = null;
        this.installButton = null;
        this.isInstalled = false;
        this.swRegistration = null;
        
        this.init();
    }

    /**
     * Initialize PWA installation features
     */
    async init() {
        this.checkInstallStatus();
        this.createInstallButton();
        this.registerServiceWorker();
        this.bindEventListeners();
        this.addConnectionStatus();
    }

    /**
     * Check if app is already installed
     */
    checkInstallStatus() {
        // Check if running in standalone mode (installed)
        this.isInstalled = window.matchMedia('(display-mode: standalone)').matches ||
                          window.navigator.standalone ||
                          document.referrer.includes('android-app://');
        
        console.log('[PWA] App installed status:', this.isInstalled);
    }

    /**
     * Create install button in the header
     */
    createInstallButton() {
        // Don't show install button if already installed
        if (this.isInstalled) {
            console.log('[PWA] App already installed, hiding install prompt');
            return;
        }

        const installContainer = document.createElement('div');
        installContainer.className = 'pwa-install-container';
        installContainer.innerHTML = `
            <div class="alert alert-success alert-dismissible fade show mx-3 mb-3" id="installAlert" style="display: none;">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <strong><i class="fas fa-mobile-alt me-2"></i>Install FarmAssist Crop</strong>
                        <div class="small">Add to your home screen for quick access, even offline!</div>
                    </div>
                    <div class="ms-3">
                        <button type="button" class="btn btn-success btn-sm me-2" id="installBtn">
                            <i class="fas fa-download me-1"></i>Install
                        </button>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
                    </div>
                </div>
            </div>
        `;

        // Insert after the language selector or at the beginning of container
        const container = document.querySelector('.container');
        const firstChild = container.firstElementChild;
        container.insertBefore(installContainer, firstChild);

        this.installButton = document.getElementById('installBtn');
        this.installAlert = document.getElementById('installAlert');
    }

    /**
     * Register service worker
     */
    async registerServiceWorker() {
        if ('serviceWorker' in navigator) {
            try {
                console.log('[PWA] Registering service worker...');
                
                this.swRegistration = await navigator.serviceWorker.register('/static/sw.js', {
                    scope: '/'
                });

                console.log('[PWA] Service worker registered successfully:', this.swRegistration.scope);

                // Handle service worker updates
                this.swRegistration.addEventListener('updatefound', () => {
                    console.log('[PWA] New service worker version found');
                    this.handleServiceWorkerUpdate();
                });

                // Check for waiting service worker
                if (this.swRegistration.waiting) {
                    this.showUpdateAvailable();
                }

            } catch (error) {
                console.error('[PWA] Service worker registration failed:', error);
            }
        } else {
            console.warn('[PWA] Service workers not supported in this browser');
        }
    }

    /**
     * Bind event listeners for PWA features
     */
    bindEventListeners() {
        // Before install prompt event
        window.addEventListener('beforeinstallprompt', (e) => {
            console.log('[PWA] Before install prompt triggered');
            e.preventDefault();
            this.deferredPrompt = e;
            this.showInstallPrompt();
        });

        // App installed event
        window.addEventListener('appinstalled', () => {
            console.log('[PWA] App successfully installed');
            this.hideInstallPrompt();
            this.showInstallSuccess();
        });

        // Install button click
        if (this.installButton) {
            this.installButton.addEventListener('click', () => {
                this.promptInstall();
            });
        }

        // Online/offline status
        window.addEventListener('online', () => {
            this.updateConnectionStatus(true);
        });

        window.addEventListener('offline', () => {
            this.updateConnectionStatus(false);
        });
    }

    /**
     * Show install prompt
     */
    showInstallPrompt() {
        if (this.installAlert && !this.isInstalled) {
            this.installAlert.style.display = 'block';
            
            // Auto-hide after 10 seconds
            setTimeout(() => {
                if (this.installAlert) {
                    this.installAlert.style.display = 'none';
                }
            }, 10000);
        }
    }

    /**
     * Hide install prompt
     */
    hideInstallPrompt() {
        if (this.installAlert) {
            this.installAlert.style.display = 'none';
        }
    }

    /**
     * Prompt user to install the app
     */
    async promptInstall() {
        if (!this.deferredPrompt) {
            console.log('[PWA] No deferred prompt available');
            this.showManualInstallInstructions();
            return;
        }

        try {
            // Show the install prompt
            this.deferredPrompt.prompt();
            
            // Wait for user response
            const { outcome } = await this.deferredPrompt.userChoice;
            console.log('[PWA] User choice:', outcome);
            
            if (outcome === 'accepted') {
                console.log('[PWA] User accepted the install prompt');
            } else {
                console.log('[PWA] User dismissed the install prompt');
            }
            
            // Clear the deferred prompt
            this.deferredPrompt = null;
            this.hideInstallPrompt();
            
        } catch (error) {
            console.error('[PWA] Install prompt failed:', error);
        }
    }

    /**
     * Show manual install instructions for browsers that don't support auto-prompt
     */
    showManualInstallInstructions() {
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.innerHTML = `
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-mobile-alt me-2"></i>
                            Install FarmAssist Crop
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>To install FarmAssist Crop on your device:</p>
                        
                        <div class="mb-3">
                            <h6><i class="fab fa-chrome me-2"></i>Chrome (Android/Desktop):</h6>
                            <ol class="small">
                                <li>Tap the menu button (⋮)</li>
                                <li>Select "Add to Home screen" or "Install app"</li>
                                <li>Follow the prompts</li>
                            </ol>
                        </div>
                        
                        <div class="mb-3">
                            <h6><i class="fab fa-safari me-2"></i>Safari (iOS):</h6>
                            <ol class="small">
                                <li>Tap the share button (⬆)</li>
                                <li>Scroll down and tap "Add to Home Screen"</li>
                                <li>Tap "Add"</li>
                            </ol>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <strong>Benefits:</strong> Faster loading, offline access, and quick access from your home screen!
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
        
        // Clean up when modal is hidden
        modal.addEventListener('hidden.bs.modal', () => {
            modal.remove();
        });
    }

    /**
     * Show install success message
     */
    showInstallSuccess() {
        this.showNotification('App installed successfully! You can now access FarmAssist Crop from your home screen.', 'success');
    }

    /**
     * Handle service worker updates
     */
    handleServiceWorkerUpdate() {
        const newWorker = this.swRegistration.installing;
        
        newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                this.showUpdateAvailable();
            }
        });
    }

    /**
     * Show update available notification
     */
    showUpdateAvailable() {
        const notification = document.createElement('div');
        notification.className = 'alert alert-info alert-dismissible fade show position-fixed';
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 300px;';
        notification.innerHTML = `
            <strong>Update Available!</strong><br>
            A new version of FarmAssist Crop is ready.
            <div class="mt-2">
                <button type="button" class="btn btn-info btn-sm me-2" id="updateBtn">
                    <i class="fas fa-sync me-1"></i>Update Now
                </button>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        document.getElementById('updateBtn').addEventListener('click', () => {
            this.updateServiceWorker();
            notification.remove();
        });
        
        // Auto remove after 10 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 10000);
    }

    /**
     * Update service worker to new version
     */
    updateServiceWorker() {
        if (this.swRegistration && this.swRegistration.waiting) {
            this.swRegistration.waiting.postMessage({ type: 'SKIP_WAITING' });
            window.location.reload();
        }
    }

    /**
     * Add connection status indicator
     */
    addConnectionStatus() {
        const statusDiv = document.createElement('div');
        statusDiv.id = 'connectionStatus';
        statusDiv.className = 'position-fixed bottom-0 end-0 m-3';
        statusDiv.style.zIndex = '9998';
        
        document.body.appendChild(statusDiv);
        this.connectionStatus = statusDiv;
        
        // Set initial status
        this.updateConnectionStatus(navigator.onLine);
    }

    /**
     * Update connection status display
     */
    updateConnectionStatus(isOnline) {
        if (!this.connectionStatus) return;
        
        if (isOnline) {
            this.connectionStatus.innerHTML = `
                <div class="badge bg-success">
                    <i class="fas fa-wifi me-1"></i>Online
                </div>
            `;
            
            // Hide online status after 3 seconds
            setTimeout(() => {
                if (this.connectionStatus) {
                    this.connectionStatus.innerHTML = '';
                }
            }, 3000);
        } else {
            this.connectionStatus.innerHTML = `
                <div class="badge bg-warning text-dark">
                    <i class="fas fa-wifi-slash me-1"></i>Offline Mode
                </div>
            `;
        }
    }

    /**
     * Show notification message
     */
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    /**
     * Get PWA status information
     */
    getStatus() {
        return {
            isInstalled: this.isInstalled,
            hasServiceWorker: !!this.swRegistration,
            isOnline: navigator.onLine,
            canInstall: !!this.deferredPrompt
        };
    }
}

// Initialize PWA installer when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    console.log('[PWA] Initializing PWA installer...');
    window.pwaInstaller = new PWAInstaller();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PWAInstaller;
}