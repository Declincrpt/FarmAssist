/**
 * Service Worker for FarmAssist Crop PWA
 * Provides offline functionality and caching for agricultural app
 */

const CACHE_NAME = 'farmassist-crop-v1.0.0';
const STATIC_CACHE_NAME = 'farmassist-static-v1.0.0';
const DYNAMIC_CACHE_NAME = 'farmassist-dynamic-v1.0.0';

// Files to cache immediately (critical app shell)
const STATIC_FILES = [
  '/',
  '/voice-demo',
  '/static/css/styles.css',
  '/static/js/symptom-diagnoser.js',
  '/static/js/voice-accessibility.js',
  '/static/manifest.json',
  'https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'
];

// Network-first resources (always try to get fresh content)
const NETWORK_FIRST = [
  '/api/',
  '/static/manifest.json'
];

// Cache-first resources (use cached version when available)
const CACHE_FIRST = [
  '/static/css/',
  '/static/js/',
  '/static/icons/',
  'https://cdn.replit.com/',
  'https://cdnjs.cloudflare.com/',
  'https://cdn.jsdelivr.net/'
];

/**
 * Install Event - Cache critical resources
 */
self.addEventListener('install', (event) => {
  console.log('[SW] Installing Service Worker...');
  
  event.waitUntil(
    caches.open(STATIC_CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Caching app shell and static files');
        return cache.addAll(STATIC_FILES);
      })
      .then(() => {
        console.log('[SW] All static files cached successfully');
        return self.skipWaiting(); // Force activate new SW immediately
      })
      .catch((error) => {
        console.error('[SW] Failed to cache static files:', error);
      })
  );
});

/**
 * Activate Event - Clean old caches and claim clients
 */
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating Service Worker...');
  
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            // Delete old caches
            if (cacheName !== STATIC_CACHE_NAME && 
                cacheName !== DYNAMIC_CACHE_NAME && 
                cacheName !== CACHE_NAME) {
              console.log('[SW] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('[SW] Service Worker activated and ready');
        return self.clients.claim(); // Take control of all pages immediately
      })
  );
});

/**
 * Fetch Event - Handle all network requests with caching strategies
 */
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);
  
  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }
  
  // Skip chrome extension requests
  if (url.protocol === 'chrome-extension:') {
    return;
  }

  event.respondWith(
    handleRequest(request)
  );
});

/**
 * Handle different types of requests with appropriate caching strategies
 */
async function handleRequest(request) {
  const url = new URL(request.url);
  
  try {
    // Strategy 1: Network First (for API calls and manifest)
    if (isNetworkFirst(request.url)) {
      return await networkFirstStrategy(request);
    }
    
    // Strategy 2: Cache First (for static assets)
    if (isCacheFirst(request.url)) {
      return await cacheFirstStrategy(request);
    }
    
    // Strategy 3: Stale While Revalidate (for HTML pages)
    return await staleWhileRevalidateStrategy(request);
    
  } catch (error) {
    console.error('[SW] Request failed:', error);
    return await getOfflineFallback(request);
  }
}

/**
 * Network First Strategy - Try network, fallback to cache
 */
async function networkFirstStrategy(request) {
  try {
    const networkResponse = await fetch(request);
    
    // Cache successful responses
    if (networkResponse.ok) {
      const cache = await caches.open(DYNAMIC_CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    // Network failed, try cache
    const cachedResponse = await caches.match(request);
    if (cachedResponse) {
      console.log('[SW] Serving from cache (network failed):', request.url);
      return cachedResponse;
    }
    throw error;
  }
}

/**
 * Cache First Strategy - Try cache, fallback to network
 */
async function cacheFirstStrategy(request) {
  const cachedResponse = await caches.match(request);
  
  if (cachedResponse) {
    console.log('[SW] Serving from cache:', request.url);
    return cachedResponse;
  }
  
  try {
    const networkResponse = await fetch(request);
    
    // Cache successful responses
    if (networkResponse.ok) {
      const cache = await caches.open(DYNAMIC_CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.error('[SW] Cache and network both failed for:', request.url);
    throw error;
  }
}

/**
 * Stale While Revalidate Strategy - Serve from cache, update in background
 */
async function staleWhileRevalidateStrategy(request) {
  const cachedResponse = await caches.match(request);
  
  // Fetch fresh version in background
  const fetchPromise = fetch(request).then((networkResponse) => {
    if (networkResponse.ok) {
      const cache = caches.open(DYNAMIC_CACHE_NAME);
      cache.then(c => c.put(request, networkResponse.clone()));
    }
    return networkResponse;
  }).catch(() => {
    // Network failed, but we might have cache
    console.log('[SW] Network failed for:', request.url);
  });
  
  // Return cached version immediately if available
  if (cachedResponse) {
    console.log('[SW] Serving stale from cache:', request.url);
    return cachedResponse;
  }
  
  // No cache, wait for network
  return fetchPromise;
}

/**
 * Get offline fallback for failed requests
 */
async function getOfflineFallback(request) {
  const url = new URL(request.url);
  
  // For HTML pages, return cached main page or offline page
  if (request.headers.get('accept')?.includes('text/html')) {
    const cachedPage = await caches.match('/');
    if (cachedPage) {
      return cachedPage;
    }
    
    // Return simple offline page
    return new Response(`
      <!DOCTYPE html>
      <html lang="en" data-bs-theme="dark">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>FarmAssist Crop - Offline</title>
        <style>
          body { 
            font-family: Arial, sans-serif; 
            background: #1a1a1a; 
            color: #fff; 
            text-align: center; 
            padding: 2rem; 
          }
          .container { max-width: 600px; margin: 0 auto; }
          .icon { font-size: 4rem; margin-bottom: 1rem; }
          h1 { color: #2E7D32; margin-bottom: 1rem; }
          p { margin-bottom: 1rem; line-height: 1.6; }
          .btn { 
            background: #2E7D32; 
            color: white; 
            padding: 0.75rem 1.5rem; 
            text-decoration: none; 
            border-radius: 5px; 
            display: inline-block; 
            margin-top: 1rem; 
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="icon">🌱</div>
          <h1>FarmAssist Crop</h1>
          <p><strong>You're currently offline</strong></p>
          <p>Don't worry! You can still use the cached features of FarmAssist Crop. The app will work with your previously loaded data.</p>
          <p>When you reconnect to the internet, all features will be available again.</p>
          <a href="/" class="btn">Continue to App</a>
        </div>
      </body>
      </html>
    `, {
      headers: { 'Content-Type': 'text/html' }
    });
  }
  
  // For other resources, return error
  return new Response('Offline - Resource not available', {
    status: 503,
    statusText: 'Service Unavailable'
  });
}

/**
 * Check if request should use Network First strategy
 */
function isNetworkFirst(url) {
  return NETWORK_FIRST.some(pattern => url.includes(pattern));
}

/**
 * Check if request should use Cache First strategy
 */
function isCacheFirst(url) {
  return CACHE_FIRST.some(pattern => url.includes(pattern));
}

/**
 * Background Sync Event (for future features)
 */
self.addEventListener('sync', (event) => {
  console.log('[SW] Background sync triggered:', event.tag);
  
  if (event.tag === 'farmassist-data-sync') {
    event.waitUntil(syncFarmData());
  }
});

/**
 * Sync farm data when back online (placeholder for future implementation)
 */
async function syncFarmData() {
  console.log('[SW] Syncing farm data...');
  // Future: Sync offline actions when connection restored
}

/**
 * Message Event - Handle communication with main thread
 */
self.addEventListener('message', (event) => {
  const { type, payload } = event.data;
  
  switch (type) {
    case 'SKIP_WAITING':
      self.skipWaiting();
      break;
      
    case 'GET_CACHE_STATUS':
      getCacheStatus().then(status => {
        event.ports[0].postMessage(status);
      });
      break;
      
    case 'CLEAR_CACHE':
      clearAllCaches().then(() => {
        event.ports[0].postMessage({ success: true });
      });
      break;
      
    default:
      console.log('[SW] Unknown message type:', type);
  }
});

/**
 * Get current cache status
 */
async function getCacheStatus() {
  const cacheNames = await caches.keys();
  const status = {
    caches: cacheNames,
    totalCaches: cacheNames.length
  };
  
  for (const cacheName of cacheNames) {
    const cache = await caches.open(cacheName);
    const keys = await cache.keys();
    status[cacheName] = keys.length;
  }
  
  return status;
}

/**
 * Clear all caches (useful for debugging)
 */
async function clearAllCaches() {
  const cacheNames = await caches.keys();
  await Promise.all(
    cacheNames.map(cacheName => caches.delete(cacheName))
  );
  console.log('[SW] All caches cleared');
}